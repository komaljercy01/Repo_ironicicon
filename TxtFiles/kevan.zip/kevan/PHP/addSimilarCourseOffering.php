<?php 
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Similar Course Offering</title>

<link rel="stylesheet" href="../scripts/bootstrap-theme.min.css">
<link rel="stylesheet" href="../scripts/bootstrap.min.css">
<link rel="stylesheet" href="../scripts/font-awesome.min.css">
<link rel="stylesheet" href="../scripts/bootsnipp.min.css">
<script src="../scripts/jquery.min.js"></script>
<script src="../scripts/bootstrap.min.js"></script> 
<script src="../scripts/bootstrapValidator.min.js"></script>

          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="../scripts/html5shiv.js"></script>
    	<script src="../scripts/respond.js"></script>
    <![endif]-->
   

<link type="text/css" href="../css/jquery.ui.all.css" rel="stylesheet" /> 



	<script type="text/javascript" src="../scripts/jquery-1.4.2.js"></script> 
	<script type="text/javascript" src="../scripts/jquery.ui.core.js"></script> 
	<script type="text/javascript" src="../scripts/jquery.ui.widget.js"></script> 
	<script type="text/javascript" src="../scripts/jquery.ui.datepicker.js"></script> 
	
	

	<script type="text/javascript"> 
	$(function() {
		$(".datepicker").datepicker();
	});
	</script> 

   <script>
                $(function() {
                   
                      $('#stepExample1').timepicker();
                      $('#stepExample2').timepicker();
                      $('#stepExample3').timepicker();
                      $('#stepExample4').timepicker();

                   
                });
            </script>
</head>
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];

 $query4="select  USERTYPE from user where  USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'";
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$usertype = $row['USERTYPE'];
}



$SQLuserid = "select  * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}
else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>
<body>
<?php 
include 'config.php';
include 'opendb.php';

// if post submit , check if exist , then add record //

/* $insertStatement = "INSERT INTO COURSEOFFERING (classsize, day, startdate, enddate, courseid, semesterid, teacherid, cost, begintime, endtime, day2, begintime2, endtime2, status,crid) VALUES ('$classSize', '$classDay', '$stDate', '$endDate', '$courseId', '$semesterId', '$teacherId', '$cost', '$startTime', '$endTime', '$classDay2', '$startTime2', '$endTime2','$status','$classSize')";
              mysql_query($insertStatement);
              $notes = 'Course Offering successfully added.'; 
*/

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect value of input field


    $AcademicSemester = $_POST['AcademicSemester'];
    $Course = $_POST['Course'];
    $stDate = $_POST['stDate'];
    $endDate = $_POST['endDate'];
    $classDay = $_POST['classDay'];
    $starttime = $_POST['starttime'];
    $endtime = $_POST['endtime'];
    $starttime2 = $_POST['starttime2'];
    $endtime2 = $_POST['endtime2'];
    $lastDAY2 = $_POST['lastDAY2'];
    $status = $_POST['status'];
    $teacherId = $_POST['teacherId'];
    $classSize = $_POST['classSize'];
    $TAmount = $_POST['TAmount'];




  $result = mysql_query("SELECT  * FROM courseoffering 
    WHERE (
CLASSSIZE='$classSize'
AND DAY='$classDay'
AND STARTDATE='$stDate'
AND ENDDATE='$endDate'
AND COURSEID='$Course'
AND SEMESTERID='$AcademicSemester'
AND TEACHERID='$teacherId'
AND COST='$TAmount'
AND BEGINTIME='$starttime'
AND ENDTIME='$endtime'
AND DAY2='$lastDAY2'
AND BEGINTIME2='$starttime2'
AND ENDTIME2='$endtime2'
AND STATUS='$status'
AND crid='$classSize' )
    "); 

$count = mysql_num_rows($result);

if($count>0){
   echo "<span class='label label-warning'> Record already exists, please check fields!</span>";

}
else{
  $insertStatement = "INSERT INTO   COURSEOFFERING 
  (classsize, day, startdate, enddate, courseid, semesterid, teacherid, cost, begintime, endtime, day2, begintime2, endtime2, status,crid)
   VALUES ('$classSize', '$classDay', '$stDate', '$endDate', '$Course', '$AcademicSemester', '$teacherId', '$TAmount', '$starttime', '$endtime', '$lastDAY2', '$starttime2', '$endtime2','$status','$classSize')";
             $insert_record=  mysql_query($insertStatement);
             if($insert_record){
              echo "<span class='label label-success'>Success Record was entered!</span>";
            //  echo "<div class='alert alert-success'> Success.  </div>";
            }
              else{
                echo "<span class='label label-warning'>Record was not entered please check fields!</span>";

              }


            
              
}
    }

else{}
$last_coid_query = "SELECT   *  FROM     courseoffering ORDER BY COID DESC LIMIT    0, 1
";
$result_last_coid_query= mysql_query($last_coid_query);

while($noticia_result_last_coid_query = mysql_fetch_array($result_last_coid_query)) {

	$lastCOID =$noticia_result_last_coid_query[COID];
	$lastCourseid =$noticia_result_last_coid_query[COURSEID];
	$lastsemesterid =$noticia_result_last_coid_query[SEMESTERID];
	$lastclassssize =$noticia_result_last_coid_query[classssize];
	$classDay =$noticia_result_last_coid_query[DAY];
	$lastStartdate =$noticia_result_last_coid_query[STARTDATE];
	$lastenddate =$noticia_result_last_coid_query[ENDDATE];
	$lastteacherid =$noticia_result_last_coid_query[TEACHERID];
	$lastcost =$noticia_result_last_coid_query[COST];
	$lastBEGINTIME =$noticia_result_last_coid_query[BEGINTIME];
	$lastENDTIME =$noticia_result_last_coid_query[ENDTIME];
	$lastDAY2 =$noticia_result_last_coid_query[DAY2];
	$lastBEGINTIME2 =$noticia_result_last_coid_query[BEGINTIME2];
	$lastENDTIME2 =$noticia_result_last_coid_query[ENDTIME2];
	$lastSTATUS =$noticia_result_last_coid_query[STATUS];
	$lastcrid =$noticia_result_last_coid_query[crid];


}
//echo $lastsemesterid;

?>
  <div class="row">
    <div class="col-md-8 col-md-offset-1">
    
    <?php  echo "<form action=".$_SERVER['PHP_SELF']." method=post  class='form-horizontal' role='form' >" ; ?>
        <fieldset>

          <!-- Form Name -->
          <legend>Add Similar Course Offering</legend>

           <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Academic Year - Semester </label>
            <div class="col-sm-8">
          <?php 

echo " <select name='AcademicSemester' id='AcademicSemester' class='form-control' > ";

$sem_id_query = "
SELECT SEMESTER.SEMESTERID ,semester.ACADEMICYEARID,semester.STARTDATE, SEMESTER.ENDDATE  , academicyr.YEARID , academicyr.BODYID 
, academicyr.START , academicyr.END
FROM semester , academicyr

WHERE 
semester.ACADEMICYEARID = academicyr.YEARID 
AND 
SEMESTER.SEMESTERID = $lastsemesterid
";    
$result_sem_id_query= mysql_query($sem_id_query);

while($noticia_result_sem_id_query = mysql_fetch_array($result_sem_id_query)) {
  $semesterid_display = $noticia_result_sem_id_query['SEMESTERID'];
}
//echo "</select>";


$sem_id_query = "
SELECT SEMESTER.SEMESTERID ,semester.ACADEMICYEARID,semester.STARTDATE, SEMESTER.ENDDATE  , academicyr.YEARID , academicyr.BODYID 
, academicyr.START , academicyr.END
FROM semester , academicyr

WHERE 
semester.ACADEMICYEARID = academicyr.YEARID 
ORDER by academicyr.START , semester.STARTDATE DEsc
";    
$result_sem_id_query= mysql_query($sem_id_query);

while($noticia_result_sem_id_query = mysql_fetch_array($result_sem_id_query)) {

  if($semesterid_display == $noticia_result_sem_id_query['SEMESTERID']){
    echo "<option selected value='".$noticia_result_sem_id_query['SEMESTERID']."'>(Academic year) ".$noticia_result_sem_id_query['START']." to ".$noticia_result_sem_id_query['END']." (Semester) ".$noticia_result_sem_id_query['STARTDATE']." to ".$noticia_result_sem_id_query['ENDDATE']."</option>";
  }

else {
  echo "<option value='".$noticia_result_sem_id_query['SEMESTERID']."'>(Academic year) ".$noticia_result_sem_id_query['START']." to ".$noticia_result_sem_id_query['END']." (Semester) ".$noticia_result_sem_id_query['STARTDATE']." to ".$noticia_result_sem_id_query['ENDDATE']."</option>";
}
}
echo "</select>";
  ?>
            </div>
</div>

           <!-- Text input-->
         
<div class="form-group">


            <label class="col-sm-2 control-label" for="textinput">Program - Course</label>
          <div class="col-sm-10">
          <?php 

echo " <select name='Course' id='Course' class='form-control' > ";



$course_id_query = "
SELECT COURSE.COURSEID , COURSE.PROGRAMID , COURSE.COURSETITLE , program.PROGRAMID , program.BODYID , PROGRAM.SEMESTER , PROGRAM.TITLE FROM course , program WHERE 
COURSE.PROGRAMID =  program.PROGRAMID 
AND
COURSE.COURSEID=$lastCourseid

ORDER by PROGRAM.TITLE
";    
$result_course_id_query= mysql_query($course_id_query);

while($noticia_result_course_id_query = mysql_fetch_array($result_course_id_query)) {
  
$courseid_display = $noticia_result_course_id_query['COURSEID'];
}
//echo "</select>";




$course_id_query = "
SELECT COURSE.COURSEID , COURSE.PROGRAMID , COURSE.COURSETITLE , program.PROGRAMID , program.BODYID , PROGRAM.SEMESTER , PROGRAM.TITLE FROM course , program WHERE 
COURSE.PROGRAMID =  program.PROGRAMID 
ORDER by PROGRAM.TITLE
";    
$result_course_id_query= mysql_query($course_id_query);

while($noticia_result_course_id_query = mysql_fetch_array($result_course_id_query)) {
  if ($courseid_display==$noticia_result_course_id_query['COURSEID']){
    echo "<option selected value='".$noticia_result_course_id_query['COURSEID']."'>".$noticia_result_course_id_query['TITLE']." - ".$noticia_result_course_id_query['COURSETITLE']."</option>";

}
 else{
  echo "<option value='".$noticia_result_course_id_query['COURSEID']."'>".$noticia_result_course_id_query['TITLE']." - ".$noticia_result_course_id_query['COURSETITLE']."</option>";

}

}
echo "</select>";
  ?>
            </div>

 </div>
          
 <input type="hidden"    name="vid" id="vid"     value="<?php echo $vid_get;?>" >

   <!-- drop down  input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" >Start Date</label>
            <div class="col-sm-2">
              <input type="text" name="stDate" class="datepicker" placeholder="" class="form-control"  value="<?php echo $lastStartdate; ?>" />
            </div>
    
          <label class="col-sm-2 control-label" >End Date</label>
            <div class="col-sm-2">
              <input type="text"  name="endDate" class="datepicker" placeholder="" class="form-control" value="<?php echo $lastenddate; ?>"  />
            </div> 
       
           <label class="col-sm-2 control-label" >Day</label>
            <div class="col-sm-2">
               <select name="classDay" placeholder="" class="form-control">
										<option selected><?php echo  $classDay; ?></option>
										<option>Monday</option>
										<option>Tuesday</option>
										<option>Wednesday</option>
										<option>Thursday</option>
										<option>Friday</option>
										<option>Saturday</option>
										<option>Sunday</option>
									</select>
            </div>
</div>


 			<div class="form-group">
                       <label class="col-sm-2 control-label" for="textinput">Start Time (24 hour)</label>
             <div class="col-sm-2">
            <div class="demo">
             <input id="stepExample1" type="text" class="time" placeholder="" class="form-control"  name="starttime"  value="<?php echo $lastBEGINTIME; ?>"  /> 
            </div>
            </div>

            
            <label class="col-sm-2 control-label" for="textinput">End Time (24 hour)</label>
            <div class="col-sm-2">
              <div class="demo">
             <input id="stepExample2" type="text" class="time" placeholder="" class="form-control"  name="endtime"  value="<?php echo $lastENDTIME ; ?>" /> 
            </div>
        </div>
        </div>

 <legend> Second day class  Info (optional)</legend>
             <div class="form-group">
            <label class="col-sm-2 control-label" >Start Time 2 (24 hour) </label>
            <div class="col-sm-2">
             <div class="demo">
             <input id="stepExample3" type="text" class="time" placeholder="" class="form-control"  name="starttime2"   value="<?php echo $lastBEGINTIME2 ; ?>" /> 
            </div>
        </div>
    
          <label class="col-sm-2 control-label" >End Time 2 (24 hour)</label>
            <div class="col-sm-2">
              <div class="demo">
             <input id="stepExample4" type="text" class="time" placeholder="" class="form-control"  name="endtime2"   value="<?php echo $lastENDTIME2 ; ?>" /> 
            </div>
             </div> 
        
           <label class="col-sm-2 control-label" >Day 2</label>
            <div class="col-sm-2">
               <select name="lastDAY2" placeholder="" class="form-control">
										<option><?php echo $lastDAY2; ?></option>
										<option>Monday</option>
										<option>Tuesday</option>
										<option>Wednesday</option>
										<option>Thursday</option>
										<option>Friday</option>
										<option>Saturday</option>
										<option>Sunday</option>
									</select>
            </div>
</div>

 <legend> Class  Info (required)</legend>

             <div class="form-group">
                       <label class="col-sm-2 control-label" for="textinput">Status </label>
            <div class="col-sm-4">
              <select name="status" placeholder="" class="form-control">
							<?php echo			"<option value=".$lastSTATUS.">".$lastSTATUS.""; ?> </option>
										<option value="FT">FT</option>
										<option value="PT">PT</option>
									</select>
            </div>
                <div class="col-sm-4">Part Time (PT) or Full Time (FT)</div>
            </div>

             <div class="form-group">
                       <label class="col-sm-2 control-label" for="textinput">Teacher</label>
            <div class="col-sm-4">
              <select name="teacherId">
									

										
							
							<?php		$teacherQue = mysql_query("SELECT * FROM TEACHER WHERE ID =$lastteacherid" );						
										while($enRow = mysql_fetch_array($teacherQue))
										{	?>
											<option selected value="<?php echo $enRow['ID'].'">'.$enRow['FNAME'].' '.$enRow['LNAME'].', '.$enRow['TITLE'].'</option>';
										 } 

										 $teacherQue = mysql_query("SELECT * FROM TEACHER WHERE ACTIVE='Y'" );						
										while($enRow = mysql_fetch_array($teacherQue))
										{	?>
											<option  value="<?php echo $enRow['ID'].'">'.$enRow['FNAME'].' '.$enRow['LNAME'].', '.$enRow['TITLE'].'</option>';
										 } ?>	

									</select>
            </div>
            </div>


             <div class="form-group">
             <label class="col-sm-2 control-label" for="textinput">Class Size</label>
            <div class="col-sm-4">
             <?php
                                
								
								?>
									<select name="classSize">
							<?php		
										$classSizeQue = mysql_query("SELECT crid , classname , classssize FROM classroom where crid=$lastcrid; ");
										while($thisclassSizerow = mysql_fetch_array($classSizeQue)){
										?>	
                                        <option selected value=<?php echo '"'.$thisclassSizerow['crid'].'">'.$thisclassSizerow['classname'].' size - '.$thisclassSizerow['classssize'].'</option>';
										}	
										
										$classSizeQue = mysql_query("SELECT crid , classname , classssize FROM classroom where 1; ");
										while($thisclassSizerow = mysql_fetch_array($classSizeQue)){
										?>	
                                        <option  value=<?php echo '"'.$thisclassSizerow['crid'].'">'.$thisclassSizerow['classname'].' size - '.$thisclassSizerow['classssize'].'</option>';
										}	
										
										?>

										
				
									</select>
            </div>
          </div>    


          <div class="form-group">
             <label class="col-sm-2 control-label" for="textinput">Cost</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="TAmount" id="TAmount" value="<?php echo $lastcost; ?>">
            </div>
          </div>   
      <div class="row">
    <div class="col-md-12 col-md-offset-0">      


          </div>   
          
 
          
  
          
              
          
          
</div>
</div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
                 <button type="submit" class="btn btn-primary">Add Course Offering </button>
                 <button type="submit" class="btn btn-default">Cancel</button>
              </div>
            </div>
      </div>
        </fieldset>
      </form>
    </div><!-- /.col-lg-12 -->
</div><!-- /.row -->

<script>


</script>
</body>
<?php 

?>
</html>                                		