<?php
// config.php
$dbhost = '127.0.0.1';
$dbuser = 'root';
$dbpass = 'root';

$dbname = 'elance';
//$dbpass = '6-108E4adfn2A!Li';

include 'opendb.php';
include 'loginCheck.php';
?>