<?php include("header.php"); ?>

<div class="about-neuroflexyn-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12">
				<h1 class="caption-top">WHAT'S IN</h1>
				<h1 class="caption-bottom">NEUROFLEXYN?</h1>
				<p class="subheader-caption">GET THE HIGHEST RATED PRODUCTIVITY PILL TODAY</p>
				<div class="ingredients">
					
					<?php include("neuroflexyn-ingredients.php"); ?>

				</div>

				<img class="img-responsive hidden-xs" src="images/img-label.png" />
				<img class="img-responsive visible-xs label-mobile" src="images/img-label-mobile.png" />

			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">

			<?php include("sidebar.php"); ?>

			</div>
		</div>

	</div>
	<div class="try-neuroflexyn">

		<?php include("try-neuroflexyn.php"); ?>
		
	</div>
	<?php include("footer-logo-sublinks.php"); ?>	
	<?php include("footer.php"); ?>

</div>