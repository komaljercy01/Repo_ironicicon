<?php 
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Vendor Payments</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
<script src="//oss.maxcdn.com/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.min.js"></script>

          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
    <style type="text/css">
/* Adjust feedback icon position */
#addVendor .form-control-feedback {
    right: 15px;
}
#addVendor .selectContainer .form-control-feedback {
    right: 25px;
}
</style>


</head>
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
// $appid = $_GET['appid'];
// $appidcheck = $_GET['appid'];

 $query4="select  USERTYPE from user where  USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'";
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$usertype = $row['USERTYPE'];
}



$SQLuserid = "select  * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}
else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>
<body>
<?php 
include 'config.php';
include 'opendb.php';
$vid_get = $_GET['vid'];


$quer_usersfor_course=mysql_query("
SELECT  *
FROM   Vendor
WHERE  
VendorID=$vid_get
");  
while($noticia = mysql_fetch_array($quer_usersfor_course)) {
$VendorName= $noticia['VendorName'];
$VendorDesc = $noticia['VendorDesc'];
$Vexpense = $noticia['Vexpense'];
$VendorCashAcct = $noticia['VendorCashAcct'];
$VendorAdd = $noticia['VendorAdd'];
$Vcity = $noticia['Vcity'];
$VendorPersonContact = $noticia['VendorPersonContact'];
$VendorPContact = $noticia['VendorPContact'];
$VendorSContact = $noticia['VendorSContact'];
$Vfax = $noticia['Vfax'];
$VendorAcctname = $noticia['VendorAcctname'];
$VendorPEmail = $noticia['VendorPEmail'];
$Vweb = $noticia['Vweb'];
$Vtype = $noticia['Vtype'];
$Vactive = $noticia['Vactive'];


}





// foreach($_POST['stakeholderarray'] as $this_stakeholderarray){
 // echo $this_stakeholderarray;
 
// }

?>
  <div class="row">
    <div class="col-md-8 col-md-offset-1">
      <form class="form-horizontal" role="form" action="addvendorpayment1Submit.php" method="post" id="addVendor">
        <fieldset>

          <!-- Form Name -->
          <legend>Add Vendor Payment</legend>

           <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Vendor Name</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="vname" id="vname" value="<?php echo $VendorName; ?>" readonly >
            </div>

            <label class="col-sm-2 control-label" for="textinput">Vendor Number</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="vnumber" id="vnumber" value="<?php echo $vid_get; ?>" readonly>
            </div>
          </div>

         

          
 <input type="hidden"    name="vid" id="vid"     value="<?php echo $vid_get;?>" >

   <!-- drop down  input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Cash Account </label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="cash" id="cash" value="34" readonly >
            </div>
          </div>
         <!-- Text input-->
          
           <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Cheque Number</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="VchequeNo" id="VchequeNo" value="<?php echo $VchequeNo; ?>">
            </div>

            <label class="col-sm-2 control-label" for="textinput">Cheque Date</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="Date" id="Date" value="<?php echo $date; ?>">
            </div>
          </div>
             <!-- Text input-->
          <div class="form-group">
           

            <label class="col-sm-2 control-label" for="textinput">Cheque Amount</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="Date" id="Date" value="<?php echo $date; ?>">
            </div>
          </div>



             <div class="form-group">
             <label class="col-sm-2 control-label" for="textinput">Total Amount</label>
            <div class="col-sm-8">
              <input type="text" placeholder="" class="form-control" name="TAmount" id="TAmount" value="Cheque Amount - All Discounts + ALL Subtotals , Must match Cheque amount" readonly>
            </div>
          </div>    

    <div id="container">
    <div id="demo">
<table id="example" class="display" cellspacing="1" width="120%">
    <thead>
        <tr>
          
            <th >Bill ID</th>
              <th >Due Date</th>
                <th >Total</th>
                <th > Previous Payments</th>
                <th >Amt Due </th>
                  <th >Payment Amount</th>
                   <th >Discount</th>
                    <th >Account</th>
                     <th >-</th>


          </tr>
    </thead>
    <tbody>
   
   
  
 
<?php




/////////////////////////////////////////////////////////create temp table//////////////////////////////////////////////////
include 'config.php';
include 'opendb.php';

$billTotal=0;
  $quer_usersfor_course=mysql_query("

SELECT  Vendor.Vendorid ,   Vendor.VendorName ,
Vendorbills.Vbid , Vendorbills.vid , Vendorbills.duedate
FROM  vendorbills , Vendor 
WHERE  

Vendor.Vendorid = Vendorbills.vid
and  Vendorbills.vid = '$vid_get'
");
$i=1;
while($noticia = mysql_fetch_array($quer_usersfor_course)) {
$vbidQuery = $noticia['Vbid'];
echo "<tr>";
echo "<td>".$noticia['Vbid']." </td>";
echo "<td>".$noticia['duedate']." </td>";
$quer_usersfor_billsubTotal=mysql_query("SELECT  *FROM  Vendorbillsitems WHERE  Vbid = '$vbidQuery'");
while($noticia_quer_usersfor_billsubTotal = mysql_fetch_array($quer_usersfor_billsubTotal)) {
$billTotal += $noticia_quer_usersfor_billsubTotal['Quantity'] * $noticia_quer_usersfor_billsubTotal['unitPrice'];
//$billItemDesc .=" ".$noticia_quer_usersfor_billsubTotal['Description'];
}
echo "<td>".$billTotal." </td>";
echo "<td> Total Amt previous bills   </td>";
echo "<td>  = Total - previous Payments </td>";

echo "<td><input type='text' name='Amount$i'>  </td>";     
echo "<td> <input type='text' name='dscount$i'> </td>";
echo "<td> <select name='discountAcct$i'>
<option value='15'>15</option>
<option value='23'>23</option>
</select>
</td>";
echo "<td>  <input type='checkbox' id='Billid$i' name='enable' value='Billid$i'> </td>";
echo "</tr>"; 
$i++;
$billTotal=0;
$billItemDesc='';
}
?>

    </tbody>
 <input type='hidden' id='testValue' name='testValue' value='<?php echo $i;?>'>   
</table>


</div>
</div>


         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-8">
              <div class="pull-right"> </div>
            </div>
      </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-8">
              <div class="pull-right"> </div>
            </div>
      </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-8">
              <div class="pull-right"> </div>
            </div>
      </div>

          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">

                <button type="submit" class="btn btn-default">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
            </div>
      </div>
        </fieldset>
      </form>
    </div><!-- /.col-lg-12 -->
</div><!-- /.row -->
<script>
	$(document).ready(function(){
		var Id=$('#testValue').val();
		var inputValue=1;
		for(inputValue=1;inputValue<Id;inputValue++)
		{
			$('#Billid'+inputValue).click(function()
			{
				if(this.checked)
				{
					$('#Amount'+inputValue).attr("disabled","disabled");
					$('#dscount'+inputValue).attr("disabled","disabled");
					$('#discountAcct'+inputValue).attr("disabled","disabled");
				}
			});
		}
	});
</script>

</body>
</html>                                		