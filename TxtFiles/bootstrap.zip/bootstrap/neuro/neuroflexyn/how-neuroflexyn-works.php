<?php include("header.php"); ?>

<div class="how-it-works-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12">
				<h1>HOW IT WORKS</h1>
				<p class="subheader-caption">FEEL THE EFFECT WITHIN 1 HOUR</p>
				<p class="info">Neuroflexyn uses a scientifically-engineered stack of maximum strength nootropics, known as "smart drugs," to help increase brain activity, mental performance, and vigilance.</p>
				<p class="info">Nootropics improve the function of the neurotransmitter acetylcholine via cholinergic (ACh) receptors and stimulate NMDA glutamate receptors that are critical to the learning and memory processes. Furthermore, nootropics influence neuronal and vascular functions and increase cognitive function, while at the same time providing a natural source of energy to keep you alert and motivated.</p>

				<div class="how-work-setps">
					<div class="step">
						<img src="images/img-step1.jpg" />
						<div class="info">
							<p class="title">STEP #1</p>
							<p class="body">First, Neuroflexyn elevates your metabolism by supplying your cell's power-houses (mitochondria) with Alpha Lipoic Acid. This enables them to make energy faster.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="step">
						<!-- <img src="images/img-stepline.jpg" /> -->
						<div class="clearfix"></div>
					</div>
					<div class="step">
						<img src="images/img-step2.jpg" />
						<div class="info">
							<p class="title">STEP #2</p>
							<p class="body">Then, Vinpocetine rejuvenates your mind by increasing blood flow and oxygen to your brain, much the same way that exercise clears your mind.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="step">
						<!-- <img src="images/img-stepline.jpg" /> -->
						<div class="clearfix"></div>
					</div>
					<div class="step">
						<img src="images/img-step3.jpg" />
						<div class="info">
							<p class="title">STEP #3</p>
							<p class="body">Next, Choline restores neurotransmitters that are broken down throughout your day. These cell communicators are responsible for the clarity of your mind.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="step">
						<!-- <img src="images/img-stepline.jpg" /> -->
						<div class="clearfix"></div>
					</div>
					<div class="step">
						<img src="images/img-step4.jpg" />
						<div class="info">
							<p class="title">STEP #4</p>
							<p class="body">Finally, Neuroflexyn provides you the energy of a cup of coffee while keeping your body relaxed and stress-free with GABA.</p>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>

			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">

			<?php include("sidebar.php"); ?>

			</div>
		</div>

	</div>
	<div class="try-neuroflexyn">

		<?php include("try-neuroflexyn.php"); ?>
		
	</div>
	<?php include("footer-logo-sublinks.php"); ?>	
	<?php include("footer.php"); ?>

</div>