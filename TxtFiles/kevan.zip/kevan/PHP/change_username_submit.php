<?php session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Change username</title>

	<script type="text/javascript" src="../jquery.js"></script>
	<script type="text/javascript" src="../scripts/ajaxfileupload.js"></script>
    <link href="../CSS/Local.css" rel="stylesheet" type="text/css">
	
<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>

<script type="text/javascript" src="../scripts/jquery-1.2.1.pack.js"></script>



</head>

<body>
<div id="container">
<table width="100%" border="0">
  <caption align="left">
    Menu
  </caption>
  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>

<?php 
include 'config.php';
include 'opendb.php';

//$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];


$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}
} // if($row=mysql_fetch_array($resultid))
else{
echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}

$username = $_POST['inputString'];  
$newusername = $_POST['new_username'];      
$SQLuserid_user = "select * from  user where USERNAME='".$username."'"; 
 $SQLuserid_user_ = mysql_query($SQLuserid_user); 
 while ($resultid_user = mysql_fetch_array($SQLuserid_user_)){
$usernameid=$resultid_user['USERID'];}

/////////////////////CHECK if New username already exist/////////////////////////////////

$SQLuserid_user = "select * from  user where USERNAME='".$newusername."'"; 
 $SQLuserid_user_ = mysql_query($SQLuserid_user); 
 $if_username_exist = mysql_num_rows($SQLuserid_user_);
if ($if_username_exist!=0){
echo "Username ".$newusername." already exist please try again";
include 'change_username.php';
die();
}






///////////////////////////////////////////////////////////////////////////////////////
//$new_passwd = md5('P@ssword');
$change= "UPDATE USER SET 
USERNAME = '$newusername'
WHERE 
USERID = '$usernameid' ";
$query_change= mysql_query($change);
 if (!$query_change){
 echo "Username change FAILED!";}
 else {
 echo "Username change Success!";}
 
 ?>
   
	
</div>
</body>
</html>
