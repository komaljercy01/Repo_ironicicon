<img class="img-responsive header-img" src="images/img-titleingredients.png" />
<img class="img-responsive hidden-xs" src="images/img-ingredients.png" />

<img class="img-responsive visible-xs" src="images/img-ingredients1.png" />
<img class="img-responsive visible-xs" src="images/img-ingredients2.png" />
<img class="img-responsive visible-xs" src="images/img-ingredients3.png" />
<img class="img-responsive visible-xs" src="images/img-ingredients4.png" />
<img class="img-responsive visible-xs" src="images/img-ingredients5.png" />