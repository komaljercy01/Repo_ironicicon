<table width="800" border="0">
  <tr>
    <td>Default Admin</td>
  </tr>
  <tr>
    <td><a href="getuser_Madmin.php" >Reset Admin password</a></td>
  </tr>
  <tr>
    <td> </td>
  </tr>
</table>