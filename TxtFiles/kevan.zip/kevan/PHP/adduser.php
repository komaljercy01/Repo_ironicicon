<?php 
session_start();
?>
<html>
<head>
<title>CTS</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

  <LINK rel="stylesheet" href="../css/style1.css" type="text/css">
  

<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>

<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">

</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="container">
<table width="100%" border="0">
  <caption align="left">
    Menu
  </caption>
  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a></td>
  </tr>
</table>
  <?php
//
include 'config.php';
include 'opendb.php';


$username = $_POST['Username'];
$email = $_POST['email'];
$usertype = $_POST['usertype'];


// must be alphanumeric
if (!preg_match("/^\w+$/", $username)){
include 'adduser.html';
echo  "Username must contain Alphanumeric characters only, please try again";	
die();
}


$SQLuserid = mysql_query("select * from  user where USERNAME='$username' OR email='$email'"); 
$resultid = mysql_num_rows($SQLuserid);
if($resultid == 0)
{


function createPassword($length) {
	$chars = "234567890abcdefghijkmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$i = 0;
	$password = "";
	while ($i <= $length) {
		$password .= $chars{mt_rand(0,strlen($chars))};
		$i++;
	}
	return $password;

 }
$password = createPassword(8);
$encrpyt_password = md5($password);


// random password generator goes here
$SQL1 = "INSERT INTO USER (USERNAME, PASSWORD , EMAIL , ACTIVE , USERTYPE )
Values('".$username."','".$encrpyt_password."','".$email."','"."1"."','".$usertype."')" ;

$result1 = mysql_query($SQL1);


$sendto = $email; // this is the email address collected form the form
//$ccto = "you@yourdomain.com"; //you can cc it to yourself
$subject = "Email confirmation"; // Subject
$message = "

Congratulations! You have successfully registered with CTSCBCS online registration. Please find details of your login credentials below:

Username: ".$username."
Password: ".$password."
Login URL: (Under Construction) 

Please keep this information in a safe place. It is recommended that you change your password when you login to the application. We would encourage you to login to view your details at least once per week. Kindly use the website to make changes to your personal information and your registration details.

We thank you for choosing CTSCBCS as your education provider.

Welcome on board! 

____________________________________________________________
Nigel Polar
Administrative Director

CTS College of Business and Computer Science Ltd

120 Montrose Main Road, Chaguanas, Trinidad, West Indies.

Email: npolar@ctscbcs.com

Phone: 1-868-671-2551 / 1-868-671-2872

Fax: 1-868-671-3198

Website: www.ctscbcs.com 
____________________________________________________________



NOTICE:
This e-mail message contains information which is confidential and privileged, and is for the exclusive use of the intended recipient(s). It is the property of CTSCBCS in whom all copyrights and other rights are reserved where so indicated. If you are not the intended recipient, you are hereby notified that any use, dissemination, disclosure and/or copying of this email message or the information in it (including any attachments) is strictly prohibited. If you have received this e-mail message in error, please notify the sender immediately by e-mail and delete it from your system. E-mail transmissions cannot be guaranteed to be secure or error-free as information could be intercepted, corrupted, lost, destroyed, arrive late or incomplete, or contain viruses. The sender therefore does not accept liability for any errors or omissions in the contents of this message or any loss or damage arising from the use of this email message and/or attachments.

";
$header .= "Reply-to: CONTACT@CTSCBCS.com\r\n";
// This is the function to send the email
mail($sendto, $subject, $message, $header); 

//echo $message; 

echo "</p> Account creation successful. <p><a href='adduser.html'>Click here to add another user.</a></p>";
	
	echo "</p> OR Go back to HOME --> Enter User Application Information to enter information for".$username." ";
	// <p><a href='addstudentinfo.php?inputString=".$username."'>Enter Application Information for ".$username.".</a></p>";
		 	 
}


else{

include 'adduser.html';
echo  "Username or email already exists please try again";	

}

?>

</div>
</body>
</html>