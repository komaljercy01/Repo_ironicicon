<?php 
session_start();
?>
	<script type="text/javascript" src="../scripts/jquery.js"></script>
	<script type="text/javascript" src="../scripts/ajaxfileupload.js"></script>
	<script type="text/javascript">
	function ajaxFileUpload()
	{
		$("#loading")
		.ajaxStart(function(){
			$(this).show();
		})
		.ajaxComplete(function(){
			$(this).hide();
		});

		$.ajaxFileUpload
		(
			{
				url:'doajaxfileupload.php?phototype='+$("#phototype").val(),
				secureuri:false,
				fileElementId:'fileToUpload',
				dataType: 'json',
				success: function (data, status)
				{
					if(typeof(data.error) != 'undefined')
					{
						if(data.error != '')
						{
							alert(data.error);
						}else
						{
							alert(data.msg);
						}
					}
				},
				error: function (data, status, e)
				{
					alert(e);
				}
			}
		)
		
		return false;

	}
	</script>	
    
<html>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">

<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">
<head>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$username = $_SESSION['username_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;

?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {

$_SESSION['username_session'] = $username;
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>



		  <?php
		  
///Previous values///////////////

$SQL_old= "SELECT * 
FROM APPLICATION
WHERE USERID =$stu_id
ORDER BY APPLICATIONID DESC 
LIMIT 0 , 1 ";

$result_old = mysql_query($SQL_old);

while($row_old=mysql_fetch_array($result_old))
{

$old_title = $row_old['TITLE'];		  
$old_fname = $row_old['FIRSTNAME'];
$old_lname = $row_old['LASTNAME'];
$old_gender = $row_old['GENDER'];
$old_email = $row_old['EMAIL'];
$old_dob= $row_old['DOB'];
$old_Haddress = $row_old['ADDRESS1'];
$old_Haddress1 = $row_old['ADDRESS2'];
$old_City = $row_old['CITY'];
$old_Country = $row_old['COUNTRY'];
$old_MailAdd1 = $row_old['MAILADDRESS1'];
$old_MailAdd2 = $row_old['MAILADDRESS2'];
$old_workname = $row_old['COMPANYNAME'];
$old_occupation = $row_old['OCCUPATION'];
$old_Idtype = $row_old['IDTYPE'];
$old_Idnumber = $row_old['IDNUMBER'];
$old_hnumber = $row_old['PHONE1'];
$old_Wphone = $row_old['PHONE2'];
$old_MPhone = $row_old['PHONE3'];
$old_CName = $row_old['CONTACTNAME'];
$old_Crelationship = $row_old['CONTACTRELATIONSHIP'];
$old_ContactPhoneNumber = $row_old['CONTACTPH1'];

}

//Previous values///////////////////////
//////////CURRENT VALUES////////////////////////////
$title = $_POST['title'];		  
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$gender = $_POST['Gender'];
$email = $_POST['email'];
$today = time(); 
$dob= $_POST['year']."-".$_POST['month']."-".$_POST['day'];
$Haddress = $_POST['HAddress'];
$Haddress1 = $_POST['HAddress1'];
$City = $_POST['City'];
$Country = $_POST['Country'];
$MailAdd1 = $_POST['MailAdd1'];
$MailAdd2 = $_POST['MailAdd2'];
$workname = $_POST['WorkAdd'];
$occupation = $_POST['Occupation'];
$Idtype = $_POST['IDtype'];
$Idnumber = $_POST['IDnumber'];
$hnumber = $_POST['Hphone'];
$Wphone = $_POST['Wphone'];
$MPhone = $_POST['MPhone'];
$CName = $_POST['ContactName'];
$Crelationship = $_POST['ContactRelationship'];
$ContactPhoneNumber = $_POST['ContactPhoneNumber'];
//$userid = $_POST['userid'];
//$dobinsert= strftime("%Y-%m-%d", strtotime($dob));
//////////CURRENT VALUES////////////////////////////

/*

if ($title== $old_title 
&& $fname==$old_fname 
&& $lname==$old_lname 
&& $old_gender == $gender 
&& $email ==$old_email
&& $old_dob == $dob
&& $old_Haddress ==  $Haddress 
&& $old_Haddress1 == $Haddress1 
&& $old_City == $City 
&& $old_Country ==$Country 
&& $old_MailAdd1==  $MailAdd1 
&& $old_MailAdd2 == $MailAdd2 
&& $old_workname== $workname 
&& $old_occupation == $occupation 
&& $old_Idtype ==$Idtype 
&& $old_Idnumber ==$Idnumber
&& $old_hnumber== $hnumber 
&& $old_Wphone == $Wphone 
&& $old_MPhone == $MPhone  
&& $old_CName== $CName
&& $old_Crelationship == $Crelationship  
&& $old_ContactPhoneNumber == $ContactPhoneNumber

   ){}
else {
*/

include 'config.php';
include 'opendb.php';

$SQL1 = "INSERT INTO APPLICATION (TITLE , USERID ,FIRSTNAME  ,LASTNAME , GENDER ,EMAIL , DOB ,ADDRESS1 ,ADDRESS2 ,CITY ,COUNTRY, MAILADDRESS1,MAILADDRESS2	,COMPANYNAME ,OCCUPATION ,	IDTYPE 	,IDNUMBER ,	PHONE1 ,PHONE2 	,PHONE3 ,CONTACTNAME ,CONTACTRELATIONSHIP ,CONTACTPH1 )
Values('".$title."','".$stu_id."','".$fname."','".$lname."','".$gender."','".$email ."','".$dob."','".$Haddress."','".$Haddress1."','".$City."','".$Country."','".$MailAdd1."','".$MailAdd2."','".$workname."','".$occupation."','".$Idtype."','".$Idnumber."','".$hnumber."','".$Wphone."','".$MPhone."','".$CName."','".$Crelationship."','".$ContactPhoneNumber."')" ;

//$result1 = mysql_query($SQL1);


//if (!$result1){
//echo '<p> Unable to log in <a href=login.php > click here </a> to login again';
//die();
//}
//} // else (old != new)

$appid= "SELECT * 
FROM APPLICATION
WHERE USERID =$stu_id
ORDER BY APPLICATIONID DESC 
LIMIT 0 , 1 ";

$appidquery = mysql_query($appid); 

while($row = mysql_fetch_array( $appidquery )) {

$appidcheck =  $row['APPLICATIONID'];


} 

 
 //echo $_SESSION['password_session_go_back'].$_SESSION['password_session'] ;
  ?>
  
      
    <h3> STEP 2 of 5 </h3>
    <h3>Photo Upload</h3>

<form id="MedicalInformation" name="MedicalInformation" action="addstudentinfo_courses.php"   method="post" >
  <table border="0">
        
<div id="content"><img id="loading" src="../images/loading.gif" style="display:none;"> </div>
			<tr>
				<td>Please select a file and click Upload button</td>
    <!--           
                <td rowspan="4" align="center" valign="top"> <strong>Your Photo
                  </strong>
                  <A HREF="javascript:history.go(0)">Click to view your updated photo</A>
                 
                  <p>
                    <?php
   
	 $upload_directory  = $_SERVER[DOCUMENT_ROOT] ."/CTS/userphotos/latest".$stu_id.".img";
       
        // Check that the images directory exists
        if(file_exists($upload_directory))
        {   
		//echo "<a href=".$upload_directory.">".$upload_directory."</a>";
		echo "<img src=".$upload_directory." width='240' height='124' />";
		}
		else {
		echo "No photo Uploaded";
			
		}
?> 
                    
                    <!--   <img src="userphotos/latest10.img" width="640" height="480">-->
                      </td>
</tr>
    <tr><td>
      <label>
      
      
      
      
      
      
      
      <select name="phototype" id="phototype">
        <option value="xx" selected>Choose a photo Type</option>
        <option value="ID">ID</option>
        <option value="photo">Photo</option>
        <option value="Result">Results</option>
        <option value="GEr">GCE results</option>
        <option value="CxC">CXC</option>
        <option value="cA">certificate1</option>
        <option value="cB">certificate2</option>
        <option value="cC">certificate3</option>
        <option value="cD">certificate4</option>
        <option value="cE">certificate5</option>
        <option value="cF">certificate6</option>
        <option value="Aff">Affidavit</option>
        <option value="mc">Marriage Certificate</option>
        <option value="gclA">Gate Clearance Letter (page1)</option>
         <option value="gclB">Gate Clearance Letter (page2)</option>
          <option value="dpA">Deed Poll (page1)</option>
          <option value="dpB">Deed Poll (page2)</option>
          <option value="dpC">Deed Poll (page3)</option>
          <option value="dpD">Deed Poll (page4)</option>
          <option value="dpE">Deed Poll (page5)</option>
          <option value="dpF">Deed Poll (page6)</option>
          <option value="dpG">Deed Poll (page7)</option>
          <option value="dpH">Deed Poll (page8)</option>
          <option value="dpI">Deed Poll (page9)</option>
          <option value="dpJ">Deed Poll (page10)</option>
          <option value="dpK">Deed Poll (page11)</option>
          <option value="dpL">Deed Poll (page12)</option>
      </select>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      <br>
note: <br>
If you have already uploaded a previous photo with the same name 
    it will be updated with the current photo.</label>
      <span class="selectRequiredMsg">Please select an item.</span></td>
    </tr>
<tr>  <input type=hidden name=MAX_FILE_SIZE value=150000>
				<td><input id="fileToUpload" type="file" size="45" name="fileToUpload" class="input"></td>			</tr>  <tr>
					<td><button class="button" id="buttonUpload"   onClick="return ajaxFileUpload();">Upload</button></td>
				</tr>
         

<tr>

   <td> 
     <p><a href="view_photos.php" target="_blank">view your uploaded photos</a></p>
      </td>
  </tr>

  
    <!----><tr>
    <td colspan="2">&nbsp;</td>
   </tr>
  <tr>
    
    <td>
       <input type='submit' value='Previous Page' onClick="MedicalInformation.action='addstudentinfo.php'; return true;">     
    <input id="submitbutton" name="submitbutton" type="SUBMIT" value='Continue to Step 3 of 5' />    </td>
</table>
         
</form>
          

<!-- End Save for Web Slices -->

</div>
</body>
</html>
