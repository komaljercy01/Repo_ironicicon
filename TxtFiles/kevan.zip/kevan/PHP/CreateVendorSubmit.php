<?php 
session_start();
?>
	
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
</head>
<body >
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;
$_SESSION['username_session'];


?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>

		  <p>
  <?php
		  
///Previous values///////////////



//Previous values///////////////////////
//////////CURRENT VALUES////////////////////////////
$vname = mysql_real_escape_string($_POST['vname']);
$VendorDesc = mysql_real_escape_string($_POST['VendorDesc']);
$VendorAcctname = mysql_real_escape_string($_POST['VendorAcctname']);		  		  
$Vadd = mysql_real_escape_string($_POST['Vadd']);
$vcity = mysql_real_escape_string($_POST['vcity']);

$VendorAcctname = mysql_real_escape_string($_POST['VendorAcctname']);
$ContactPerson = mysql_real_escape_string($_POST['ContactPerson']);
$vpemail = mysql_real_escape_string($_POST['vpemail']);
$vpcontact = mysql_real_escape_string($_POST['vpcontact']);
$vscontact = mysql_real_escape_string($_POST['vscontact']);
$vfax = mysql_real_escape_string($_POST['vfax']);
$vweb = mysql_real_escape_string($_POST['vweb']);
$cash = mysql_real_escape_string($_POST['cash']);
$ARacct = mysql_real_escape_string($_POST['ARacct']);
$vactive = $_POST['vactive'];
include 'config.php';
include 'opendb.php';


$SQL1 = " INSERT INTO vendor ( VendorName,VendorDesc, Vexpense,VendorCashAcct, VendorAdd,Vcity,  VendorPersonContact, VendorPContact,VendorSContact,  Vfax, VendorAcctname, VendorPEmail,  Vweb, Vtype, Vactive ) VALUES 

('".$vname."','".$VendorDesc."','".$ARacct."','".$cash."','".$Vadd."','".$vcity."','".$ContactPerson."','".$vpcontact."','".$vscontact."','".$vfax."','".$VendorAcctname."','".$vpemail."','".$vweb."','".""."','".$vactive."')" ;

$result1 = mysql_query($SQL1);
//echo $SQL1;

if (!$result1){
echo 'An Error has occurred please click here to go back to the previous form';
die();
}


  ?>
Success! You are being directed to Add a new Vendor in a few sconds.
If you wish to not wait, you can continue to 
<a href="create_vendor.php">here </a></p> 
		  <p><script>setTimeout('window.location.replace("create_vendor.php")', 1000);  </script> </p>
          </div>
</body>
</html>
