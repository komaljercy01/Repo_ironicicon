<footer>
	<div class="container">
		<p class="copy-right">
			Copyright &copy; 2015 Neuroflexyn. All Rights Reserved.
		</p>
		<div class="social-footer">
			<a href="https://www.facebook.com/neuroflexyn" target="_blank"><img src="images/ico-fb.png" /></a>
			<a href="https://twitter.com/neuroflexyn" target="_blank"><img src="images/ico-twitter.png" /></a>
			<a href="https://www.youtube.com/user/neuroflexyn" target="_blank"><img src="images/ico-youtube.png" /></a>
		</div>
		<div class="clearfix"></div>
		<div class="references">
			<p>References</p>
			<ol>
				<li><a href="http://www.ncbi.nlm.nih.gov/pubmed/351808">http://www.ncbi.nlm.nih.gov/pubmed/351808</a></li>
				<li><a href="https://www.neuroflexyn.com/pdf/choline.pdf">The relation of dietary choline to cognitive performance</a></li>
				<li><a href="http://www.ncbi.nlm.nih.gov/pubmed/11498727">http://www.ncbi.nlm.nih.gov/pubmed/11498727</a></li>
				<li><a href="http://wholehealthchicago.com/3378/dmae-dimethylaminoethanol/">http://wholehealthchicago.com/3378/dmae-dimethylaminoethanol/</a></li>
				<li><a href="http://www.ncbi.nlm.nih.gov/pubmed/23772955">http://www.ncbi.nlm.nih.gov/pubmed/23772955</a></li>
				<li><a href="http://www.ncbi.nlm.nih.gov/pubmed/16971751">http://www.ncbi.nlm.nih.gov/pubmed/16971751</a></li>
			</ol>
		</div>
	</div>
</footer>