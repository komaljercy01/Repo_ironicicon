<html> 
<head title="WOI"></head> 
<body> 

<table valign="middle" style="border: 1px #000000 solid; width: 100%; height: 100%">
<tr>
<td align="center">

<script language="javascript" src="../scripts/script.php">
</script>
	
<?php
include '../exam/config.php';
include '../exam/opendb.php';
include '../scripts/script.php';

$var = 2;

$formTitle = "ADD AN ACADEMIC BODY";
$submitCheck = false;
if ($_POST['submitCheck'] == true)
{  
	$orgName = mysql_real_escape_string(trim($_POST['orgName']));
	$orgDes = mysql_real_escape_string(trim($_POST['orgDes']));
	
	$err = false;
	$addSuccess = false;
	
// CHECK FOR ERRORS	
	if (empty($orgName))
	{	
		$notes .= 'Name cannot be left blank<br>';
		$err = true;
	}
	if (empty($orgDes))
	{
		$notes .= 'Description cannot be left blank<br>';
		$err = true;
	}
	if (strlen($orgDes) > 250)
	{	$desLen = strlen($orgDes);
		$notes .= 'The description can not exceed 250 characters (Currently '.$desLen.' characters long).';
		$err = true;
	}
	
	if ($err == false)
	{
		
		$que = "SELECT * FROM exambody WHERE (ORGNAME='$orgName')";
		$que = mysql_query($que);
		
		if ($row = mysql_fetch_array($que))
		{
			echo $row['ORGNAME'] .' already exists.';
		}
		else
		{
			$insertSta = "INSERT INTO exambody (ORGNAME, DESCRIPTION) VALUES ('$orgName', '$orgDes')";
			mysql_query($insertSta);
			
			$que = "SELECT * FROM exambody WHERE (ORGNAME='$orgName')";
			$que = mysql_query($que);
			$row = mysql_fetch_array($que);
			$row = $row['BODYID'];  
			
			echo "Academic Body Added Successfully";
			
			$formTitle = "ADD ANOTHER ACADEMIC BODY";
			$addSuccess = true;			
		}
	}
}
?>
		<table valign="middle" border="1" style="border: 1px #000000 solid; width: 100%; height: 20%;">
		<tr>
		<td align="left">
		
			<?php 	echo $formTitle;	?><br>
			<?php 	echo $notes;		?><br>

		</td>
		</tr>
		
		<form name="addBody" method="POST" action="addBody.php">
		
		<tr>
			<td align="left">
				Name: <input type="text" size="100" maxlength="50" id='oname' name="orgName" value="<?php echo $orgName; ?>" onBlur="amm()">
				
			<script>
			function amm()
			{
			<?php $var += 1;
			echo $var; ?>
			
			var egg = "BOILED"
			document.getElementById('hello').innerHTML="<?php checkThing($var) ?>";
			}
			</script>					
				
			</td>
		</tr>		
		<tr valign="top">
			<td align="left">
				Description: <textarea wrap="soft" rows="4" cols="50" name="orgDes"><?php echo $orgDes; ?></textarea>
				<span id="hello">
				MMmmm. Good, Thanks.
			</span>	
			</td>
		</tr>
		<tr>
			<td align="left">
				<input type="submit" name="bodySubmit" value="Add Academic Body">
				<input type="hidden" name="submitCheck" value="true">
			</form>
			</td>
		</tr>				
		<tr>
			<td>
				<hr color="black">
				<form name="listBodies" method="post" action="listBody.php">
				<input type="submit" name="viewBodies" value="View Current Academic Bodies">
			</form>	
<?php	if ($addSuccess == true)
		{	?>			
			<form name="addProgram" method="post" action="addProgram.php">
				<input type="submit" name="addPrgSumbit" value="Add Program">
				<input type="hidden" name="bodyId" value="<?php echo $row;?>">
			</form>	
			<form name="addYear" method="post" action="addYear.php">
				<input type="submit" name="addYearSumbit" value="Add Academic Year">
				<input type="hidden" name="bodyId" value="<?php echo $row;?>">
			</form>	
<?php	}	?>						
			</td>
		</tr>			
		</table>		
</td>
</tr>
</table>

</body> 
</html> 