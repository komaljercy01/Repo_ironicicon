<?php session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Create Batch</title>

    <link href="../CSS/Local.css" rel="stylesheet" type="text/css">
	
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
	<script src="../SpryAssets/SpryValidationRadio.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryValidationRadio.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="container">
<?php 
include 'config.php';
include 'opendb.php';

//$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];


$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){
$usertype_ = $row['USERTYPE'];
}

else {echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}
} // if($row=mysql_fetch_array($resultid))
else{
echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}

$username_get = $_GET['inputString'];

$username_post = $_POST['inputString'];
  
  if ($username_get==NULL){$username= $username_post;}
  if ($username_post==NULL){$username= $username_get;}   
         
  ?>  

  
                 
  <form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
<!--      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>-->
    </table></form>
    
    <table width="100%" border="0">
  <caption align="left">
    Menu
  </caption>
  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a> > 
   <?php

   if($usertype_ =='AA'){}

if($usertype_ =='MA'){}
   
   ?>    </td>
  </tr>
</table>

      <p ><span >Required fields are marked</span><span class="style1">*</span></p>

	
        <form id="acctinformation" name="acctinformation" action="create_fin_acct_submit.php"   method="post"  >
            <table cellpadding="2" bgcolor="white" cellspacing="0" border="0" width="99%">
        
                     

 </td>
  </tr>
  <tr>
<td colspan="2"><table border="0" cellspacing="5" cellpadding="0">
      
      <tr>
        <td><label >Account Name<span class="style1"></span></label></td>
        <td><span id="accttitle">
          <input name="accttitle" type="text" id="accttitle" value="" size="40">
          <span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldMinCharsMsg">Minimum of 2 characters not met.</span></span></td>
      </tr>
      

     
     

        <tr>
        <td><label >Account Description<span class="style1"></span></label></td>
        <td><span id="acctdes">
          <input name="acctdes" type="text" id="acctdes" value="" size="40">
          <span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldMinCharsMsg">Minimum of 2 characters not met.</span></span></td>
      </tr>
      
         <tr>
        <td><label >Active<span class="style1"></span></label></td>
        <td><span id="act">
        <select name="active" size="1">
          <option value="Yes">Yes
          <option value="No">No
          </select>
         </span></td>
      </tr>
           <tr>
        <td><label >Account Type<span class="style1"></span></label></td>
        <td><label for="accttype"></label>
          <select name="accttype" id="accttype">
          <?php 
		  $SQL1 = "Select ACCTYPE, ACCTDESC FROM ACCOUNTTYPE" ;
$result_SQL1 = mysql_query($SQL1);
while($row_result_SQL1=mysql_fetch_array($result_SQL1))
		  {
			  echo "<option value=".$row_result_SQL1['ACCTYPE'].">".$row_result_SQL1['ACCTDESC']."</option>";
			  
			  }
		  
		  
		  ?>
        
          </select></td>
      </tr>
      
 
 

  <tr>
  
    <td colspan="1" align="center">
  
    <input id="submitbutton" name="submitbutton" type="SUBMIT" value='Create Account' /></td>
  </tr>
                
                </table>
               
  </form>   

</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("bachtitle", "none", {minChars:2});
var spryradio1 = new Spry.Widget.ValidationRadio("spryradio1", {emptyValue:"You Must Select a Staus Value!"});
//-->
</script>
</div>
</body>
</html>
