
<?php 
session_start();
?>
	

<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script type="text/javascript" language="javascript" src="../jquery/js/jquery.js"></script> 
<script type="text/javascript" src="../scripts/jquery-1.4.2.js"></script> 

<link rel="stylesheet" href="../CSS/style.css" />
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">

<link type="text/css" href="../css/jquery.ui.all.css" rel="stylesheet" />

<script type="text/javascript" src="../scripts/jquery.ui.core.js"></script> 
<script type="text/javascript" src="../scripts/jquery.ui.widget.js"></script>  
<script type="text/javascript" src="../scripts/jquery.ui.datepicker.js"></script>

<script src="../scripts/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../jquery/js/jquery.jeditable.js" type="text/javascript" charset="utf-8"></script>


 
<script type="text/javascript" charset="utf-8">

			$(document).ready(function() {
				
				$('#myform').submit( function() {
		var sData = $('input', oTable.fnGetNodes()).serialize();
		alert( "The following data would have been submitted to the server: \n\n"+sData );
		return false;
	} );
			
				
							
				/* Apply the jEditable handlers to the table */
				$('.td_edit').editable( 'update_receipt_details.php', {
					indicator : '<img src="../images/indicator.gif">',
					type   : 'textarea',
					select : true,
					submit : 'Update',
					cssclass : "editable"
				});
				
				
		
				
				
});

</script>



<script type="text/javascript">
	function lookup(inputString) {
		if(inputString.length == 0) {
			// Hide the suggestion box.
			$('#suggestions').hide();
		} else {
			$.post("rpc_stu.php", {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$('#suggestions').show();
					$('#autoSuggestionsList').html(data);
				}
			});
		}
	} // lookup
	
	function fill(thisValue) {
		$('#inputString').val(thisValue);
		setTimeout("$('#suggestions').hide();", 200);
	}
</script>

<style type="text/css">

	.suggestionsBox {
		position: relative;
		left: 30px;
		margin: 10px 0px 0px 0px;
		width: 200px;
		background-color: #212427;
		-moz-border-radius: 7px;
		-webkit-border-radius: 7px;
		border: 2px solid #000;	
		color: #fff;
	}
	
	.suggestionList {
		margin: 0px;
		padding: 0px;
	}
	
	.suggestionList li {
		
		margin: 0px 0px 3px 0px;
		padding: 3px;
		cursor: pointer;
	}
	
	.suggestionList li:hover {
		background-color: #659CD8;
	}
</style>


<script type="text/javascript"> 
	$(function() {
		$("#date1").datepicker();
	});
	</script> 

<script type="text/javascript"> 
	$(function() {
		$("#date2").datepicker();
	});
	</script> 

        
<head>
</head>
  
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];

 $query4="select  USERTYPE from user where  USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'";
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$usertype = $row['USERTYPE'];
}



$SQLuserid = "select  * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}
else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>
<body id="dt_example">
		<div id="container">
		
	

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>

<?php 
$date1 = $_POST['date1'];
$date2 = $_POST['date2'];

if($date1==NULL){$date1="2009-01-01";}
if($date2==NULL){$date2=  date("Y-m-d");}
$userrange = $_POST['inputString'];
if($userrange==''){$userrange="BETWEEN 'zzzz' AND 'zzzz'";}
?>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" >
    <table width="200" border="1">
  <tr>    <td>Date 1</td>    <td><input name="date1" id="date1" type="text" size="10" maxlength="10" value=<?php echo $date1?>></td> 
  
  
  
  <td rowspan="3">
  
</td> 
  
  
  
  
  
  
  </tr>
   <tr>    <td>Date 2</td>    <td><input name="date2" id="date2" type="text" size="10" maxlength="10" value=<?php echo $date2?> ></td>  </tr>
   <tr><td> Username</td> <td>

       		
				<select name="inputString">
                <option value='<?php echo $inputString_post;?>'><?php echo $inputString_post;?></option>
	

<option value="username >= 'aa' AND username <  'an'" >aa - am</option>
<option value="username >= 'an' AND username <  'ba'" >an - az</option>
<option value="username >= 'ba' AND username <  'bn'" >ba - bm</option>
<option value="username >= 'bn' AND username <  'ca'" >bn - bz</option>
<option value="username >= 'ca' AND username <  'cn'" >ca - cm</option>
<option value="username >= 'cn' AND username <  'da'" >cn - az</option>
<option value="username >= 'da' AND username <  'dn'" >da - dm</option>
<option value="username >= 'dn' AND username <  'ea'" >dn - dz</option>
<option value="username >= 'ea' AND username <  'en'" >ea - em</option>
<option value="username >= 'en' AND username <  'fa'" >en - ez</option>
<option value="username >= 'fa' AND username <  'fn'" >fa - fm</option>
<option value="username >= 'fn' AND username <  'ga'" >fn - fz</option>
<option value="username >= 'ga' AND username <  'gn'" >ga - gm</option>
<option value="username >= 'gn' AND username <  'ha'" >gn - gz</option>
<option value="username >= 'ha' AND username <  'hn'" >ha - hm</option>
<option value="username >= 'hn' AND username <  'ia'" >hn - hz</option>
<option value="username >= 'ia' AND username <  'in'" >ia - im</option>
<option value="username >= 'in' AND username <  'ja'" >in - iz</option>
<option value="username >= 'ja' AND username <  'jn'" >ja - jm</option>
<option value="username >= 'jn' AND username <  'ka'" >jn - jz</option>
<option value="username >= 'ka' AND username <  'kn'" >ka - km</option>
<option value="username >= 'kn' AND username <  'la'" >kn - kz</option>
<option value="username >= 'la' AND username <  'ln'" >la - lm</option>
<option value="username >= 'ln' AND username <  'ma'" >ln - lz</option>
<option value="username >= 'ma' AND username <  'mn'" >ma - mm</option>
<option value="username >= 'mn' AND username <  'na'" >mn - mz</option>
<option value="username >= 'na' AND username <  'nn'" >na - nm</option>
<option value="username >= 'nn' AND username <  'oa'" >nn - nz</option>
<option value="username >= 'oa' AND username <  'on'" >oa - om</option>
<option value="username >= 'on' AND username <  'pa'" >on - oz</option>
<option value="username >= 'pa' AND username <  'pn'" >pa - pm</option>
<option value="username >= 'pn' AND username <  'qa'" >pn - pz</option>
<option value="username >= 'qa' AND username <  'qn'" >qa - qm</option>
<option value="username >= 'qn' AND username <  'ra'" >qn - qz</option>
<option value="username >= 'ra' AND username <  'rn'" >ra - rm</option>
<option value="username >= 'rn' AND username <  'sa'" >ra - rz</option>
<option value="username >= 'sa' AND username <  'sn'" >sa - sm</option>
<option value="username >= 'sn' AND username <  'ta'" >sa - sz</option>
<option value="username >= 'ta' AND username <  'tn'" >ta - tm</option>
<option value="username >= 'tn' AND username <  'ua'" >ta - tz</option>
<option value="username >= 'ua' AND username <  'un'" >ua - um</option>
<option value="username >= 'un' AND username <  'va'" >un - uz</option>
<option value="username >= 'va' AND username <  'vn'" >va - vm</option>
<option value="username >= 'vn' AND username <  'ua'" >vn - vz</option>
<option value="username >= 'wa' AND username <  'un'" >wa - wm</option>
<option value="username >= 'wn' AND username <  'wa'" >wn - wz</option>
<option value="username >= 'xa' AND username <  'wn'" >xa - xm</option>
<option value="username >= 'xn' AND username <  'xa'" >xn - xz</option>
<option value="username >= 'ya' AND username <  'xn'" >ya - ym</option>
<option value="username >= 'yn' AND username <  'ya'" >yn - yz</option>
<option value="username >= 'za' AND username <  'yn'" >za - zm</option>
<option value="username >= 'zn' AND username <  'zzzz'">zn -zz</option>

<!--
-->

	</select>
          </td></tr>
   <tr><td colspan="2"><input name="submit" type="submit" value="submit"></td></tr>
</table>

    </form>
    






	<table border="1"><thead>
    		<tr>
              <th>Customer Name </th>
            <th>Cusid </th>
            	<th >DATE</th>
                <th >TYPE</th>
                <th >Application ID </th>
		
        <th >Memo Number</th>
                <th >Invoice Number</th>
                <th >Receipt Number </th>
                <th >Description </th>
                <th >Amount student (CTS)</th>
                <th >Balance student (CTS)</th>
                 <th >Amount Ministry</th>
                 <th >Amount student (nonCTS)</th>
                <th >Balance student (nonCTS)</th>
                </tr>
    </thead>
    <tbody>
    
<?php
$quer_usersfor_course=mysql_query("SELECT USERNAME ,  email , USERTYPE FROM user WHERE $userrange
and USERTYPE ='DEF' 
ORDER BY USERNAME

");  

while($noticia = mysql_fetch_array($quer_usersfor_course)) {
	$inputString_post= $noticia['USERNAME'];
echo $inputString_post;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$openbalance="SELECT  USER.USERID, USER.USERNAME, 
STUDENT.BALANCE, STUDENT.USERID , STUDENT.FIRSTNAME , STUDENT.LASTNAME


FROM
USER, STUDENT

WHERE
USER.USERNAME ='$inputString_post' AND 
USER.USERID= STUDENT.USERID 
ORDER by  USER.USERNAME
";
$result_openbalance= mysql_query($openbalance);

while ($row_result_openbalance = mysql_fetch_assoc($result_openbalance)) {
$openbalance_amount= $row_result_openbalance['BALANCE'];
$subtotal_per_user = $openbalance_amount; 
$firstname= $row_result_openbalance['FIRSTNAME'];
$lastname= $row_result_openbalance['LASTNAME'];
$Customerid= $row_result_openbalance['USERID'];
$openbalance_amount_nonCTS= 0;
}


///////////////////////////////////////////////GATE OPEN BALANCE////////////////////////////////////////////////////////////////////
$openbalmin_inv_query="SELECT
USER.USERID, USER.USERNAME, 
STUDENT.BALANCE, INVOICE.INVNUMID, 
INVOICE.AMOUNT_INV,INVOICE.AMOUNT_REG ,
INVOICE.APPLICATIONID,INVOICE.DATE_INV,
APPLICATION.APPLICATIONID, APPLICATION.USERID, COURSEAPP.GATE_REQUEST, COURSEAPP.GATE_AMOUNT,COURSEAPP.APPLICATIONID, COURSEAPP.COID , COURSEAPP.CASTATUS, COURSEOFFERING.COID, COURSEOFFERING.COST, COURSEOFFERING.COURSEID, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY
FROM
USER, STUDENT,  INVOICE, APPLICATION, COURSEAPP , COURSEOFFERING , COURSE , PROGRAM

WHERE

USER.USERNAME ='$inputString_post' AND 
USER.USERID= STUDENT.USERID AND
COURSEAPP.GATE_REQUEST='Y' AND 
COURSEOFFERING.COURSEID=  COURSE.COURSEID AND
COURSE.PROGRAMID =  PROGRAM.PROGRAMID AND

APPLICATION.USERID = USER.USERID AND
INVOICE.APPLICATIONID= APPLICATION.APPLICATIONID AND
APPLICATION.APPLICATIONID= COURSEAPP.APPLICATIONID AND
COURSEAPP.COID = COURSEOFFERING.COID AND
(INVOICE.DATE_INV >= '2009-01-01' and  INVOICE.DATE_INV < '$date1')
ORDER by 
INVOICE.DATE_INV";
//where date >= '2005-01-01' and date <= '2005-01-31'

$result_openbalmin_inv_query= mysql_query($openbalmin_inv_query);
$openbalance_amount_min=0;
while ($row_result_openbalmin_inv_query= mysql_fetch_assoc($result_openbalmin_inv_query)) {
$openbalance_amount_min += $row_result_openbalmin_inv_query['GATE_AMOUNT'];
}
/////////////////////////////////////////////GATE OPEN BALANCE END/////////////////////////////////////////////////////////////////

$openbal_inv_query="SELECT
USER.USERID, USER.USERNAME, 
STUDENT.BALANCE, INVOICE.INVNUMID, 
INVOICE.AMOUNT_INV , INVOICE.AMOUNT_REG,

INVOICE.APPLICATIONID,INVOICE.DATE_INV,
APPLICATION.APPLICATIONID, APPLICATION.USERID


FROM
USER, STUDENT,  INVOICE, APPLICATION

WHERE
USER.USERNAME ='$inputString_post' AND 
USER.USERID= STUDENT.USERID AND

APPLICATION.USERID = USER.USERID AND
INVOICE.APPLICATIONID= APPLICATION.APPLICATIONID AND
(INVOICE.DATE_INV >= '2009-01-01' and  INVOICE.DATE_INV < '$date1')
ORDER by 
INVOICE.DATE_INV";
//where date >= '2005-01-01' and date <= '2005-01-31'

$result_openbal_inv_query= mysql_query($openbal_inv_query);

while ($row_result_openbal_inv_query = mysql_fetch_assoc($result_openbal_inv_query)) {
$openbalance_amount=  $openbalance_amount + $row_result_openbal_inv_query['AMOUNT_INV'] +  $row_result_openbal_inv_query['AMOUNT_REG'];
$subtotal_per_user = $openbalance_amount; 

}



$openbal_rec_query="SELECT USER.USERID , USER.USERNAME, STUDENT.BALANCE, RECEIPT.USERID, 

RECEIPT.RECNUMID, RECEIPT.AMOUNT, RECEIPT.DATE, RECEIPT.RECSTATUS ,

APPLICATION.APPLICATIONID, APPLICATION.USERID
FROM USER, STUDENT, RECEIPT, APPLICATION
WHERE 
USER.USERNAME ='$inputString_post' AND 
USER.USERID = STUDENT.USERID

AND RECEIPT.USERID = USER.USERID
AND RECEIPT.USERID = STUDENT.USERID
AND APPLICATION.USERID = USER.USERID
AND (RECEIPT.DATE   >=  '2009-01-01'  and  RECEIPT.DATE <  '$date1')
AND RECEIPT.RECSTATUS='VAL'
GROUP BY   RECEIPT.RECNUMID";

// (INVOICE.DATE_INV >= '2009-01-01' and  INVOICE.DATE_INV <= '$date1')
$result_openbal_rec_query= mysql_query($openbal_rec_query);

while ($row_result_openbal_rec_query = mysql_fetch_assoc($result_openbal_rec_query)) {
$openbalance_amount=  $openbalance_amount - $row_result_openbal_rec_query['AMOUNT'];
$APPNUM=  $row_result_openbal_rec_query['APPLICATIONID'];
$subtotal_per_user = $openbalance_amount; 

}


/////////////////////////////////////////////////////////create temp table//////////////////////////////////////////////////
include 'config.php';
include 'opendb.php';

$alphanum = "abcdefghijkmnpqrstuvwxyz";
  
$TEMP_TBL = substr(str_shuffle($alphanum), 0, 5);  // 5 Being the amount of letters/numbers are select from the variable alphanum
$TEMP_TBL ="_".$TEMP_TBL;
//$TEMP_TBL = rand();

$create_temp_tbl = "CREATE TABLE ".$TEMP_TBL."(
`CUSID` INT( 11 ) NOT NULL ,
`DATE` TIMESTAMP NOT NULL ,  INDEX (DATE),
`APPNUM` INT( 11 ) NULL DEFAULT '0',
`MEMONUM` INT( 11 ) NULL DEFAULT '0',
`INVNUM` INT( 11 ) NULL DEFAULT '0',
`RECNUM` INT( 11 ) NULL DEFAULT '0',
`DESCRIPTION` VARCHAR( 500) NULL DEFAULT 'NULL',
`AMOUNT` DOUBLE NOT NULL ,
`REGAMOUNT` DOUBLE NOT NULL ,
`GATEAMOUNT` DOUBLE NOT NULL ,
`MIN_AMT` DOUBLE NOT NULL  , 
`sales_accnum` DOUBLE NOT NULL  , 
`gate_accnum` DOUBLE NOT NULL  , 
`memo_accnum` DOUBLE NOT NULL  ,
`misInv_accnum` DOUBLE NOT NULL  ,
`recpt_accnum` DOUBLE NOT NULL , 
`discnt_accnum` DOUBLE NOT NULL  
) ENGINE = InnoDB 
";
mysql_query($create_temp_tbl);
/////////////////////////////////////////////////////////create temp table// END////////////////////////////////////////////////
/////////////////////////////////////////////////////////////INSERT INVOICE VALUES////////////////////////////////////////////////
$invoice_query="SELECT
USER.USERID, USER.USERNAME, 
STUDENT.BALANCE, INVOICE.INVNUMID, 
INVOICE.AMOUNT_INV,INVOICE.AMOUNT_REG , 

INVOICE.APPLICATIONID,INVOICE.DATE_INV,
APPLICATION.APPLICATIONID, APPLICATION.USERID, COURSEAPP.GATE_REQUEST,COURSEAPP.APPLICATIONID, COURSEAPP.COID , COURSEAPP.CASTATUS, COURSEOFFERING.COID, COURSEOFFERING.COST, COURSEOFFERING.COURSEID, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY, INVOICE.INV_ACTIVE,
REGFEE.CATEGORY , REGFEE.REGFEE ,  COURSE.ACCTID_sales, COURSE.ACCTID_sales_gate
FROM
USER, STUDENT,  INVOICE, APPLICATION, COURSEAPP , COURSEOFFERING , COURSE , PROGRAM , REGFEE
WHERE
USER.USERNAME ='$inputString_post' AND 
USER.USERID= STUDENT.USERID AND
COURSEOFFERING.COURSEID=  COURSE.COURSEID AND
COURSE.PROGRAMID =  PROGRAM.PROGRAMID AND
APPLICATION.USERID = USER.USERID AND
INVOICE.APPLICATIONID= APPLICATION.APPLICATIONID AND
PROGRAM.CATEGORY = REGFEE.CATEGORY AND
APPLICATION.APPLICATIONID= COURSEAPP.APPLICATIONID AND
COURSEAPP.COID = COURSEOFFERING.COID
AND
INVOICE.INV_ACTIVE='1'
ORDER by 
INVOICE.DATE_INV";

$result_invoice_query = mysql_query($invoice_query);
$reg_count = 1;
while ($row = mysql_fetch_assoc($result_invoice_query)) {
$cus_id = $row['USERID'];
$invdate   =$row['DATE_INV'];
$invnum = $row['INVNUMID'];
$regamt = $row['AMOUNT_REG']  ; 
$APPNUM = $row['APPLICATIONID']  ; 
$ACCTID_sales = $row['ACCTID_sales']  ; 
$ACCTID_sales_gate = $row['ACCTID_sales_gate']  ; 
//////////////////////////////////////////////////////////////////gate amount/////////////////////////////////////////////////////////
	 $catergory = $row['CATEGORY']; 
	// $coursecost = $row_result_coid_amt_table['COST']; 
/////////////////////////if Gate request = Y//////////////////////////////////////////////////
if($row['GATE_REQUEST']=='Y'){	
 if ( $catergory == "TER1" || $catergory == "TER2" || $catergory == "TER3" || $catergory == "TER4"){
	$gateamt = $gateamt +  $row['COST'];
	$stuamt = $stuamt + 0;
	}
	if($catergory == "TER5" || $catergory == "TER6" ){
		$gateamt = $gateamt +  $row['COST']*0.5;
		$stuamt = $stuamt + $row['COST']*0.5;
		}
 if ($catergory != "TER1" && $catergory != "TER2" && $catergory != "TER3" && $catergory != "TER4" && $catergory != "TER5" && $catergory != "TER6"  ){
	 $gateamt = $gateamt +   0 ;
	$stuamt = $stuamt + $row['COST'] ;
	$regamt = $row['REGFEE'] 	;		 //regfee not 0 

	 }  
 } //if($row_result_coid_amt_table['GATE_REQUEST']=='Y'){	

 else {
if ($catergory != "TER1" && $catergory != "TER2" && $catergory != "TER3" && $catergory != "TER4" && $catergory != "TER5" && $catergory != "TER6"  ){
	 $gateamt = $gateamt +   0 ;
	$stuamt = $stuamt + $row['COST'] ;
	$regamt = $row['REGFEE'] 	;  //regfee not 0 
	 }  
	 else { // Gate not requested
		$gateamt = 0;
	$stuamt = $stuamt + $row['COST'] ; 
		 }
	 //else Gate not requested and it is a teriary course
	} 
/////////////////////////////////////////////////////////////////gate amount///END//////////////////////////////////////////////////////	
///////////////////////////////////////////query for courses in invoice////////////////////////////////////////////////////////////

$description = $row['COURSETITLE']." , " ;
///////////////////////////////////////////query for courses in invoice//end//////////////////////////////////////////////////////////
//$regamt = $regamt/$reg_count; 
 //= $row['APPLICATIONID']  ; 
 
 /*
 `sales_accnum` DOUBLE NOT NULL  , 
`gate_accnum` DOUBLE NOT NULL  , 
`memo_accnum` DOUBLE NOT NULL  ,
`misInv_accnum` DOUBLE NOT NULL  ,
`recpt_accnum` DOUBLE NOT NULL  
$ACCTID_sales = $row['ACCTID_sales']  ; 
$ACCTID_sales_gate = $row['ACCTID_sales_gate']  ; 
*/
$insert_temp_values = "INSERT INTO ".$TEMP_TBL."
(CUSID, DATE, APPNUM, MEMONUM,INVNUM, RECNUM, DESCRIPTION, AMOUNT , REGAMOUNT, GATEAMOUNT , MIN_AMT, sales_accnum , gate_accnum , memo_accnum , misInv_accnum , recpt_accnum  ,discnt_accnum)
VALUES
('$cus_id','$invdate', '$APPNUM','0','$invnum', '0','$description','$stuamt','$regamt','$gateamt' , '0' ,'$ACCTID_sales' ,  '$ACCTID_sales_gate' ,'0'  ,'0' ,'0' ,'0' )
";
mysql_query($insert_temp_values);
$description="";
$stuamt= 0 ; 
$gateamt =0;
 
}


//////////////////////////////////////////////////////////INSERT INVOICE VALUES/ END////////////////////////////////////////////
/////////////////////////////////////////////////////////////INSERT MISCELLANOUS INVOICE///////////////////////////////////////
$mis_invoice_query="SELECT
USER.USERID, USER.USERNAME, 
INVOICE_ITEMS.INV_ITEM_ID , INVOICE_ITEMS.UID , 
INVOICE_ITEMS.DATE_INV ,INVOICE_ITEMS.AMT_INV  , INVOICE_ITEMS.INV_CR,  
INVOICE_ITEMS.DETAILS ,INVOICE_ITEMS.INV_ACTIVE

FROM
USER, INVOICE_ITEMS
WHERE
USER.USERNAME ='$inputString_post' AND 
USER.USERID= INVOICE_ITEMS.UID  AND
INVOICE_ITEMS.INV_ACTIVE='1'
ORDER by 
INVOICE_ITEMS.DATE_INV ";

$result_mis_invoice_query = mysql_query($mis_invoice_query);

while ($row = mysql_fetch_assoc($result_mis_invoice_query)) {
$cus_id = $row['USERID'];
$invdate   =$row['DATE_INV'];
$invnum = $row['INV_ITEM_ID'];
$stuamt = $row['AMT_INV'];
$description = $row['DETAILS'];
$INV_CR = $row['INV_CR'];

 /*
 `sales_accnum` DOUBLE NOT NULL  , 
`gate_accnum` DOUBLE NOT NULL  , 
`memo_accnum` DOUBLE NOT NULL  ,
`misInv_accnum` DOUBLE NOT NULL  ,
`recpt_accnum` DOUBLE NOT NULL  
$ACCTID_sales = $row['ACCTID_sales']  ; 
$ACCTID_sales_gate = $row['ACCTID_sales_gate']  ; 
*/

$insert_temp_values = "INSERT INTO ".$TEMP_TBL."
(CUSID, DATE, APPNUM, MEMONUM,INVNUM, RECNUM, DESCRIPTION, AMOUNT , REGAMOUNT, GATEAMOUNT , MIN_AMT ,sales_accnum , gate_accnum , memo_accnum , misInv_accnum , recpt_accnum , discnt_accnum  )
VALUES
('$cus_id','$invdate', '0','0','$invnum', '0','$description','$stuamt','0','0' , '0'     ,'0' ,'0','0','$INV_CR','0' ,'0')
";
mysql_query($insert_temp_values);
$description="";
$stuamt= 0 ; 

 
}


////////////////////////////////////////////////////////////INSERT  miscellous invoice end//////////////////////////////////////
/////////////////////////////////////////////////////////////INSERT MEMO VALUES////////////////////////////////////////////////
$memo_query="SELECT
USER.USERID, USER.USERNAME, 
STUDENT.BALANCE, INVOICE.INVNUMID, 
INVOICE.AMOUNT_INV,INVOICE.AMOUNT_REG , 
INVOICE.APPLICATIONID,INVOICE.DATE_INV,
APPLICATION.APPLICATIONID, APPLICATION.USERID, COURSEAPP.GATE_REQUEST,COURSEAPP.APPLICATIONID, COURSEAPP.COID, COURSEAPP.CASTATUS,  COURSEOFFERING.COID, COURSEOFFERING.COST, COURSEOFFERING.COURSEID, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , COURSE.ACCTID_sales, COURSE.ACCTID_sales_gate  , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY, MEMO.MEMOID, MEMO.MEMO_AMOUNT, MEMO.MIN_AMOUNT , MEMO.INVID , DEREGISTRATION.MEMOID , DEREGISTRATION.DATE_TRANS,  DEREGISTRATION.DATE_DEREG , MEMO.MEMO_ACTIVE 
FROM
USER, STUDENT,  INVOICE, APPLICATION, COURSEAPP , COURSEOFFERING , COURSE , PROGRAM, MEMO , DEREGISTRATION
WHERE
COURSEAPP.CASTATUS='DER' AND
USER.USERNAME ='$inputString_post' AND 
USER.USERID= STUDENT.USERID AND
MEMO.MEMOID =  DEREGISTRATION.MEMOID  AND
COURSEOFFERING.COURSEID=  COURSE.COURSEID AND
COURSE.PROGRAMID =  PROGRAM.PROGRAMID AND
INVOICE.INVNUMID =  MEMO.INVID AND
APPLICATION.USERID = USER.USERID AND
INVOICE.APPLICATIONID= APPLICATION.APPLICATIONID AND
APPLICATION.APPLICATIONID= COURSEAPP.APPLICATIONID AND
COURSEAPP.COID = COURSEOFFERING.COID AND
MEMO.MEMO_ACTIVE = '1'
GROUP bY MEMO.MEMOID
ORDER by 
INVOICE.DATE_INV";

$result_memo_query = mysql_query($memo_query);
$reg_count = 1;
while ($row_result_memo_query = mysql_fetch_assoc($result_memo_query)) {

$invid_memo = $row_result_memo_query['INVID'];
$cus_id = $row_result_memo_query['USERID'];
$memodate   =$row_result_memo_query['DATE_DEREG'];
$memoid = $row_result_memo_query['MEMOID'];
$memoamt = $row_result_memo_query['MEMO_AMOUNT']  ; 
$minamt = $row_result_memo_query['MIN_AMOUNT']  ; 
$APPNUM = $row_result_memo_query['APPLICATIONID']  ; 
$ACCTID_memo = $row_result_memo_query['ACCTID_sales']  ; 
$ACCTID_memo_gate = $row_result_memo_query['ACCTID_sales_gate']  ; 
$memoamt_calc  = $memoamt* -1 ;
$minamt_calc  = $minamt* -1 ;

//////////////////////////////////////////////////////////////////gate amount/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////gate amount///END//////////////////////////////////////////////////////	
///////////////////////////////////////////query for courses in invoice////////////////////////////////////////////////////////////
////////////////////////////////////DESCRIPTION DETAILSSSSSSSSSSSSSSS?????????????//////////////////////////////////
$memo_details_query="SELECT
USER.USERID, USER.USERNAME, 
STUDENT.BALANCE, INVOICE.INVNUMID, 
INVOICE.AMOUNT_INV,INVOICE.AMOUNT_REG , 
INVOICE.APPLICATIONID,INVOICE.DATE_INV,
APPLICATION.APPLICATIONID, APPLICATION.USERID, COURSEAPP.GATE_REQUEST,COURSEAPP.APPLICATIONID, COURSEAPP.COID, COURSEAPP.CASTATUS,  COURSEOFFERING.COID, COURSEOFFERING.COST, COURSEOFFERING.COURSEID, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY, MEMO.MEMOID, MEMO.MEMO_AMOUNT ,MEMO.MIN_AMOUNT , MEMO.INVID , DEREGISTRATION.MEMOID , DEREGISTRATION.DATE_DEREG 
FROM
USER, STUDENT,  INVOICE, APPLICATION, COURSEAPP , COURSEOFFERING , COURSE , PROGRAM, MEMO , DEREGISTRATION
WHERE
COURSEAPP.CASTATUS='DER' AND
USER.USERNAME ='$inputString_post' AND 
USER.USERID= STUDENT.USERID AND
MEMO.MEMOID =  DEREGISTRATION.MEMOID  AND
MEMO.MEMOID = '$memoid' AND
COURSEOFFERING.COURSEID=  COURSE.COURSEID AND
COURSE.PROGRAMID =  PROGRAM.PROGRAMID AND
INVOICE.INVNUMID =  MEMO.INVID AND
 MEMO.INVID = '$invid_memo' AND
APPLICATION.USERID = USER.USERID AND
INVOICE.APPLICATIONID= APPLICATION.APPLICATIONID AND
APPLICATION.APPLICATIONID= COURSEAPP.APPLICATIONID AND
COURSEAPP.COID = COURSEOFFERING.COID
ORDER by 
MEMO.MEMOID";

$result_memo_details_query = mysql_query($memo_details_query);
while ($row_result_memo_details_query = mysql_fetch_assoc($result_memo_details_query)) {
	$description .= $row_result_memo_details_query['COURSETITLE']." , " ;}


///////////////////////////////////////////////////DESCRIPTION DETAILS END////////////////////////////////////
///////////////////////////////////////////query for courses in invoice//end//////////////////////////////////////////////////////////
//$regamt = $regamt/$reg_count; 
//$ACCTID_memo 
// $ACCTID_memo_gate

$insert_temp_values = "INSERT INTO ".$TEMP_TBL."
(CUSID, DATE, APPNUM,MEMONUM,INVNUM, RECNUM, DESCRIPTION, AMOUNT , REGAMOUNT, GATEAMOUNT, MIN_AMT ,sales_accnum , gate_accnum , memo_accnum , misInv_accnum , recpt_accnum ,discnt_accnum )
VALUES
('$cus_id','$memodate','$APPNUM', '$memoid','$invid_memo', '0','$description','$memoamt_calc','0','0' , '$minamt_calc'    ,'0' ,'$ACCTID_memo_gate' ,'$ACCTID_memo' ,'0' ,'0' ,'0' )
";
mysql_query($insert_temp_values);
$description="";
$stuamt= 0 ; 
$gateamt =0;
echo mysql_error(); 
}


//////////////////////////////////////////////////////////INSERT MEMO VALUES/ END////////////////////////////////////////////
/////////////////////////////////////////////////////////////INSERT Receipt  VALUES/// ///////////////////////////////////////////
$receipt_query="SELECT USER.USERID , USER.USERNAME, STUDENT.BALANCE, RECEIPT.USERID, 
RECEIPT.RECNUMID, RECEIPT.AMOUNT, RECEIPT.DATE,  RECEIPT.REP_DETAILS, RECEIPT.DISCOUNT_AMT , RECEIPT.REC_CR , RECEIPT.DISCOUNT_ACCT ,
APPLICATION.APPLICATIONID, APPLICATION.USERID, RECEIPT.RECSTATUS
FROM USER, STUDENT, RECEIPT, APPLICATION
WHERE 
USER.USERNAME ='$inputString_post' 
AND USER.USERID = STUDENT.USERID
AND RECEIPT.USERID = USER.USERID
AND RECEIPT.USERID = STUDENT.USERID
AND APPLICATION.USERID = USER.USERID
AND RECEIPT.RECSTATUS='VAL'
GROUP BY   RECEIPT.RECNUMID
";
$result_receipt_query = mysql_query($receipt_query);

if(mysql_num_rows($result_receipt_query)==0){
$receipt_query="SELECT USER.USERID , USER.USERNAME, RECEIPT.USERID, 
RECEIPT.RECNUMID, RECEIPT.AMOUNT, RECEIPT.DATE,  RECEIPT.REP_DETAILS, RECEIPT.DISCOUNT_AMT  , RECEIPT.REC_CR , RECEIPT.DISCOUNT_ACCT ,RECEIPT.RECSTATUS
FROM USER, RECEIPT
WHERE 
USER.USERNAME ='$inputString_post'   
AND RECEIPT.USERID = USER.USERID
AND RECEIPT.RECSTATUS='VAL'
";
}
	else{}
$result_receipt_query = mysql_query($receipt_query);
while ($row = mysql_fetch_assoc($result_receipt_query)) {
$cus_id= $row['USERID'] ;
$recdate = $row['DATE'];
$rec_num = $row['RECNUMID'];
$recamt = $row['AMOUNT'];
$description=$row['REP_DETAILS'];
$discount_amt= $row['DISCOUNT_AMT'];
$REC_CR= $row['REC_CR'];
$DISCOUNT_ACCT= $row['DISCOUNT_ACCT'];
///////////////////////////////////////////query for courses receipt details////////////////////////////////////////////////////////////

///////////////////////////////////////////query for courses receipt details/end//////////////////////////////////////////////////////////
$insert_temp_values = "INSERT INTO ".$TEMP_TBL."
(CUSID, DATE, MEMONUM,INVNUM, RECNUM, DESCRIPTION,AMOUNT,REGAMOUNT,GATEAMOUNT, MIN_AMT  ,sales_accnum , gate_accnum , memo_accnum , misInv_accnum , recpt_accnum ,discnt_accnum )
VALUES
('$cus_id', '$recdate','0', '0', '$rec_num','$description','$recamt','0','0' , '0'   ,'0' ,'0' ,'0','0' ,'$REC_CR' ,'$DISCOUNT_ACCT' )
";
mysql_query($insert_temp_values);
$description="&nbsp;";

$insert_temp_values = "INSERT INTO ".$TEMP_TBL."
(CUSID, DATE, MEMONUM,INVNUM, RECNUM, DESCRIPTION,AMOUNT,REGAMOUNT,GATEAMOUNT , MIN_AMT  ,sales_accnum , gate_accnum , memo_accnum , misInv_accnum , recpt_accnum ,discnt_accnum )
VALUES
('$cus_id', '$recdate','0', '0', '$rec_num','$description','$discount_amt','0','0' , '0'  ,'0' ,'0' ,'0','0' ,'$REC_CR' ,'$DISCOUNT_ACCT' )
";
mysql_query($insert_temp_values);
$description="&nbsp;";


}
/////////////////////////////////////////////////////////////INSERT Receipt VALUES/// END////////////////////////////////////////////
////////////////////////////////////////////////////////open balance//////////////////////////////////////////////
echo "<tr>";
echo"<td colspan='8' align='left'>";
echo "Opening Balance ";
echo "</td>";
echo "<td>&nbsp;";
echo "</td>";
echo"<td>";
echo  $openbalance_amount;  
echo "</td>";
echo"<td>";

echo "</td>";
echo"<td>";
echo  $openbalance_amount_min;
echo "</td>";
echo"</tr>";
////////////////////////////////////////////////////////open balance///END///////////////////////////////////////////
/////////////////////////////////////////////////////////////ARRANGE VALUES/////////////////////////////////////////////////
$arrange_group =mysql_query ("Select * from  ".$TEMP_TBL." 
where
DATE BETWEEN '$date1' and '$date2'
GROUP by INVNUM, RECNUM , MEMONUM
ORDER by DATE

 ");
 echo "<form name='statement' action='statment_create.php'  method='post' target='_new' > ";

// echo mysql_error();
echo mysql_error();
while ($row_arrange_group = mysql_fetch_assoc($arrange_group) ) {
$inv_group = $row_arrange_group['INVNUM'];
$rec_group = $row_arrange_group['RECNUM'];	
$memo_group = $row_arrange_group['MEMONUM'];	

$arrange=mysql_query ("Select * from  ".$TEMP_TBL."
where
DATE BETWEEN '$date1' and '$date2' AND( INVNUM='$inv_group' AND RECNUM='$rec_group'  AND MEMONUM='$memo_group' ) ORDER by DATE");

 $regamt= 0;
 $count= 1; 
 while ($row_arrange = mysql_fetch_assoc($arrange) ) {
echo mysql_error();
//$invnum_tally = $row_arrange['INVNUM'];
////////////////////////////////////////////////get memo inv recpt account type //////////////////////////////

$sales_accnum_saleType = $row_arrange['sales_accnum'];
$gate_accnum_saleType = $row_arrange['gate_accnum'];
$memo_accnum_saleType  = $row_arrange['memo_accnum'];
$misInv_accnum_saleType  = $row_arrange['misInv_accnum'];
$recpt_accnum_saleType  = $row_arrange['recpt_accnum'];
$discnt_accnum_saleType  = $row_arrange['discnt_accnum'];
//////////////////////////////////////////////////sales_accnum_saleType/////////////////////////////////
$saletype_query="SELECT * 
FROM ACCOUNT
WHERE 
ACCTID ='$sales_accnum_saleType' 
";
$result_saletype_query = mysql_query($saletype_query);
while ($row_result_saletype_query = mysql_fetch_assoc($result_saletype_query)) {
$CTSorNoCTSsalesNum  = $row_result_saletype_query['SALE_TYPE'];
}
//////////////////////////////////////////////////sales_accnum_saleType////END///////////////////////////// $sales_accnum_saleType' .$CTSorNoCTSsalesNum
//////////////////////////////////////////////////memo_accnum_saleType/////////////////////////////////
$saletype_query="SELECT * 
FROM ACCOUNT
WHERE 
ACCTID ='$memo_accnum_saleType' 
";
$result_saletype_query = mysql_query($saletype_query);
while ($row_result_saletype_query = mysql_fetch_assoc($result_saletype_query)) {
$CTSorNoCTSmemoNum  = $row_result_saletype_query['SALE_TYPE'];
}
//////////////////////////////////////////////////memo_accnum_saleType////END/////////////////////////////
//////////////////////////////////////////////////misInv_accnum_saleType/////////////////////////////////
$saletype_query="SELECT * 
FROM ACCOUNT
WHERE 
ACCTID ='$misInv_accnum_saleType' 
";
$result_saletype_query = mysql_query($saletype_query);
while ($row_result_saletype_query = mysql_fetch_assoc($result_saletype_query)) {
$CTSorNoCTSmisInvNum  = $row_result_saletype_query['SALE_TYPE'];
}
//////////////////////////////////////////////////misInv_accnum_saleType////END/////////////////////////////$misInv_accnum_saleType.$CTSorNoCTSmisInvNum
//////////////////////////////////////////////////recpt_accnum_saleType/////////////////////////////////
$saletype_query="SELECT * 
FROM ACCOUNT
WHERE 
ACCTID ='$recpt_accnum_saleType' 
";
$result_saletype_query = mysql_query($saletype_query);
while ($row_result_saletype_query = mysql_fetch_assoc($result_saletype_query)) {
$CTSorNoCTSrecptNum  = $row_result_saletype_query['SALE_TYPE'];
}
//////////////////////////////////////////////////recpt_accnum_saleType////END//////////////////////////
////////////////////////////////////////////////get memo inv recpt account type /////END/////////////////////////
echo"<tr>";
echo "<td colspan='2'>";
echo 	$inputString_post."  ".$row_arrange['CUSID'];
$lookaheadcusid = $row_arrange['CUSID'];
echo "</td>";
echo "<td>";
echo $row_arrange['DATE'];
echo "</td>";
echo "<td>";
if($row_arrange['MEMONUM'] > 0 ){echo " CM ";//.$memo_accnum_saleType.$CTSorNoCTSmemoNum; 
$ctsORnocts =$CTSorNoCTSmemoNum;}
if($row_arrange['INVNUM'] > 0  && $row_arrange['APPNUM'] > 0 && $row_arrange['MEMONUM'] == 0 ){echo " SJ ";//.$sales_accnum_saleType.$CTSorNoCTSsalesNum;
$ctsORnocts =$CTSorNoCTSsalesNum;}
if($row_arrange['INVNUM'] > 0  && $row_arrange['APPNUM'] == 0 && $row_arrange['MEMONUM'] == 0 ){echo " SJ  (Mis Invoice)";//.$misInv_accnum_saleType.$CTSorNoCTSmisInvNum;
$ctsORnocts =$CTSorNoCTSmisInvNum;}
if($row_arrange['RECNUM'] > 0 ){echo " CRJ ";//.$recpt_accnum_saleType.$CTSorNoCTSrecptNum;
$ctsORnocts =$CTSorNoCTSrecptNum; }
echo "</td>";
echo "<td>";
echo  "<a href='financial_approved_admin.php?appid=".$row_arrange['APPNUM']."'>".$row_arrange['APPNUM']."</a>";
$appid_gate_batch_chk= $row_arrange['APPNUM'];
echo "</td>";
echo "<td>";	

//echo "insert link ";
echo "<a href='get_memo.php?invoice_num=".$row_arrange['MEMONUM']."'>".$row_arrange['MEMONUM']."</a>";
echo "</td>";
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if($appid_gate_batch_chk==0){
echo "<td>";
echo "<a href='get_invoice_items_wo_memo.php?invoice_num=".$row_arrange['INVNUM']."'>".$row_arrange['INVNUM']."</a>";
echo "</td>";
}
else{
echo "<td>";
echo "<a href='get_invoice_wo_memo.php?invoice_num=".$row_arrange['INVNUM']."'>".$row_arrange['INVNUM']."</a>";
echo "</td>";
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
echo "<td>";	
echo "<a href='review_rep.php?receipt_num=".$row_arrange['RECNUM']."'>".$row_arrange['RECNUM']."</a>";
echo "</td>";


$regamt_display   =  $row_arrange['REGAMOUNT'];
$regamt   +=  $row_arrange['REGAMOUNT'];
$regamt_avg  = ($regamt) / $count; 
	
if($row_arrange['RECNUM']>0){
	
	if($usertype =="RA" ){echo "<td  width='300px'  id='".$row_arrange['RECNUM']."' >"; }
else {echo "<td  width='300px' class='td_edit'  id='".$row_arrange['RECNUM']."' >"; }

echo $row_arrange['DESCRIPTION'] . " " ;
echo "</td>";
}
else{
echo"<td  width='300px'  id='".$row_arrange['RECNUM']."' >";
echo $row_arrange['DESCRIPTION'] . " " ;
echo "</td>";}


echo "<td>";	
if($ctsORnocts=='CTS'){
echo $row_arrange['AMOUNT'];
//echo "Cts student Amount";
if($row_arrange['INVNUM']==0 ){$openbalance_amount = $openbalance_amount -  $row_arrange['AMOUNT'] ; }
if($row_arrange['RECNUM']==0  ){$openbalance_amount = $openbalance_amount +  $row_arrange['AMOUNT']; }
}
else {echo" &nbsp;" ; }
echo "</td>";

echo "<td>";	
//echo "Cts student balance";
echo "</td>";

echo "<td>";	
if($row_arrange['MEMONUM']== 0){echo $row_arrange['GATEAMOUNT'];}
else{echo $row_arrange['MIN_AMT'];}
if($row_arrange['INVNUM']==0 ){$openbalance_amount_min = $openbalance_amount_min -  $row_arrange['GATEAMOUNT']  - $row_arrange['MIN_AMT']; }
if($row_arrange['RECNUM']==0  ){$openbalance_amount_min = $openbalance_amount_min +  $row_arrange['GATEAMOUNT']+  $row_arrange['MIN_AMT']; }
echo "</td>";

echo "<td>";	
if($ctsORnocts=="noCTS"){
echo $row_arrange['AMOUNT'];
//echo "non Cts student amount";
if($row_arrange['INVNUM']==0 ){$openbalance_amount_nonCTS = $openbalance_amount_nonCTS -  $row_arrange['AMOUNT'] ; }
if($row_arrange['RECNUM']==0  ){$openbalance_amount_nonCTS = $openbalance_amount_nonCTS +  $row_arrange['AMOUNT']; }
}
else{ echo" &nbsp;";}
echo "</td>";

echo "<td>";	
//echo "non Cts student balance";
echo "</td>";
//echo $openbalance_amount; $openbalance_amount_nonCTS = 
echo "</tr>";

$whatistherecnum= $row_arrange['RECNUM'];
$whatisthememonum= $row_arrange['MEMONUM'];
if($regamt_display ==0){}
else{$count++; }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
if ($whatistherecnum ==0 && $whatisthememonum==0){
echo "<tr>";

echo "<td colspan=6 align='right'>";
echo "Reg fee ";
echo "</td>";
echo "<td>";
echo $regamt_display ;
echo "</td>";
echo "</tr>";
}else {}

$GC_batch_query_num="SELECT  GATE_CLEAR_INFO.BATCH_CLEAR_PRIMARYKEY , GATE_CLEAR_INFO.BATCH_CLEAR_ID , GATE_CLEAR_INFO.APPID , GATE_CLEAR_INFO.CLEAR_APR 

FROM GATE_CLEAR_INFO
WHERE 
GATE_CLEAR_INFO.APPID ='$appid_gate_batch_chk'
";
$result_GC_batch_query_num = mysql_query($GC_batch_query_num);
if( mysql_num_rows($result_GC_batch_query_num)==0){}
else{
/////////////////////////////////////////////////GATE CLEARANCE  batch information///////////////////////////////////////////////
echo "<tr>";

echo "<td>";
echo "Gate Clearance Batch ";
echo "</td>";

//echo $appid_gate_batch_chk;
$GC_batch_query="SELECT  GATE_CLEAR_INFO.BATCH_CLEAR_PRIMARYKEY , GATE_CLEAR_INFO.BATCH_CLEAR_ID , GATE_CLEAR_INFO.APPID , GATE_CLEAR_INFO.CLEAR_APR 

FROM GATE_CLEAR_INFO
WHERE 
GATE_CLEAR_INFO.APPID ='$appid_gate_batch_chk'
";

$result_GC_batch_query = mysql_query($GC_batch_query);
echo "<td colspan='3'>";
while ($row_result_GC_batch_query = mysql_fetch_assoc($result_GC_batch_query)) {
	
	echo "<a href='GateClear_batch_listings.php?batchidget=".$row_result_GC_batch_query['BATCH_CLEAR_ID']."'>".$row_result_GC_batch_query['BATCH_CLEAR_ID']."</a>";
	//http://localhost/CTS/PHP/GateClear_batch_listings.php?batchidget=11
//	echo $row_result_GC_batch_query['BATCH_CLEAR_ID'];
	echo " - ";
if($row_result_GC_batch_query['CLEAR_APR']=='APR'){
	echo "Approved";
	}
if($row_result_GC_batch_query['CLEAR_APR']=='DEN'){
	echo "DEN";
	}
if($row_result_GC_batch_query['CLEAR_APR']=='' || $row_result_GC_batch_query['CLEAR_APR']==NULL){
	echo "Pending";
	}	
	}

echo "</td>";
echo "</tr>";
/////////////////////////////////////////////////GATE CLEARANCE batch information//END/////////////////////////////////////////////
/////////////////////////////////////////////////GATE  FORM batch information///////////////////////////////////////////////
echo "<tr>";
echo "<td>";
echo "Gate Form Batch";
echo "</td>";
$GF_batch_query="SELECT  GATE_FORM_INFO.BATCH_FORM_PRIMARYKEY , GATE_FORM_INFO.BATCHID , GATE_FORM_INFO.APPID , GATE_FORM_INFO.FORM_APR 

FROM GATE_FORM_INFO 
WHERE 
GATE_FORM_INFO.APPID ='$appid_gate_batch_chk'
";

$result_GF_batch_query = mysql_query($GF_batch_query);
echo "<td colspan='3'>";
while ($row_result_GF_batch_query = mysql_fetch_assoc($result_GF_batch_query)) {
	//Gateform_batch_listings.php?batchidget=1
	echo "<a href='Gateform_batch_listings.php?batchidget=". $row_result_GF_batch_query['BATCHID']."'>". $row_result_GF_batch_query['BATCHID']."</a>";
	//echo $row_result_GF_batch_query['BATCHID'];
	echo " - ";

if($row_result_GF_batch_query['FORM_APR']=='APR'){
	echo "Approved";
	}
if($row_result_GF_batch_query['FORM_APR']=='DEN'){
	echo "DEN";
	}
if($row_result_GF_batch_query['FORM_APR']=='' || $row_result_GF_batch_query['FORM_APR']==NULL) {
	echo "Pending";
	}	
	
	}

echo "</td>";
echo "<td>";
/////////////////////////////////////////////////////////CHECK for all courses in program user applied for  and application apr//////////////////////////
//echo "CHECK for all courses in program user applied for  and application apr";
$num_prg_user=mysql_query("SELECT USER.USERID, APPLICATION.USERID, APPLICATION.APPLICATIONID, APPLICATION.STATUS, COURSEAPP.APPLICATIONID, COURSEAPP.COID, COURSEAPP.GATE_REQUEST, 

COURSEOFFERING.COID, COURSEOFFERING.COURSEID, COURSE.COURSEID, COURSE.PROGRAMID, PROGRAM.PROGRAMID 
FROM COURSEAPP, COURSEOFFERING, COURSE, PROGRAM, USER, APPLICATION
WHERE USER.USERID = APPLICATION.USERID
AND COURSEAPP.COID = COURSEOFFERING.COID
AND COURSEOFFERING.COURSEID = COURSE.COURSEID
AND COURSE.PROGRAMID = PROGRAM.PROGRAMID
AND APPLICATION.STATUS='APR'
AND PROGRAM.PROGRAMID = ( 
SELECT PROGRAM.PROGRAMID
FROM PROGRAM, COURSE, COURSEAPP, COURSEOFFERING
WHERE COURSE.PROGRAMID = PROGRAM.PROGRAMID
AND COURSEAPP.APPLICATIONID = '$appid_gate_batch_chk'
AND COURSEOFFERING.COURSEID = COURSE.COURSEID
AND COURSEAPP.COID = COURSEOFFERING.COID
LIMIT 0 , 1 ) 
AND COURSEAPP.APPLICATIONID = APPLICATION.APPLICATIONID
AND COURSEAPP.GATE_REQUEST = 'Y'
AND APPLICATION.USERID = ( 
SELECT APPLICATION.USERID
FROM APPLICATION
WHERE APPLICATION.APPLICATIONID = '$appid_gate_batch_chk' ) 
"
);  
echo "This student was approved for ";
echo  mysql_num_rows($num_prg_user);
echo " subjects  in this Program. ";
/////////////////////////////////////////////////////////CHECK for all courses in program user applied for  and application apr///END///////////////////////

//////////////////////////////////////////////////////No of courses in Pogram////////////////////////////////////////////////////
$num_subs_in_prg_user=mysql_query("SELECT USER.USERID, APPLICATION.USERID, APPLICATION.APPLICATIONID, APPLICATION.STATUS, COURSEAPP.APPLICATIONID, COURSEAPP.COID, COURSEAPP.GATE_REQUEST, 

COURSEOFFERING.COID, COURSEOFFERING.COURSEID, COURSE.COURSEID, COURSE.PROGRAMID, PROGRAM.PROGRAMID ,PROGRAM.SUBJ_IN_PROG
FROM COURSEAPP, COURSEOFFERING, COURSE, PROGRAM, USER, APPLICATION
WHERE USER.USERID = APPLICATION.USERID
AND COURSEAPP.COID = COURSEOFFERING.COID
AND COURSEOFFERING.COURSEID = COURSE.COURSEID
AND COURSE.PROGRAMID = PROGRAM.PROGRAMID
AND APPLICATION.STATUS='APR'
AND PROGRAM.PROGRAMID = ( 
SELECT PROGRAM.PROGRAMID
FROM PROGRAM, COURSE, COURSEAPP, COURSEOFFERING
WHERE COURSE.PROGRAMID = PROGRAM.PROGRAMID
AND COURSEAPP.APPLICATIONID = '$appid_gate_batch_chk'
AND COURSEOFFERING.COURSEID = COURSE.COURSEID
AND COURSEAPP.COID = COURSEOFFERING.COID
LIMIT 0 , 1 ) 
AND COURSEAPP.APPLICATIONID = APPLICATION.APPLICATIONID
AND COURSEAPP.GATE_REQUEST = 'Y'
AND APPLICATION.USERID = ( 
SELECT APPLICATION.USERID
FROM APPLICATION
WHERE APPLICATION.APPLICATIONID = '$appid_gate_batch_chk' ) 
GROUP BY PROGRAM.PROGRAMID
"
);  
while($rows_num_subs_in_prg_user= mysql_fetch_array($num_subs_in_prg_user)){
	echo " This Program allows a maximum of ";
	echo $rows_num_subs_in_prg_user['SUBJ_IN_PROG'];
	echo " subjects";
	}

//////////////////////////////////////////////////////////////////no of courses in program end ///////////////////////////////////
echo "</td>";
echo "</tr>";
/////////////////////////////////////////////////GATE  FORM batch information//END/////////////////////////////////////////////
} //else num rows
echo "<tr>";

echo "<td colspan=9>";
echo "subtotal ";
echo "</td>";

echo "<td>";
 $openbalance_amount =  $openbalance_amount + $regamt_avg ;
echo "</td>";

echo "<td>";
echo round($openbalance_amount, 2);
echo "</td>";

echo "<td>";
echo round($openbalance_amount_min, 2);
echo "  </td>";

echo "<td>";
echo "&nbsp;";
echo "  </td>";

echo "<td>";
echo $openbalance_amount_nonCTS;
echo "  </td>";

echo "</tr>";


}// while inputstring is username
$inputString_post='';
$openbalance_amount_nonCTS=0;
$openbalance_amount_min=0;
$openbalance_amount=0;
$regamt_avg=0;
 $openbalance_amount=0;  
 $openbalance_amount_min=0;
 
 $drop_table = mysql_query(" DROP TABLE ".$TEMP_TBL." ; ");
}

///////////////////////////////////////////////////////////ARRANGE VALUES// // END////////////////////////////////////////////
$arrange_temp_values;
$view_temp_values;
// $drop_table = mysql_query(" DROP TABLE ".$TEMP_TBL." ; ");


//echo $create_temp_tbl;
echo mysql_error();



echo " </td>" ;
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "<input name='print' type='submit' value='click here to print statment'>";
echo "";
echo "</td>";
echo "</tr>";
echo"</form>";
?>

    </tbody>
    
</table>

</div>

</body>
</html>