$(document).ready(function(){

	$(window).resize(function(){
		var width = $(this).width();
		console.log(width);
	})

	$(".mobile-toggle").click(function(){
		if($(".nav ul").hasClass("nav-open")){
			$(".nav ul").css({
				"max-height": "0px",
			});

			$(".nav ul").addClass("nav-close");
			$(".nav ul").removeClass("nav-open");

		}else{
			$(".nav ul").css({
				"max-height": "393px",
			});

			$(".nav ul").addClass("nav-open");
			$(".nav ul").removeClass("nav-close");
		}
	})

	$(".form-area .card .body").click(function(index){
		var ord = $(this).data("order");

		$(".form-area .card .body .checkbox").removeClass("checked");

		$(".form-area .card .body .white-bg").css({
			"background-color": "transparent"
		})
		$(".white-bg",this).css({
			"background-color": "white"
		})
		$(".checkbox", this).addClass("checked");

		$(".shipping-type .amount").html("FREE Priority Shipping");
		if(ord == 1){
			$(".package-type .amount").html("3 Bottles + 2 Free Bottles");
			$(".your-total .amount").html("$149.85");
			$(".save .caption").html("349.75");
			$(".save .amount").html("You Save $249.80");
		}
		if(ord == 2){
			$(".package-type .amount").html("2 Bottles + 1 Free Bottle");
			$(".your-total .amount").html("$119.91");
			$(".save .caption").html("249.81");
			$(".save .amount").html("You Save $129.90");
		}
		if(ord == 3){
			$(".package-type .amount").html("1 Bottle");
			$(".your-total .amount").html("$49.95");
			$(".save .caption").html("69.95");
			$(".save .amount").html("You Save $20.00");
		}
	})
	$("button").click(function(){
		window.location = "order.php";
	})
	$(".ajax-modal").click(function(){
		var url = $(this).data("url");
		$("ajax-content .content").show().load(url+".php");
	})
})