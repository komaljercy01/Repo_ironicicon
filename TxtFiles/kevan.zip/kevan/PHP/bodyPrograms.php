<html> 
<head>
<script language="javascript" src="../exam/scripts/script.js">
</script>
</head> 
<body> 

<table valign="middle" style="border: 1px #000000 solid; width: 100%; height: 100%">
<tr align="center">
<td>	
		<table border="0" style="border: 0px #000000 solid; width: 400px; height: 20%; border-spacing: 0px">

<?php
include '../exam/config.php';
include '../exam/opendb.php';

$formTitle = "ADD AN ACADEMIC BODY";
$submitCheck = false;
$count = 0;
$count2 = 0;

$bodyQuery = mysql_query("SELECT * FROM EXAMBODY");

if (mysql_num_rows($bodyQuery) == 0)
{	?>
		<tr>
			<td align="left">
				<p class="head2" align="center">No Academic Bodies Exist. You may add one by clicking <a href="../exam/addBody.php">here</a><br>
			</td>
		</tr>			
<?php
}
else
{
	while ($row = mysql_fetch_array($bodyQuery))
	{   
		$rowBId = $row['BODYID'];
		$rowOName = $row['ORGNAME'];
		$rowDes = $row['DESCRIPTION'];		
?>		<tr style="background-color: EEEEEE">
			<td>
				<p class="head2mar" align="left"><?php echo $rowOName ?></p>
			</td>
			<form name="bodyEditForm<?php echo $count; ?>" method="post" action="../exam/editBody.php">
				<input type="hidden" name="bodyId" value="<?php echo $rowBId; ?>">
			<td>
				<input type="submit" name="editBody" value="Edit" class="eButton">
			</td>	
			</form>
			
		</tr>			
<?php
		$programQuery = mysql_query("SELECT * FROM PROGRAM WHERE BODYID = $rowBId");
		if (mysql_num_rows($programQuery) == 0)
		{	?>
			<tr>
				<td align="left">
					<p class="ver10mar" align="left">This body contains no programs.</p>
				</td>
				<td>
				</td>
			</tr>			
			<?php
		}
		else
		{	
			while ($row2 = mysql_fetch_array($programQuery))
			{
				$row2PId = $row2['PROGRAMID'];
				$row2BId = $row2['BODYID'];
				$row2Title = $row2['TITLE'];
				$row2Cat = $row2['CATEGORY'];
				$count2 += 1;
				?>
				<tr>
					<form name="form<?php echo $count2; ?>" method="post" action="../exam/editProgram.php">
					<input type="hidden" name="programId" value="<?php echo $row2PId; ?>">
						<td>
							<p class="ver10mar" align="left"><?php echo $row2Title.' ('.$row2Cat.')'; ?></p>
						</td>
						<td>
							<input type="submit" name="editProgram" value="Edit" class="eButton">
						</td>
					</form>
				</tr>
				
				<?php
			}
		}
?>
		<tr>
			<td colspan="2">
				<hr color="#000000" style="width: 50%">
			</td>
		</tr>
<?php
	}		
} ?>
		</table>
</td>
</tr>
</table>

</body> 
</html> 