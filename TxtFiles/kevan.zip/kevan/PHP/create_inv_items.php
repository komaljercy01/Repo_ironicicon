<?php 
session_start();
?><html>

<head>
<title>Generate an Invoice</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">


<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">
<script>
var i;
function fill_acnumber(i){
var form1 = document.getElementById("f1");
	form1.cash.options.length=0;

	
switch(i)
{	
case 0:
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  ACCOUNT.ACCTID =3
";	  
$result_acct_id_query= mysql_query($acct_id_query);
$n=0;
while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
?>
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  NOT ACCOUNT.ACCTID =3
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
$n=0;
	?>
break;
case 1:
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  ACCOUNT.ACCTID =1
";	  
$result_acct_id_query= mysql_query($acct_id_query);
$n=0;
while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
?>
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  NOT ACCOUNT.ACCTID =1
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
$n=0;
	?>
break;
case 2:
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  ACCOUNT.ACCTID =1
";	  
$result_acct_id_query= mysql_query($acct_id_query);
$n=0;
while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
?>
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  NOT ACCOUNT.ACCTID =1
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
$n=0;
	?>
break;
case 3:
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  ACCOUNT.ACCTID =1
";	  
$result_acct_id_query= mysql_query($acct_id_query);
$n=0;
while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
?>
<?php 
include 'config.php';
include 'opendb.php';
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
AND
ACCOUNTTYPE.ACCTYPE = 2
AND  NOT ACCOUNT.ACCTID =1
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
echo "form1.cash.options[$n] =new  Option('".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."','".$noticia_result_acct_id_query['ACCTID']."');";
$n++;
}
$n=0;
	?>
break;
}

}
</script>

<script type="text/javascript">

 function openWindow()
 {
  window.open('new_page_address.html','_blank');
  return true;
 }
</script>

<script type="text/javascript" src="../scripts/jquery-1.2.1.pack.js"></script>
<script type="text/javascript">
	function lookup(inputString) {
		if(inputString.length == 0) {
			// Hide the suggestion box.
			$('#suggestions').hide();
		} else {
			$.post("rpc_Aadmin.php", {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$('#suggestions').show();
					$('#autoSuggestionsList').html(data);
				}
			});
		}
	} // lookup
	
	function fill(thisValue) {
		$('#inputString').val(thisValue);
		setTimeout("$('#suggestions').hide();", 200);
	}
</script>

<style type="text/css">

	.suggestionsBox {
		position: relative;
		left: 30px;
		margin: 10px 0px 0px 0px;
		width: 200px;
		background-color: #212427;
		-moz-border-radius: 7px;
		-webkit-border-radius: 7px;
		border: 2px solid #000;	
		color: #fff;
	}
	
	.suggestionList {
		margin: 0px;
		padding: 0px;
	}
	
	.suggestionList li {
		
		margin: 0px 0px 3px 0px;
		padding: 3px;
		cursor: pointer;
	}
	
	.suggestionList li:hover {
		background-color: #659CD8;
	}
</style>

</head>
<body >
<div id="top">
<div id="menu"></div>
</div>
<!-- Save for Web Slices (CTS.psd) -->
             <?php            // enter php to divert to login.php when appid and userid test fails
	// 
include 'config.php';
include 'opendb.php';
//$appidcheck = $_POST['appid'];
//$userid=$_POST['userid'];
$userid =  $_SESSION['USERAUTH'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];
//$appidcheck =  $_SESSION['APPID'];
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;

//validates session

?>
             <?php
include 'config.php';
include 'opendb.php'; 
			 
 $query4="select USERNAME from user where USERID  = ".$userid;
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
?>
<script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form id="logout" action="logout.php" method="post">    
<table width="300" border="0" align="right" class="gaia">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
<!--      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>-->
    </table>
</form>
<table width="100%" border="0">
  <caption align="left">
    Menu
  </caption>
  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a> </td>
  </tr>
</table>
<form name ="f1" method="post">  
 <table border='1' >         
	 <tr><td> 
    Username:  <span id="sprytextfield2">
       <input type="text" size="30" value="" name="inputString" id="inputString" onKeyUp="lookup(this.value);" />
       
       <span class="textfieldRequiredMsg">A value is required.</span></span>
<div class="suggestionsBox" id="suggestions" style="display: none;">
				<img src="../images/upArrow.png" style="position: center; top: -12px; left: 30px;" alt="upArrow" />
				<div class="suggestionList" id="autoSuggestionsList">
&nbsp;				</div>
  </div>
<!-- onClick="document.f1.action='customer_ledger.php';" -->
  </td><td>
	 <span id='currency'>
     <label>Amount
     <input type='text' name='amount' id='amount' />
     </label>
     <span class='textfieldRequiredMsg'>A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span> </td>

  <td>
  <label>Sales account
<?php 

echo " <select name='cash' id='cash'>";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION, ACCOUNT.ACTIVE, ACCOUNT.ACCTYPE, ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC
FROM ACCOUNTTYPE, ACCOUNT
WHERE ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE
AND ACCOUNTTYPE.ACCTYPE =4
AND ACCOUNT.ACCTNAME ='40000'
UNION 
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION, ACCOUNT.ACTIVE, ACCOUNT.ACCTYPE, ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC
FROM ACCOUNTTYPE, ACCOUNT
WHERE ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE



";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
    
 </label>   
 </td> 
 
 <td>
  <label>A/R account
 <?php 

echo " <select name='ARacct' id='ARacct'>";
$course_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE from  ACCOUNT 
where 
ACCOUNT.ACCTYPE=  '1'
Group by  ACCOUNT.ACCTID
Order by ACCOUNT.ACCTID 
";	  
$result_course_id_query= mysql_query($course_id_query);

while($noticia_result_course_id_query = mysql_fetch_array($result_course_id_query)) {
	
echo "<option value='".$noticia_result_course_id_query['ACCTID']."'>".$noticia_result_course_id_query['ACCTNAME']." - ".$noticia_result_course_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
 </label>   
 </td>

 
  </tr>
     <tr>
       <td><?php 
echo "<input type='submit' value='Create Invoice' onClick=f1.action='insert_inv_items.php';this.form.target='_parent';>


 " ?></td>

       <td colspan="3">  <label>Details
   
     </label>
      
       <textarea name="Details" id="Details" cols="100" rows="10"></textarea></td>
      
      
     </tr>
     <tr>
      
       <td>&nbsp;</td>
       <td>&nbsp;</td>
       <td>&nbsp;</td>
       <td>&nbsp;</td>
     </tr>
      </table>
    <!--
    <input type='submit' value='Previous Page' onClick="f1.action='courses_pending.php'; return true;">     

  <input type='submit' value='Confirm and View Quotation' onClick="f1.action='confirmation_pending_admin.php'; return true;">-->
</form>

<!-- End Save for Web Slices -->
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("currency", "currency");
//-->
</script>

<script type="text/javascript">
<!--
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</body>
</html>