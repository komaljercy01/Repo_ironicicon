<?php 
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Vendor Bill</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<!--<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">-->
<link rel="stylesheet" href="css/bootstrap-datepicker3.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
<script src="scripts/js/bootstrap-datepicker.min.js"></script> 
<script src="scripts/editVendorBill_js.js"></script> 
<!--<script src="//oss.maxcdn.com/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.min.js"></script>-->

          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
    <style type="text/css">
/* Adjust feedback icon position */
#addVendor .form-control-feedback {
    right: 15px;
}
#addVendor .selectContainer .form-control-feedback {
    right: 25px;
}
</style>

</head>
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];

 $query4="select  USERTYPE from user where  USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'";
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$usertype = $row['USERTYPE'];
}



$SQLuserid = "select  * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}
else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

<script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" style="  margin-right: 10px; margin-top: 20px;" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table>
</form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>
<body style="background-color:#f5f5f5">
<?php 
//include 'config.php';
//include 'opendb.php';
$vbid_get = $_GET['vbid'];
 
// vendor bill details
$query_vendor=mysql_query("SELECT  vb.*,v.VendorName FROM vendorbills vb inner join vendor v on v.VendorID=vb.VID WHERE VBid=$vbid_get"); 
$res=mysql_fetch_array($query_vendor); 
//print_r($res);
$vBillId=$res['VBid'];
$vid_get=$res['VID'];
?>
  <div class="row">
    <div class="col-md-9 col-md-offset-1">
      <form class="form-horizontal" role="form" id="editVendorBill">
        <fieldset>

          <!-- Form Name -->
          <legend>Edit Vendor Bill</legend>
			<div class="alert alert-warning alert-dismissible" role="alert" id="errors" style="display:none;">
					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<strong>Errors !!!</strong><br> <span id="errorMsg"></span>
			</div>
			<div class="alert alert-success alert-dismissible" role="alert" id="success" style="display:none;">
					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<strong>Success !!!</strong><br> <span id="successMsg"></span>
			</div>
			<div class="alert alert-warning alert-dismissible" role="alert" id="errorsRemove" style="display:none;">
					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<strong>Errors !!!</strong><br> <span id="errorRemoveMsg"></span>
			</div>
			<div class="alert alert-success alert-dismissible" role="alert" id="successRemove" style="display:none;">
					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<strong>Success !!!</strong><br> <span id="successRemoveMsg"></span>
			</div>
           <!-- Text input-->
		   <input type="hidden" name="vbid" value="<?php echo $vBillId; ?>"/>
          <div class="form-group col-md-6">
            <label class="col-md-5 control-label" for="textinput">Vendor Name</label>
            <div class="col-md-7">
              <input type="text" placeholder="" class="form-control" name="vname" id="vname" value="<?php if(isset($res['VendorName']) && $res['VendorName'])echo $res['VendorName']; ?>" readonly >
            </div>
		 </div>
		 <div class="form-group col-md-6">
            <label class="col-md-5 control-label" for="textinput">Vendor Number</label>
            <div class="col-md-7">
              <input type="text" placeholder="" class="form-control" name="vnumber" id="vnumber" value="<?php echo $vid_get; ?>" readonly>
            </div>
          </div>

          
           <!-- Text input-->
          <div class="form-group col-md-6">
           <!--- <label class="col-sm-2 control-label" for="textinput">Cheque Number</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="VchequeNo" id="VchequeNo" value="<?php echo $VchequeNo; ?>">
            </div>-->

            <label class="col-md-5 control-label" for="textinput">Date</label>
            <!--<div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="Date" id="Date" value="<?php echo $date; ?>">
            </div>-->
			<div class="col-md-7 dtPicker">
				<input type="text" type="text" id="date" name="date" value="<?php if(isset($res['VBdate']) && $res['VBdate'])echo $res['VBdate']; ?>" class="form-control">
			</div>
		</div>
		<div class="form-group col-md-6">


            <label class="col-md-5 control-label" for="textinput">Payable account</label>
			  <div class="col-md-7">
					<?php
							echo " <select name='AR' id='vaccountpay1' class='form-control' > ";
							$acct_id_query = "
							SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
							where 
							ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
							ORDER BY ACCOUNT.ACCTID DESC
							";    
							$result_acct_id_query= mysql_query($acct_id_query);

							while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
							  $selected="";
							  if($noticia_result_acct_id_query['ACCTID']==$res['AR'])$selected='selected';
							echo "<option value='".$noticia_result_acct_id_query['ACCTID']."' ".$selected.">".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
							}
							echo "</select>";
					  ?>
				</div>

 </div>
          
	 <input type="hidden" name="vid" id="vid" value="<?php echo $vid_get;?>" >

   <!-- drop down  input-->
          <div class="form-group col-md-6">
           
          <label class="col-md-5 control-label" for="textinput">Due Date</label>
            <!--<div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="dueDate" id="dueDate" value="<?php echo $duedate; ?>">
            </div> -->
			<div class="col-md-7 dtPicker">
				<input type="text" type="text" id="duedate" name="duedate" value="<?php if(isset($res['duedate']) && $res['duedate'])echo $res['duedate']; ?>" class="form-control">
			</div>
			</div>
			<div class="form-group col-md-6">
				 <label class="col-md-5 control-label" for="textinput">Total</label>
				<div class="col-md-7">
				 <div id="total" style="margin-top: 6px;"> </div>
				</div> 
         </div>
         <!--Headings -->
          <div class="form-group col-md-12">
			 <label class="col-sm-1 control-label" for="textinput">Remove</label>
			 <label class="col-sm-1 control-label" for="textinput">Quantity</label>
			 <label class="col-sm-2 control-label" for="textinput">Unit Price</label>
			 <label class="col-sm-4 control-label" for="textinput" >Description</label>
			 <label class="col-sm-2 control-label" for="textinput" >Account Number</label>
			 <label class="col-sm-2 control-label" for="textinput">Sub Total</label>
		   </div>
         <!-- Text input-->
		
         <?php 
		 $qBillitemsr="select * from vendorbillsitems where VBid=$vBillId and ACTIVE=1";
		 $qBillitems=mysql_query($qBillitemsr);
		 $count=0;
		 while($rBillItems=mysql_fetch_array($qBillitems)) {
				$count++;
			?>
			<input type="hidden" name="vbitemid[]" value="<?php if(isset($rBillItems) && $rBillItems)echo $rBillItems['VBIID']; ?>"/>
          <div class="form-group col-md-12" id="row_<?php echo $count; ?>">
			<div class="col-sm-1">
              <span><i class="glyphicon glyphicon-minus-sign" data-vl="<?php echo $count; ?>" onClick="removeBillItem(this);" data-id="<?php if(isset($rBillItems) && $rBillItems)echo $rBillItems['VBIID']; ?>" style="font-size: 30px;float: right;color:red;cursor:pointer;"></i></span>
            </div>
            <div class="col-sm-1">
              <input type="text" placeholder="" id="qty_<?php echo $count;?>" data-id="<?php echo $count;?>" onChange="updateTotal(this);" class="form-control" name="Quantity[]" value="<?php if(isset($rBillItems) && $rBillItems)echo $rBillItems['Quantity'];?>">
            </div>
               
            <div class="col-sm-2">
              <input type="text" placeholder="" id="uPrice_<?php echo $count;?>" data-id="<?php echo $count;?>" class="form-control" onChange="updateTotal(this);" name="unitPrice[]" value="<?php if(isset($rBillItems) && $rBillItems)echo $rBillItems['unitPrice'];?>">
            </div>
               
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="desc[]" value="<?php if(isset($rBillItems) && $rBillItems)echo $rBillItems['Description'];?>">
            </div>

            <div class="col-sm-2">
            <?php 

				echo " <select name='ARVal[]' class='form-control' > ";
				$acct_id_query = "
				SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
				where 
				ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
				ORDER BY ACCOUNT.ACCTID DESC
				";    
				$result_acct_id_query= mysql_query($acct_id_query);

				while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
				  $selected="";
				  if($noticia_result_acct_id_query['ACCTID']==$rBillItems['AcctID'])$selected='selected';
				echo "<option value='".$noticia_result_acct_id_query['ACCTID']."' ".$selected.">".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
				}
				echo "</select>";
			?>
            </div>
           
            <div class="col-sm-2">
              <input type="text" placeholder="" class="form-control subtotal" id="subTotal_<?php echo $count;?>" name="Subtotal[]" readonly value="<?php if(isset($rBillItems) && $rBillItems)echo $rBillItems['Subtotal'];?>">
            </div>
          </div> 

<?php }?>
<input type="hidden" value="<?php echo $count+1; ?>" id="count"/>
<div id="billColumn"></div>
<div class="form-group">		
	<div class="col-md-12">
	  <span><i class="glyphicon glyphicon-plus-sign" style="font-size: 35px;float: right;cursor:pointer;" id="addBillItemColumn"></i></span>
	</div>
</div>
<!--- Text input-->
			<div class="form-group col-md-12">
				<div class="pull-right">
				 <button type="button" id="saveVBill" class="btn btn-primary">Save and Add New Bill </button>
				  <button type="button" class="btn btn-danger" id="cancelWindow">Cancel</button>
			  </div>
		  </div>
</div>
          
        </fieldset>
      </form>
    </div><!-- /.col-lg-12 -->
</div><!-- /.row -->

<input type="hidden" value="<?php echo SITE_URL; ?>" id="base_url"/>
</body>
</html>                                		