 <?php 
session_start();
?>
	

<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">



<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.3/css/jquery.dataTables.css">
<link type="text/css" href="../css/jquery.ui.all.css" rel="stylesheet" />



<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" language="javascript" src="../jquery/js/jquery.dataTables.numbers.js"></script>
<script type="text/javascript" src="../jquery/js/jquery.ui.datepicker.js"></script>
	<script type="text/javascript" class="init">


$(document).ready(function() {
	$('#example').dataTable( {
		columnDefs: [ {
			targets: [ 0 ],
			orderData: [ 0, 1 ]
		}, {
			targets: [ 1 ],
			orderData: [ 1, 2 ]
		}, {
			targets: [ 2 ],
			orderData: [ 2, 3 ]
		},{ 
			targets: [ 3 ],
			orderData: [ 3, 4]
		},{ 
			targets: [ 4 ],
			orderData: [ 4, 5]
		
		} ]
	} );
} );

	</script>




<script type="text/javascript"> 
	$(function() {
		$("#date1").datepicker();
	});
	</script> 

<script type="text/javascript"> 
	$(function() {
		$("#date2").datepicker();
	});
	</script> 

        
<head>
</head>
  
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];
$formnum=2;
$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>
<body id="dt_example">
		<div id="container">
		
	

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>

<?php 
$CoStartdate=$_POST['date1'];
$CoEndDate =  $_POST['date2'];


if($CoStartdate==NULL){$CoStartdate="2014-01-01";}
if($CoEndDate==NULL){$CoEndDate=  date("Y-m-d");}

$date1="2009-01-01";
$date2=  date("Y-m-d");


$cat_=$_GET['cat'];
$subcat_=$_GET['cat3'];

$cat=$_POST['cat'];
$subcat=$_POST['subcat'];


$subcat3_=$_GET['cat4'];
$subcat4_=$_GET['cat5'];
$subcat5_=$_GET['cat6'];





$subcat3=$_POST['subcat3'];
$subcat4=$_POST['subcat4'];
$subcat5=$_POST['subcat5'];
$subcat6=$_POST['subcat6'];

////////////////////////////////////////////get users in course////////////////////////////
$courseid = $subcat6;
$examid = $cat;
$programid = $subcat;

include 'config.php';
include 'opendb.php';

$quer_usersfor_course=mysql_query("

SELECT  USER.USERNAME ,  COURSEOFFERING.COID, COURSE.COURSETITLE, COURSEOFFERING.COURSEID,  COURSEOFFERING.COST , 
COURSEOFFERING.STARTDATE, COURSEOFFERING.ENDDATE, 
COURSE.COURSEID, COURSE.PROGRAMID , PROGRAM.PROGRAMID , PROGRAM.BODYID , PROGRAM.TITLE , EXAMBODY.BODYID , EXAMBODY.ORGNAME  , USER.USERID, USER.EMAIL , COURSEAPP.APPLICATIONID, COURSEAPP.COID , COURSEAPP.CAID , APPLICATION.APPLICATIONID  , COURSEAPP.APPLICATIONID , APPLICATION.USERID  , APPLICATION.STATUS ,INVOICE.INVNUMID , INVOICE.APPLICATIONID , INVOICE.DATE_INV

FROM   COURSEOFFERING, COURSE, PROGRAM, EXAMBODY,USER , COURSEAPP , APPLICATION  , INVOICE

WHERE 
USER.USERID = APPLICATION.USERID AND
APPLICATION.APPLICATIONID = COURSEAPP.APPLICATIONID AND
COURSEAPP.COID = COURSEOFFERING.COID AND
COURSEOFFERING.COURSEID =  COURSE.COURSEID AND
COURSE.PROGRAMID = PROGRAM.PROGRAMID AND
PROGRAM.BODYID =  EXAMBODY.BODYID  AND
APPLICATION.STATUS ='APR' AND
APPLICATION.APPLICATIONID =  INVOICE.APPLICATIONID AND
INVOICE.DATE_INV  BETWEEN '$CoStartdate' AND '$CoEndDate' 
GROUP  by COURSEAPP.CAID

");

////////////////////////////////////////////get users in course////////////////////////////

//$inputString_post = $_POST['inputString'];
if($inputString_post==''){$inputString_post='zzz';}




//echo "<form action=".$_SERVER['PHP_SELF']." method=post  name='f1' id='f1'>";
?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"  name="f1" id="f1">
           <table border="0" cellpadding="0" cellspacing="0" id="frames">
    <tr>
      <td><h3>To begin: Select an Exam Body</h3> <?php // echo "APPIDGET = ".$appidcheckget."APPID = ".$appidcheck." USERID = ".$userid."COID= ".$subcat6; ?></td>
      
    </tr>
    <tr>
      <td>
      

<?php


?>

</td>
   </tr>   <tr><td>  </td>
  <td><?php // echo $begintime." - begintime (TEST)"; ?></td>
    </tr></table><table width="200" border="1">
  <tr>    <td>Date 1</td>    <td><input name="date1" id="date1" type="text" size="10" maxlength="10" value=<?php echo $CoStartdate; ?>></td> 
 <td rowspan="3"><?php
///////////////////////////////////////////////////////////////////////////////////



echo "<table>";
echo "  <tr>";
 echo "    <td>First Name</td>";
 echo "    <td>".$firstname."</td>";
echo "   </tr>";
echo "  <tr>";
 echo "    <td>Last  Name</td>";
 echo "    <td>".$lastname."</td>";
echo "   </tr>";
/*echo "  <tr>";
 echo "    <td>Customer ID </td>";
 echo "    <td>".$Customerid."</td>";
echo "   </tr>";*/
echo " </table>";

?>
</td> 
  
  
  
  
  
  
  </tr>
   <tr>    <td>Date 2</td>    <td><input name="date2" id="date2" type="text" size="10" maxlength="10" value=<?php echo $CoEndDate; 2?> ></td>  </tr>
   <tr><td> Username</td> <td>

       		
				
		<input type="text" size="30" value='<?php echo $inputString_post;?>' name="inputString" id="inputString"  disabled/>
            <!--    onKeyUp="lookup(this.value);" onBlur="fill();" />-->

			
<div class="suggestionsBox" id="suggestions" style="display: none;">
				<img src="../images/upArrow.png" style="position: center; top: -12px; left: 30px;" alt="upArrow" />
				<div class="suggestionList" id="autoSuggestionsList">
					&nbsp;
				</div>
  </div>
    
          </td></tr>
   <tr><td colspan="2">
   <input type="submit" value="submit" />
      </td></tr>
</table>

    </form>
    



<div id="container">
		<div id="demo">
<table  width="100%" class='display' id='example' cellpadding='0' cellspacing='0' border='1'> 


    <thead>
    		<tr>
          
            <th >Exam Body</th>
             <th>Course</th>
                <th>Course Offering</th>
                <th >Start Date</th>
            <th>Username</th>               
                <th >Cost</th>
               <th >Memo Value </th> 
               <!-- <th >Minitry amount</th> -->

                </tr>
    </thead>
    <tbody>
   
   


 
<?php




/////////////////////////////////////////////////////////create temp table//////////////////////////////////////////////////
include 'config.php';
include 'opendb.php';



if ( isset($_POST['date1']) ) { 

while($noticia = mysql_fetch_assoc($quer_usersfor_course)){
$caid = $noticia['CAID']; 
echo "<tr>";
echo "<td>".$noticia['ORGNAME']."</td>";
echo "<td>".$noticia['TITLE']."</td>";
echo "<td>".$noticia['COURSETITLE']."</td>";
echo "<td>".$noticia['STARTDATE']."</td>";
echo "<td>".$noticia['USERNAME']."</td>";
echo "<td>".$noticia['COST']."</td>";
 $quer_usersfor_memo=mysql_query("
SELECT  DEREGISTRATION.DEREGID , DEREGISTRATION.CAID , DEREGISTRATION.MEMOID,
MEMO.MEMOID , MEMO.MEMO_AMOUNT
FROM DEREGISTRATION , MEMO
WHERE 
DEREGISTRATION.CAID= $caid AND
DEREGISTRATION.MEMOID = MEMO.MEMOID
");
if(mysql_num_rows($quer_usersfor_memo)>0){
while($noticia_quer_usersfor_memo = mysql_fetch_array($quer_usersfor_memo)) {
echo "<td>". $noticia_quer_usersfor_memo['MEMO_AMOUNT']."</td>";
	}
}
else{echo "<td>"." 0 "."</td>";} 

echo "</tr>";	

}
$inputString_post = substr($inputString_post, 0, strlen($inputString_post)-1); 
//echo $inputString_post;
//echo $examid." - ".$programid;
$num_rows = mysql_num_rows($quer_usersfor_course);
//echo "$num_rows Rows\n";
}
else {}

?>

    </tbody>
    
</table>

</div></div>

    
</div>

</body>
</html>