<?php


if(isSet($_POST['username']))
{
$username = $_POST['username'];

include 'config.php';
include 'opendb.php';

$sql_check = mysql_query("select * from user where username='".$username."'") or die(mysql_error());

if(mysql_num_rows($sql_check))
{
echo '<font color="red">The nickname <STRONG>'.$username.'</STRONG> is already in use.</font>';
}
else
{
echo '<font color="green"><STRONG> Username is available </STRONG> </font>';
}

}

?>