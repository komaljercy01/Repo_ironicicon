<?php
session_start();
?>
<html> 
<head>
<script language="javascript" src="scripts/script.js">
</script>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
</head> 
<body> 
<div id="container">
<table>
<tr>
<td align="center" valign="top">
<?php

include 'config.php';
if ($usertype =="MA" )
{

?>
<table>
	<tr><td>
			MENU: <a href="Controlpanel.php">Home</a> > <a href="listBody.php">List Academic Bodies</a> > <span >Edit Body</span>
	</td></tr>
</table>

<?php

	$formTitle = "EDIT ACADEMIC BODY";

	if ($_POST['bodyId'])
	{	
		$bodyId = $_POST['bodyId'];
		$que = mysql_query("SELECT * FROM EXAMBODY WHERE BODYID=$bodyId");
		
		// CHECK FOR EXAMBODIES						
		if (mysql_num_rows($que) > 0)
		{	
			$row = mysql_fetch_array($que);
			
			if ($_POST['submitCheck'] == true)
			{  
				$orgName = mysql_real_escape_string(trim($_POST['orgName']));
				$orgDes = mysql_real_escape_string(trim($_POST['orgDes']));
				$err = false;
				
			// CHECK FOR ERRORS	
				if (empty($orgName))
				{	
					$notes .= 'Name cannot be left blank<br>';
					$err = true;
					$orgName = $row['ORGNAME'];
				}
				if (empty($orgDes))
				{
					$notes .= 'Description cannot be left blank<br>';
					$err = true;
					$orgDes = $row['DESCRIPTION'];
				}
				
				if (strlen($orgDes) > 250)
				{	$desLen = strlen($orgDes);
					$notes .= 'The description can not exceed 250 characters (Currently '.$desLen.' characters long).';
					$err = true;
					$orgDes = $row['DESCRIPTION'];
				}
				
				if ($err == false)
				{
				
					$que2 =  mysql_query("SELECT * FROM exambody WHERE ORGNAME='$orgName'");
					
					if ($row2 = mysql_fetch_array($que2))			
					{
						$idCheck = $row2['BODYID'];
						
						if ($idCheck != $bodyId)
						{
							$notes = $row2['ORGNAME'] .' already exists.';
							$orgName = $row['ORGNAME'];
						}
						else
						{
							$insertSta = "UPDATE EXAMBODY SET ORGNAME='$orgName', DESCRIPTION='$orgDes' WHERE BODYID=$bodyId";
							mysql_query($insertSta);
							$notes = $orgName.' updated.';							
						}
					}
					else
					{
						$insertSta = "UPDATE EXAMBODY SET ORGNAME='$orgName', DESCRIPTION='$orgDes' WHERE BODYID=$bodyId";
						mysql_query($insertSta);
						$notes = $orgName.' updated.';	
					}			
				}
			}
			else
			{
				$bodyId = $row['BODYID'];
				$orgName = $row['ORGNAME'];
				$orgDes = $row['DESCRIPTION'];
			}
		// SHOW FORM
		?>
				<table >
				<tr>
					<td align="left" colspan="2">
					
						<p ><?php 	echo $formTitle;	?><br>
						<hr >
						<p ><?php 	echo $notes;		?><br>
			
					</td>
				</tr>
			<form name="editBody" method="POST" action="editBody.php">	
			<tr>
				<td align="left" width="150">
					Name: 
				</td>
				<td align="left">
					<input type="text" maxlength="50" id='oname' name="orgName" value="<?php echo $orgName; ?>">							
				</td>			
			</tr>		
			<tr valign="top">
				<td align="left">
					Description:
				</td>
				<td align="left">
					<textarea wrap="soft" rows="4" cols="50" name="orgDes"><?php echo $orgDes; ?></textarea>
				</td>			
			</tr>			
				
				
				<tr>
				<td align="left" colspan="2">
					<input type="submit" name="submit" value="Save Changes" >
					<input type="hidden" name="submitCheck" value="true">
					<input type="hidden" name="bodyId" value="<?php echo $bodyId;?>">
				</form>	
				</td>
				</tr>
				<tr>
				<td align="left" colspan="2">
					<form name="delete" method="post" action="deleteRecord.php">
						<input type="submit" name="sumbit" value="Delete Record">
						<input type="hidden" name="pageName" value="examBody">
						<input type="hidden" name="id" value="<?php echo $bodyId;?>">
					</form>
				</td>
				</tr>				
				<tr>
					<td colspan="2">
					<hr>
				<form name="listBodies" method="post" action="addBody.php">
					<input type="submit" name="viewBodies" value="Add/List Academic Bodies" >
				</form>	
				<form name="addProgram" method="post" action="addProgram.php">
					<input type="submit" name="addPrgSumbit" value="View/Add Programmes" >
					<input type="hidden" name="bodyId" value="<?php echo $bodyId;?>">
				</form>	
				<form name="addProgram" method="post" action="addYear.php">
					<input type="submit" name="addYear" value="View/Add Academic Years">
					<input type="hidden" name="bodyId" value="<?php echo $bodyId; ?>">
				</form>								
					</td>

				</tr>				
				</table>
	<?php		
		}
		else
		{   ?>
				<table >
				<tr>
					<td align="center" colspan="2">
						<p >Academic body does not exist.</p>
					</td>
				</tr>
				</table>
	<?php
		} 
	}
	else
	{	?>
				<table >
				<tr>
					<td align="center" colspan="2">
						<p >You have accessed this page in error.</p>
					</td>
				</tr>
				</table>
	<?php
	}
}
else
{
	?>
		<p align="left">You have accessed this page in error<br>
		<a href="Controlpanel.php">Return to Index</a></p>
	<?php
}
?>		
	</td>
	</tr>
	</table>
    </div>
</body> 
</html> 