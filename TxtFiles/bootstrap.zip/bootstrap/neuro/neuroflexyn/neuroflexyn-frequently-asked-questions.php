<?php include("header.php"); ?>

<div class="neuroflexyn-faq-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12">
				<h1>FAQ</h1>
				<p class="subheader-caption">FREQUENTLY ASKED QUESTIONS ABOUT NEUROFLEXYN</p>
				<div class="faq-caption col-lg-7 col-md-7 col-sm-12">
					<div class="caption">
						<p>We have compiled a list of the most common questions asked in regards to Neuroflexyn below. This will not only help clarify any concerns you may have regarding usage instructions and benefits, but also assist you in making a choice to start benefiting from this natural supplement once you decide it is the right fit for you.</p>
						<p>Our customer support team is also here to answer any additional questions you may have. You may reach us </p>
						<div>
							Toll-Free at 877-296-9799 or 
							Email at Support@Neuroflexyn.com 
							Mon-Fri 6:00am to 6:00pm PST, 
							Saturdays 8:00am to 1:00pm PST.
						</div>
					</div>
				</div>
				<div class="col-lg-5 col-md-5 col-sm-12">
					<img class="img-responsive bottle-faq" src="images/bottle-faq.png" />
				</div>
				<div class="clearfix"></div>
				<div class="blue-div">
					<img src="images/img-cs.png" />
					<p>Our customer care team is also here to answer any question you may have. You may reach us Toll-Free at <span class="highlight">877-296-9799</span> or Email <span class="highlight">Support@Neuroflexyn.com</span></p>
					<div class="clearfix"></div>
				</div>

				<div class="question-answer">
					<div class="card">
						<img src="images/img-question.png" />
						<div class="qa">
							<p class="quest">Q: Where Does Neuroflexyn Come From?</p>
							<p class="ans"><span>A:</span> Formulated with complete and balanced ingredients, Neuroflexyn uses a combination formula that may support in delivering a robust mental advantage to consumers. Neuroflexyn works to potentially support and enrich overall brain and mind function as well as supply it vital nutrients.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="card">
						<img src="images/img-question.png" />
						<div class="qa">
							<p class="quest">Q: How Can I Be Sure Neuroflexyn is Safe?</p>
							<p class="ans"><span>A:</span> Neuroflexyn, is manufactured in a cGMP Certified laboratory in the USA. Moreover the product is continually safely tested to meet industry-best practices. The product is free of yeast, wheat, milk or milk derivatives, egg, shellfish, peanuts, soy, artificial color, artificial flavor, and gluten.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="card">
						<img src="images/img-question.png" />
						<div class="qa">
							<p class="quest">Q: Who Should Not Take Neuroflexyn?</p>
							<p class="ans"><span>A:</span> Patients who are nursing, pregnant, who are taking other medications, or with previous health conditions, should consult a doctor or pediatrician first before using any supplements including Neuroflexyn.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="card">
						<img src="images/img-question.png" />
						<div class="qa">
							<p class="quest">Q: Where Else Can I Purchase Neuroflexyn?</p>
							<p class="ans"><span>A:</span> Neuroflexyn can only be purchased directly from our website. We also sell our product on Amazon. By handling the entire supply chain we can guarantee you maximum efficacy in every bottle.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="card">
						<img src="images/img-question.png" />
						<div class="qa">
							<p class="quest">Q: What Makes Neuroflexyn Better Than Others?</p>
							<p class="ans"><span>A:</span> Neuroflexyn uses a strategically selected set of powerful nootropics that when brought together may increase brain activity, mental performance and vigilance, given high-quality ingredients in a balanced formula.</p>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">

			<?php include("sidebar.php"); ?>

			</div>
		</div>

	</div>
	<div class="try-neuroflexyn">

		<?php include("try-neuroflexyn.php"); ?>
		
	</div>
	<?php include("footer-logo-sublinks.php"); ?>	
	<?php include("footer.php"); ?>

</div>