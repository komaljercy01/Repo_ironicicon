<?php 
session_start();
?><html>

<head>
<title>CTS</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../CSS/print.css" rel="stylesheet" media="print" type="text/css" />
<link href="../CSS/media.css" rel="stylesheet" media="screen" type="text/css" />
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">

<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">


</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
             <?php            // enter php to divert to login.php when appid and userid test fails
	// 
include 'config.php';
include 'opendb.php';
//$appidcheck = $_POST['appid'];
//$userid=$_POST['userid'];
$userid =  $_SESSION['USERAUTH'];
$appidcheck =  $_GET['appid'];
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;

//validates session

?>
             <?php
include 'config.php';
include 'opendb.php'; 
			 
 $query4="select USERNAME from user where USERID  = ".$userid;
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
?>
<script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>
<div id="logout_">
<form id="logout" action="logout.php" method="post">    
<table width="300" border="0" align="right" >
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" > Click here to Logout</a></td>
      </tr>
    </table>
</form></div>





<?php 


 ///////////////////USER INFORMATION PROTECTION//////////////////////////////////
 
 $appid_query_User="SELECT APPLICATION.USERID from APPLICATION where APPLICATIONID='$appidcheck'";
 $result_appid_query_User = @mysql_query($appid_query_User);
 while($row_result_appid_query_User=@mysql_fetch_array($result_appid_query_User))
 {$userid_appid = $row_result_appid_query_User['USERID'];}
 
 $userid_query_User="SELECT USER.USERID from USER where USERID='$userid'";
 $result_userid_query_User = @mysql_query($userid_query_User);
  while($row_result_userid_query_User=@mysql_fetch_array($result_userid_query_User))
  {$userid_userid = $row_result_userid_query_User['USERID'];}
  
  if($userid_userid==$userid_appid){}
  else {
  echo "You are not allowed to view this page";
  die();}
 
 
 
  ///////////////////USER INFORMATION PROTECTION//////////////////////////////////

$names= "SELECT *
FROM APPLICATION
WHERE APPLICATION.APPLICATIONID ='$appidcheck'
";

$namesquery = mysql_query($names); 

while($rownames = mysql_fetch_array( $namesquery )) {

$fname =  $rownames['FIRSTNAME'];
$lname =  $rownames['LASTNAME'];

} 
//echo $_SESSION['password_session_go_back'].$_SESSION['password_session'] ;
?>
<table  width="966"  border="1">
  
      <tr>
        <td  colspan="2" bgcolor=""><div align="center"><span class="style14" >Quotation</span></div></td>
      </tr>
      <tr>
        <td bgcolor=""><span  >Student Name:</span></td>
        <td bgcolor=""><span ><?php echo $fname." ".$lname; ?></span></td>
      </tr>
 </table>
<?php 
	  
echo "<table width='966'  border='1' > ";	  
$total = 0; 
$query4= "select COURSEAPP.APPLICATIONID , COURSEAPP.COID , COURSEOFFERING.COID , COURSEOFFERING.COURSEID, COURSEOFFERING.COST, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY , COURSEAPP.CAID   from courseapp, COURSEOFFERING , COURSE , PROGRAM 
where COURSEAPP.APPLICATIONID =".$appidcheck." 
and COURSEAPP.COID= COURSEOFFERING.COID 
and COURSEOFFERING.COURSEID=COURSE.COURSEID 
and COURSE.PROGRAMID=PROGRAM.PROGRAMID
Group by  PROGRAM.PROGRAMID
";


$result4 = mysql_query($query4);
while($row=mysql_fetch_array($result4))
{
$programid=$row['PROGRAMID'];
$programtitle=$row['TITLE'];


$query5="select COURSEAPP.APPLICATIONID , COURSEAPP.COID , COURSEOFFERING.COID , COURSEOFFERING.COURSEID, COURSEOFFERING.COST, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY , COURSEAPP.CAID   from courseapp, COURSEOFFERING , COURSE , PROGRAM 
where COURSEAPP.APPLICATIONID =".$appidcheck." 
and COURSEAPP.COID= COURSEOFFERING.COID 
and COURSEOFFERING.COURSEID=COURSE.COURSEID 
and PROGRAM.PROGRAMID =".$programid."
and COURSE.PROGRAMID =".$programid."
";

echo "<tr> <td bgcolor='#EFEBDE'  colspan='2' align='center'>".$programtitle."</td> </tr>";
$Subcost = 0; 
$result5 = mysql_query($query5);
while($row5=mysql_fetch_array($result5))
	
{


echo  "<tr> <td bgcolor='#F4F4F4'>".$row5['COURSETITLE']."</td> <td>$".$row5['COST'].".00</td> </tr>";
$Subcost = $row5['COST'] + $Subcost;
}

echo "<tr><td  align='right'>SUBCOST</td><td align='right'>$".$Subcost.".00</td>";
$total = $Subcost + $total;

if ( $row['CATEGORY'] == "TER"){
		$tertiary_count=1;}
else {}	
		
}// while($row=mysql_fetch_array($result4))
if ($tertiary_count >0 ){
echo "<tr> <td align='right'>Registration Fee </td> <td align='right'> $200.00 </td></tr>";
$new_total = $total+200; }
else {}


echo "<tr> <td align='right'>TOTAL COST </td> <td align='right'>$".$total.".00 </td></tr>";
echo "</table>";

?>
	  <div id="footer" > <table border="0">
        <tr>
          <td>Congratulations You have finished registered</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Please logout</td>
          <td>&nbsp;</td>
        </tr>
      </table></div>
      <p>
  <!--  <input type='submit' value='Previous Page' onClick="f1.action='courses.php'; return true;">     
      <input type='submit' value='Timetable Page' onClick="f1.action='schedule.php'; return true;"> 
      <input type='submit' value='DONE' onClick="f1.action='confirmation.php'; return true;">      -->
  </p>
        
  <!-- End Save for Web Slices -->

      <form name="f2">
      
      <input type='submit' value='Previous Page' onClick="f2.action='View_APR_DEN_user_app.php'; return true;">
    <!-- <input type="button" value=" Print this page "
onclick="window.print();return false;" />
-->
</form> 
</div>
</body>
</html>