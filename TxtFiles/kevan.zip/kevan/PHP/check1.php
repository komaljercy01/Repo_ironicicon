<?php
include 'config.php';
include 'opendb.php'; 
require_once('includes/FirePHP.class.php');
require_once('includes/fb.php');
$firephp =& FirePHP::getInstance(true);
ob_start();

// Get the variables.
$query = "UPDATE SEMESTER SET ACTIVE='on' WHERE SEMESTERID =".$_POST['feed_id']." " ;

mysql_query($query);
mysql_close($con);



?>
