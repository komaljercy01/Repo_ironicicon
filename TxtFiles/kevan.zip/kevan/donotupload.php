<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php 
if ( $row['CATEGORY'] == "TER1" || $row['CATEGORY'] == "TER2" || $row['CATEGORY'] == "TER3" || $row['CATEGORY'] == "TER4" || $row['CATEGORY'] == "TER5" || $row['CATEGORY'] == "TER6" )






$query_cat="select COURSEAPP.APPLICATIONID , COURSEAPP.COID , COURSEOFFERING.COID , COURSEOFFERING.COURSEID, COURSEOFFERING.COST, COURSE.COURSEID, COURSE.PROGRAMID , COURSE.COMPULSORY, COURSE.COURSETITLE , PROGRAM.PROGRAMID , PROGRAM.TITLE , PROGRAM.CATEGORY , COURSEAPP.CAID , REGFEE.CATEGORY , REGFEE.REGFEE from courseapp, COURSEOFFERING , COURSE , PROGRAM , REGFEE
where COURSEAPP.APPLICATIONID = '$appidcheck'
and COURSEAPP.COID= COURSEOFFERING.COID 
and COURSEOFFERING.COURSEID=COURSE.COURSEID 
and COURSE.PROGRAMID=PROGRAM.PROGRAMID 
AND PROGRAM.CATEGORY = REGFEE.CATEGORY
Group by  PROGRAM.PROGRAMID
";
$reg_fee = 0 ;	 
$result_query_cat = mysql_query($query_cat);
while($row_result_query_cat=mysql_fetch_array($result_query_cat))

{
$reg_fee = $row_result_query_cat['REGFEE'] + $reg_fee;
}



echo "<tr> <td align='right'>Registration Fee </td> <td align='right'> $".$reg_fee.".00 </td></tr>";
$total = $total+$reg_fee; }







$minus_cost =0;


if($row5['COST'] < 0){
$minus_cost =2;}

if($minus_cost > 1 ){echo "<tr> <td align='right'>Registration Fee (Not Applicable)</td> <td align='right'> $".$reg_fee.".00 </td></tr>";}
else {echo "<tr> <td align='right'>Registration Fee </td> <td align='right'> $".$reg_fee.".00 </td></tr>";}

?>
</body>
</html>
