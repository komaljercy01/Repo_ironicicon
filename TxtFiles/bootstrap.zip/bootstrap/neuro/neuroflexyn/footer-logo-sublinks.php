<div class="neuroflexyn-social-footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-12">
				<img class="img-responsive" src="images/logo.png" />
			</div>
			<div class="col-lg-9 col-md-9 col-sm-12">
				<ul>
					<li><a href="#" class="ajax-modal" data-url="terms">Terms & Conditions</a></li>
					<li><a href="#" class="ajax-modal" data-url="privacy">Privacy Policy</a></li>
					<li><a href="https://www.neuroflexyn.com/order_tracking.php" target="_blank">Track Order</a></li>
					<li><a href="">Blog</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
				</ul>
				<p class="notice">The statements made on this website have not been evaluated by the Food & Drug Administration. The FDA only evaluates foods and drugs, not supplements like these products. These products are not intended to diagnose, prevent, treat, or cure any disease. Individual results may vary.</p>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>