<?php 
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Vendor Payments</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
<script src="//oss.maxcdn.com/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.min.js"></script>

          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
    <style type="text/css">
/* Adjust feedback icon position */
#addVendor .form-control-feedback {
    right: 15px;
}
#addVendor .selectContainer .form-control-feedback {
    right: 25px;
}
</style>

</head>
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];

 $query4="select  USERTYPE from user where  USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'";
$result4 = mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$usertype = $row['USERTYPE'];
}



$SQLuserid = "select  * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}
else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>
<body>
<?php 
include 'config.php';
include 'opendb.php';
$vid_get = $_GET['vid'];

$quer_usersfor_course=mysql_query("
SELECT  *
FROM   Vendor
WHERE  
VendorID=$vid_get
");  
while($noticia = mysql_fetch_array($quer_usersfor_course)) {
$VendorName= $noticia['VendorName'];
$VendorDesc = $noticia['VendorDesc'];
$Vexpense = $noticia['Vexpense'];
$VendorCashAcct = $noticia['VendorCashAcct'];
$VendorAdd = $noticia['VendorAdd'];
$Vcity = $noticia['Vcity'];
$VendorPersonContact = $noticia['VendorPersonContact'];
$VendorPContact = $noticia['VendorPContact'];
$VendorSContact = $noticia['VendorSContact'];
$Vfax = $noticia['Vfax'];
$VendorAcctname = $noticia['VendorAcctname'];
$VendorPEmail = $noticia['VendorPEmail'];
$Vweb = $noticia['Vweb'];
$Vtype = $noticia['Vtype'];
$Vactive = $noticia['Vactive'];


}
?>
  <div class="row">
    <div class="col-md-8 col-md-offset-1">
      <form class="form-horizontal" role="form" action="addvendorpayment1Submit.php" method="post" id="addVendor">
        <fieldset>

          <!-- Form Name -->
          <legend>Add Vendor Payment</legend>

           <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Vendor Name</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="vname" id="vname" value="<?php echo $VendorName; ?>" readonly >
            </div>

            <label class="col-sm-2 control-label" for="textinput">Vendor Number</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="vnumber" id="vnumber" value="<?php echo $vid_get; ?>" readonly>
            </div>
          </div>

          
           <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Cheque Number</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="VchequeNo" id="VchequeNo" value="<?php echo $VchequeNo; ?>">
            </div>

            <label class="col-sm-2 control-label" for="textinput">Date</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="Date" id="Date" value="<?php echo $date; ?>">
            </div>
          </div>

          
 <input type="hidden"    name="vid" id="vid"     value="<?php echo $vid_get;?>" >

   <!-- drop down  input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Cash Account</label>
            <div class="col-sm-4">
<?php 

echo " <select name='cash' id='cash' class='form-control' > ";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
         </div>   
         </div>
         <!-- Text input-->
          <div class="form-group">
                       <label class="col-sm-2 control-label" for="textinput">Line Description</label>
            <div class="col-sm-10">
              <input type="text" placeholder="" class="form-control" name="Comment" id="Comment" value="">
            </div>
            </div>
             <div class="form-group">
             <label class="col-sm-2 control-label" for="textinput">Total Amount</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control" name="TAmount" id="TAmount" value="" readonly>
            </div>
          </div>    
      <div class="row">
    <div class="col-md-12 col-md-offset-0">      

  <div class="form-group">
             
              <label class="col-sm-3 control-label" for="textinput">Description</label>
               <label class="col-sm-3 control-label" for="textinput">Account</label>
              <label class="col-sm-3 control-label" for="textinput">Amount</label>
          </div>   
          
  <div class="form-group">
           
            <div class="col-sm-5">
            <textarea  placeholder="" class="form-control" name="Description1" id="Description1"  rows="2" > </textarea> 
            </div>
             <div class="col-sm-3">
          <?php 

echo " <select name='vaccountpay1' id='vaccountpay1' class='form-control' > ";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
            </div>
            <div class="col-sm-3">
              <input type="text" placeholder="" class="form-control" name="Amount1" id="Amount1" value="" >
            </div>
          </div>   
          
  <div class="form-group">
          
            <div class="col-sm-5">
              <textarea  placeholder="" class="form-control" name="Description2" id="Description2"  rows="2" > </textarea> 
              </div>
             <div class="col-sm-3">
            <?php 

echo " <select name='vaccountpay2' id='vaccountpay2' class='form-control' > ";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
            </div>
            <div class="col-sm-3">
              <input type="text" placeholder="" class="form-control" name="Amount2" id="Amount2" value="" >
            </div>
          </div>   
          
           <div class="form-group">
            
            <div class="col-sm-5">
              <textarea  placeholder="" class="form-control" name="Description3" id="Description3"  rows="2" > </textarea> 
              </div>
             <div class="col-sm-3">
            <?php 

echo " <select name='vaccountpay3' id='vaccountpay3' class='form-control' > ";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
            </div>
            <div class="col-sm-3">
              <input type="text" placeholder="" class="form-control" name="Amount3" id="Amount3" value="" >
            </div>
          </div>   
          
           <div class="form-group">
          
            <div class="col-sm-5">
              <textarea  placeholder="" class="form-control" name="Description4" id="Description4"  rows="2" > </textarea> 
              </div>
             <div class="col-sm-3">
            <?php 

echo " <select name='vaccountpay4' id='vaccountpay4' class='form-control' > ";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
            </div>
            <div class="col-sm-3">
              <input type="text" placeholder="" class="form-control" name="Amount4" id="Amount4" value="" >
            </div>
          </div>   
          
           <div class="form-group">
           
            <div class="col-sm-5">
              <textarea  placeholder="" class="form-control" name="Description5" id="Description5"  rows="2" > </textarea> 
              </div>
             <div class="col-sm-3">
            <?php 

echo " <select name='vaccountpay5' id='vaccountpay5' class='form-control' > ";
$acct_id_query = "
SELECT ACCOUNT.ACCTID, ACCOUNT.ACCTNAME, ACCOUNT.DESCRIPTION , ACCOUNT.ACTIVE , ACCOUNT.ACCTYPE , ACCOUNTTYPE.ACCTYPE, ACCOUNTTYPE.ACCTDESC from ACCOUNTTYPE , ACCOUNT 
where 
ACCOUNT.ACCTYPE = ACCOUNTTYPE.ACCTYPE 
ORDER BY ACCOUNT.ACCTID DESC
";	  
$result_acct_id_query= mysql_query($acct_id_query);

while($noticia_result_acct_id_query = mysql_fetch_array($result_acct_id_query)) {
	
echo "<option value='".$noticia_result_acct_id_query['ACCTID']."'>".$noticia_result_acct_id_query['ACCTNAME']." - ".$noticia_result_acct_id_query['DESCRIPTION']."</option>";
}
echo "</select>";
	?>
            </div>
            <div class="col-sm-3">
              <input type="text" placeholder="" class="form-control" name="Amount5" id="Amount5" value="" >
            </div>
          </div>   
          
          
</div>
</div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
                <button type="submit" class="btn btn-default">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
            </div>
      </div>
        </fieldset>
      </form>
    </div><!-- /.col-lg-12 -->
</div><!-- /.row -->

<script>
$(document).ready(function() {
    $('#addVendor').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            vname: {
                group: '.col-sm-10',
                validators: {
                    notEmpty: {
                        message: 'The name is required'
                    }
                }
            },
            vadd: {
                group: '.col-sm-10',
                validators: {
                    notEmpty: {
                        message: 'The Address is required'
                    }
                }
            },
            vpemail: {
                group: '.col-sm-4',
                validators: {
                    notEmpty: {
                        message: 'The email is required'
                    },
					 emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            },
			
			
            vpcontact: {
                group: '.col-sm-4',
                validators: {
                    notEmpty: {
                        message: 'The contact name is required'
                    }
                }
            }
        }
    });
});

</script>
</body>
</html>                                		