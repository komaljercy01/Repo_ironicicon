<html> 
<head>
<script language="javascript" src="../exam/scripts/script.js">
</script>
</head> 
<body> 

<table class="main">
<tr>
<td valign="top">

<?php

include '../exam/config.php';
include '../exam/opendb.php';

$formTitle = "ADMINISTRATION HOME";
?>
		<table class="sub">		
		<tr>
			<td>
				<p class="head2"><?php 	echo $formTitle;	?><br>
				<hr color="black">
				<p class="bold10">WELCOME. Here you can create, access and modify Academic Body, Course and Teacher information.
			</td>
		</tr>
		<tr>
			<td>
				<hr color="black">
				<p class="head2mar" align="left">ACADEMIC BODIES</p>
				<p class="head2mar" align="left">ACADEMIC BODIES</p>                
			</td>
		</tr>
		<tr>
			<td>
				<hr color="black">
				<p class="head2mar" align="left">PROGRAMMES</p>
				<p class="head2mar" align="left">PROGRAMMES</p>                
			</td>
		</tr>
		<tr>
			<td>
				<hr color="black">
				<p class="head2mar" align="left">TEACHERS</p>
				<p class="bold10" align="left"><a href="../exam/addTeacher.php">Add Teacher</a></p> 
				<p class="bold10" align="left"><a href="../exam/listTeacher.php">View Teachers</a></p>                                               
			</td>
		</tr>                					
		</table>	
</td>
</tr>
</table>

</body> 
</html> 