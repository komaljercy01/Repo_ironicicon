<?php 
session_start();
?>
	
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
</head>
<body >
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;
$_SESSION['username_session'];


?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>

		  <p>
  <?php
		  
///Previous values///////////////



//Previous values///////////////////////
//////////CURRENT VALUES////////////////////////////
$vid = mysql_real_escape_string($_POST['vid']);	
$vname = mysql_real_escape_string($_POST['vname']);		
$VendorDesc = mysql_real_escape_string($_POST['VendorDesc']);	  
$Vadd = mysql_real_escape_string($_POST['Vadd']);
$VendorAcctname = mysql_real_escape_string($_POST['VendorAcctname']);
$vcity = mysql_real_escape_string($_POST['vcity']);
$ContactPerson = mysql_real_escape_string($_POST['ContactPerson']);
//$vcountry = $_POST['vcountry'];
$vpemail = mysql_real_escape_string($_POST['vpemail']);
//$vsemail = mysql_real_escape_string($_POST['vsemail']);
$vpcontact = mysql_real_escape_string($_POST['vpcontact']);
$vscontact = mysql_real_escape_string($_POST['vscontact']);
$vfax = mysql_real_escape_string($_POST['vfax']);
$vweb = mysql_real_escape_string($_POST['vweb']);
$cash = mysql_real_escape_string($_POST['cash']);
$ARacct = mysql_real_escape_string($_POST['ARacct']);
$vactive = $_POST['vactive'];
include 'config.php';
include 'opendb.php';


$SQL1 = " UPDATE  VENDOR SET 
VendorName='$vname' , VendorDesc='$VendorDesc',
VendorAdd='$Vadd',VendorPEmail='$vpemail', VendorCashAcct='$cash',
 Vcity='$vcity', Vactive='$vactive',    VendorPContact='$vpcontact',
VendorPersonContact='$ContactPerson',VendorAcctname ='$VendorAcctname',
 VendorSContact='$vscontact', Vfax='$vfax', Vweb='$vweb', Vexpense='$ARacct'
WHERE
VENDORID=$vid
" ;

$result1 = mysql_query($SQL1);
//echo $SQL1;

if (!$result1){
echo 'An Error has occurred please click here to go back to the previous form , <a href="EditVendorSearch.php">here </a>';
echo $result;
echo $SQL1 ;
die();
}


  ?>
Success! You are being directed to Edit a Vendor in a few sconds.
If you wish to not wait, you can continue to 
<a href="EditVendorSearch.php">here </a></p> 
		  <p><script>setTimeout('window.location.replace("EditVendorSearch.php")', 1000);  </script> </p>
          </div>
</body>
</html>
