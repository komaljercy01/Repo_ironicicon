<div class="sidebar">
	<div class="srap-wrap">
		<a href="http://www.shopperapproved.com/reviews/neuroflexyn.com/" rel="nofollow" onclick="var nonwin=navigator.appName!='Microsoft Internet Explorer'?'yes':'no'; var certheight=screen.availHeight-90; window.open(this.href,'shopperapproved','location='+nonwin+',scrollbars=yes,width=620,height='+certheight+',menubar=no,toolbar=no'); return false;"> <img src="https://c813008.ssl.cf2.rackcdn.com/13541-med.jpg" style="border: 0" alt="Shopper Award" oncontextmenu="var d = new Date(); alert('Copying Prohibited by Law - This image and all included logos are copyrighted by shopperapproved \251 '+d.getFullYear()+'.'); return false;" /></a>
	</div>
	<a href="order.php"><img class="img-responsive" src="images/banner.jpg" /></a>
	<div class="srap-wrap">
		<a href="http://www.shopperapproved.com/reviews/neuroflexyn.com/" rel="nofollow" onclick="var nonwin=navigator.appName!='Microsoft Internet Explorer'?'yes':'no'; var certheight=screen.availHeight-90; window.open(this.href,'shopperapproved','location='+nonwin+',scrollbars=yes,width=620,height='+certheight+',menubar=no,toolbar=no'); return false;"> <img src="https://c813008.ssl.cf2.rackcdn.com/13541-med.jpg" style="border: 0" alt="Shopper Award" oncontextmenu="var d = new Date(); alert('Copying Prohibited by Law - This image and all included logos are copyrighted by shopperapproved \251 '+d.getFullYear()+'.'); return false;" /></a>
	</div>
	<div class="g-page" data-width="251" data-href="https://plus.google.com/113746446359106385986" data-rel="publisher"></div>
</div>