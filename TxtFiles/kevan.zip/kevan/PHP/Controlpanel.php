<?php 
include 'timeout.php';

?>
<html>
<head>
<title>CTS</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="../CSS/Local.css" rel="stylesheet" type="text/css">

<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script type='text/javascript' src='../jquery/js/jquery.js'></script>


<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">

<link type='text/css' rel='stylesheet' media='all' href='../CSS/screen.css' />

</head>
<body >
<div id="container">

<table width="800" border="0">
  
  <tr>
    <td>         
<?php
include 'config.php';
include 'opendb.php';


/*$adminusername = $_POST['Username'];
$password = $_POST['Password'];
$password = md5($password);*/

$password = $_SESSION['password_session'];
//$_SESSION['username_session'] = $adminusername ;
 if ($password=='382e0360e4eb7b70034fbaa69bec5786'){
 $passwd_change ='Alert your password was recently reset you must reset it immediately';
 }

$SQLuserid = "select * from  user where USERNAME = '".$adminusername."' OR USERNAME = '".$_SESSION['username_session']."' "; 
$resultid = mysql_query($SQLuserid);
while($row=mysql_fetch_array($resultid))
{
$password_from_row=$row['PASSWORD'] ;
$row_active_from_row=$row['ACTIVE'];
$usertype= $row['USERTYPE'];
$username= $row['USERNAME'];
$userid = $row['USERID'];
}
if($password_from_row == $password && $row_active_from_row==1 ){


$_SESSION['USERAUTH'] = $userid;}

else {echo '<p> Unable to log in <a href=index.html > click here </a> to login again bad passwd';
die();}



?>


   <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout"  id="logout">    
<table  width='95%' align="right">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
         <tr>
<td colspan="2"> <?php echo  $passwd_change; ?><a href="passwd_change.php"> Click here</a> to change your password</td>
</tr>
      <tr align="right">
        <td colspan="2">

<a href="javascript: submitform()" > Click here to Logout</a></td>
      </tr>
    </table></form>
    <h3>&nbsp;</h3>
    <p>&nbsp;</p>
    
          
           
              <?php
 //session validation  
 unset ($_SESSION['STU_ID']);
 $_SESSION['username'] = $username; // Must be already set
//////////////////////////////////////////////////////////////////chat/////////////////////////////////////////////////

//////////////////if admin then display//////////////////////////////////



//////////////////////////////////////////////////////chat/////////////////////////////////////////////////////////////
?>

<form id="accountInformation" name="accountInformation" action="../Adminaction.php"   method="post" >
            <table cellpadding="2" bgcolor="white" cellspacing="0" border="0" width="99%">
            
<?php
if($usertype =="AA" ){
include 'AA_admin.php';
include 'exam_index.php';

}// AA ?>
 
 
 <?php
if($usertype =="SA" ){ 
include 'SA_admin.php';
include 'exam_index.php'; } //SA ?>


 
 <?php
if($usertype =="MA" ){

include 'MA_admin.php';
//include 'exam_index.php';

} //MA ?>
 
 
 <?php
if($usertype =="DA" ){ 
include 'DA_admin.php';
include 'exam_index.php'; } //DA ?>
 


 <?php
if($usertype =="DEF" ){
include 'userpanel.php';
} //DA ?>

 <?php
if($usertype =="RA" ){

include 'RA_admin.php';


} //MA ?>

 <?php
if($usertype !="DA" && $usertype !="DEF"  && $usertype !="AA"  && $usertype !="MA" && $usertype !="RA" ){?>
<table width="800" border="0">
  <tr>
    <td>You are not authorized to view this page</td>
  </tr>
</table> 
<?php
echo " </form></td>
  </tr>
</table>


</div>
</body>
</html>";
die();

 } // Usertype not identified ?>
    </form></td>
  </tr>
</table>


</div>
</body>
</html>