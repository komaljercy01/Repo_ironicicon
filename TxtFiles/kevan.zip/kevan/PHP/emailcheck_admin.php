
<?php


if(isSet($_POST['email']))
{
$email = $_POST['email'];

include 'config.php';
include 'opendb.php';

$sql_check = mysql_query("select * from user where email='".$email."'") or die(mysql_error());

if(mysql_num_rows($sql_check))
{
echo '<font color="red">The email <STRONG>'.$email.'</STRONG> is already in use.</font>';

}
else
{
echo '<font color="green"><STRONG> email is available </STRONG> </font>';?>
<table border="1">
  <tr>
    <td>Usertype</td>
    <td><select name="usertype" size="1" id="usertype">
      <option value="DEF">Student</option>
      <option value="AA">Assitant admin</option>
      
    </select></td>
  </tr>
</table></td></tr>    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
</tr>
  </table>
<label>
  <input type="submit" name="Submit" id="Submit" value="Submit" <?php echo $submit ; ?>>
</label>
<?php 
}

}

?>