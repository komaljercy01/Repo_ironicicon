<?php 
session_start();
?>
	

<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">

	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.2/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/tabletools/2.2.3/css/dataTables.tableTools.css">
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" language="javascript" src="//cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="//cdn.datatables.net/tabletools/2.2.3/js/dataTables.tableTools.min.js"></script>
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->


        
<title>Choose vendor to add payments</title>
<head>
</head>
  
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];
$formnum=2;
$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>
<body id="dt_example">
		<div id="container">
		
	

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>

<?php 



include 'config.php';
include 'opendb.php';

$quer_usersfor_course=mysql_query("

SELECT  *
FROM   Vendor
WHERE  1


");  

?>
<div id="container">
		<div id="demo">
<table  width="100%" class='display' id='example' cellpadding='0' cellspacing='0' border='1'> 
    <thead>
    		<tr>
          
            <th >Name</th>
             <th>Number</th>
          <th>Contact</th>
                <th >Email</th>
            <th>Address</th>               
                <th >Active</th>
              

          </tr>
    </thead>
    <tbody>
   
   
  
 
<?php




/////////////////////////////////////////////////////////create temp table//////////////////////////////////////////////////
include 'config.php';
include 'opendb.php';

?>


    <div class="col-md-12 col-md-offset-1">
      <form class="form-horizontal" role="form" action="addvendorpaymentbill1.php" method="post" id="selectMultiplebills">
  
  <?php

while($noticia = mysql_fetch_array($quer_usersfor_course)) {
//	$inputString_post.= "'".$noticia['USERNAME']."',";
$vendorid = $noticia['VendorID'];
$vendorname = $noticia['VendorName'];
echo "<tr>";
echo "<td> <a href='addvendorpaymentbill1.php?vid=".$vendorid."'>".$vendorname."</a></td>";
echo "<td>".$noticia['VendorPEmail']."</td>";
echo "<td>".$noticia['VendorPContact']."</td>";
echo "<td>".$noticia['Vcity']."</td>";
echo "<td>".$noticia['Vcountry']."</td>";
echo "<td>".$noticia['Vweb']."</td>";

echo "</tr>";	

}

?>

    </tbody>
    
</table>


    
</div>
		



    
</form>


        <script type="text/javascript" charset="utf-8">
$(document).ready(function() {
    var selected = [];
 
    $("#example").dataTable({
        "processing": true
    });
 
    
} );
    </script>
</body>
</html>