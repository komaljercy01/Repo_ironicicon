<?php
// config.php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'root';

$dbname = 'elance';
//$dbpass = '6-108E4adfn2A!Li';
//define("SITE_URL","http://elance.localhost.com/PHP/");

include 'opendb.php';
include 'loginCheck.php';
?>