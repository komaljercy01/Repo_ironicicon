<?php 
session_start();
?>
<html>
<head>
<title>CTS</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

  <LINK rel="stylesheet" href="../css/style1.css" type="text/css">
  

<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>

<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">

</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="container">
<p>
  <?php

include 'config.php';
include 'opendb.php';

$userid = $_SESSION['USERAUTH'];

$username = $_POST['Username'];
$password = $_POST['Password'];
$password = md5($password);

$_SESSION['password_session'] = $password;
$_SESSION['username_session'] = $username ;



$SQLuserid = "select * from  user where USERNAME='".$username."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){
$userid = $row['USERID'];
include 'userpanel.php';
}

elseif ($row['PASSWORD'] == $password && ($row['ACTIVE']!=1 || $row['ACTIVE']!=0) ) {

include 'login.html';
echo  "Account was not activated please click <a href='http://localhost/CTS/resend_activation.html'>here </a> to resend validation email";	}

else{

include 'login.html';
echo  "Username or password is incorrect please try again";	

}


} // if($row=mysql_fetch_array($resultid))
else{

include 'login.html';
echo  "Username or password is incorrect please try again";	

}

?>

</div>
</body>
</html>