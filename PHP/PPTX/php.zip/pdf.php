<?php
require("class.filetotext.php");
if(isset($_POST['hiddenValue']))
{
	//Upload file to "file" folder
	$MIMEType=$_POST['format'];
	$filePath="file/".$_FILES["fileInput"]["name"];
	move_uploaded_file($_FILES["fileInput"]["tmp_name"], $filePath);
	$Values="";
	//set upload limit to 10MiB
	if($MIMEType=="pdf")
	{	
		$docObj = new Filetotext($filePath);
		$Values = $docObj->convertToText();
		//=$a->output();
		// echo $filePath;
		// echo file_get_contents($filePath);
	}
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>TExtracter | Extract texts from PPTX and PDF</title>
    <script src="scripts/jquery.js"></script>
    <script src="scripts/bootstrap.js"></script>
    <link href="styles/bootstrap.css" rel="stylesheet" />
	<script src="scripts/custom1.js"></script>
</head>
<body>
    <!--Nav bar-->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="display: block;">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">
                    <p>TExtract</p>
                </a>
            </div>
            <div class="collapse navbar-collapse" id="collapse" style="height: 90px;">
                <ul class="nav navbar-nav">
                    <li><a id="register" href="index.php">Extract From PPTX</a></li>
                    <li><a id="login" href="pdf.php">Extract From PDF</a></li>
					<li><a id="ContactUs" href="#ContactUs">Contact Us</a></li>
					<li><a id="AboutUs" href="#AboutUs">About Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
	<div class="col-lg-12">
		<div class="container" style="border:1px solid;display:table;height:100%;margin-top:60px;padding:0px 0px 30% 10px;">
			<p class="page-header" style="text-align:center;font-size:28px;">Text Extracter from PDF</p>
			<div class="col-md-6">
				<div class="col-md-12">
					<form action="pdf.php" method="post" enctype="multipart/form-data">
						<label for="fileInput">Select the PDF file</label>
						<input type="file" name="fileInput" id="fileInput"></input>
						<button class="btn btn-default col-xs-12" disabled="disabled" style="margin-top:5px;" type="submit" id="submitButton">UploadFile</button>
						<input type="hidden" name="hiddenValue"  value="true"/>
						<input type="hidden" name="format" id="format" />
					</form>
				</div>
				<div class="col-md-12">
					<div id="errorDiv" class="alert alert-danger alert-dismissible" role="alert" style="display:none;margin-top:10px;">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<strong>Error Found!</strong> Please upload a pdf file
					</div>
				</div>
			</div>
			<div class="col-md-6" style="border-left:1px solid #eee;display:table;height:100%;">
				<p class="page-header">Extracted text comes below</p>
				<div id="ExtractedText" class="col-md-12">
					<p><?php 
					if(isset($Values))
					{	
						echo $Values."</b></p><br/>";
					}
					?></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>