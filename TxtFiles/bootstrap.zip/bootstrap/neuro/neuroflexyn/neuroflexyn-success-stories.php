<?php include("header.php"); ?>

<div class="testimonial-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12">
				<h1>TESTIMONIALS</h1>
				<p class="subheader-caption">SEE WHAT PEOPLE ARE SAYING ABOUT NEUROFLEXYN</p>
				<p class="info">Now that you have heard the claims made by experts and done some of your own research, we feel the best way to express the real power of Neuroflexyn as your new health supplement is by showing you the comments of clients who have already tried it and are willing to share their results.</p>
				<p class="info">After trying Neuroflexyn please be sure to let us know how well it worked for you and if you are willing to share your experiences online with others, just let us know that we have your permission to post them here on our website.</p>

				<div class="blue-bar">
					<p class="caption">TELL US ABOUT YOUR EXPERIENCE</p>
					<div class="social">
						<a href="."><img src="images/img-verified.jpg" /></a>
						<a href="https://www.facebook.com/neuroflexyn" target="_blank"><img src="images/img-fb.jpg" /></a>
						<a href="."><img src="images/img-trustlink.jpg" /></a>
					</div>
					<div class="clearfix"></div>
				</div>

				<div class="testimonial-content">
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">This stuff is awesome.</div>
							<div class="body">I can have a productive day without a crash and get a lot done. When I first took it I didn't know what to think, but I felt good and I was in a good mood. I read a lot so this helps me stay focused and concentrate more. Thank you, great job guys!!</div>
							<div class="quote-by">Ramon C - Las Vegas, NV</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I've been using Neuroflexyn for 3 weeks and am so grateful to have found a natural product that produces results like this.</div>
							<div class="body">I have researched over the last couple of years, and have found a lot LIKE Neuroflexyn. However this particular formula is the "cherry on the top", as it brings such smooth execution and clarity to my everyday life. I am so grateful to have found this product, THANKS NEUROFLEXYN!</div>
							<div class="quote-by">Janay W - San Diego, CA</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">Before using Neuroflexyn I had trouble focusing daily at tasks that needed to be completed.</div>
							<div class="body">Neuroflexyn seemed to be too good to be true. I researched the "Brain Blend" ingredients so I said "Why Not?" It's been 2 months and I'm excited to say, the fog has lifted!!! It does not make me feel jittery or nervous. Just sustained clarity & with that confidence that I never had before! I even sleep better and am in a better mood daily. I can accomplish more with less setbacks.....even my relationships have improved. I know I have Neuroflexyn to thank for all these substantial improvements! I'm still 100% me, but I'm like the high def version of my former self! Thank you so much Neuroflexyn!</div>
							<div class="quote-by">Melissa Z - Tarawa Terrace, NC</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I have been taking Neuroflexyn daily over the past 2 weeks and...</div>
							<div class="body">have noticed a difference in my cognitive processing skills and memory, as well as my ability to attend to detail. While I don't consider Neuroflexyn to be a "wonder" bill, I plan to continue to use it to supplement to my current regiment of things I currently do and take to keep my mind as sharp as posible.</div>
							<div class="quote-by">Richard K - Austin, TX</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">My mind seems to be much sharper and I can focus easier.</div>
							<div class="body">I'm a chronic multi-tasker, and I feel I have the ability to accomplish more in less time. I have given some to my assistant, and she keeps asking for more. I am re-ordering for myself and all my employees. I would recommend anyone to give it a try!</div>
							<div class="quote-by">Rick O - Alpharetta, GA</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I have been a user of Neuroflexyn for approximately 30 days now.</div>
							<div class="body">After using this product I have noticed that my memory function has substantially increased. It seems that I am thinking more outside the box. That phrase has taken on a whole new meaning for me. It is great. I plan on continuing to take this product to see what can happen in my future.</div>
							<div class="quote-by">Stephen C - Denton, TX</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I have been using this product for about one month now and it is literally changing my life in wonderful ways.</div>
							<div class="body">I have noticed fantastic changes in my mood, my mental sharpness/memory and in my clarify of thought. I am much happier and my days at work are considerably more peaceful and fulfilling without all the mental and emotional drain as before. This product is an absolute life changer on many levels! I will continue to use this product for as long as it's available. Thank you all at the Neuroflexyn team. Many blessings!</div>
							<div class="quote-by">Brian L - Woodbridge, VA</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I started off taking Addium. 2 weeks into it I switched to Neuroflexyn.</div>
							<div class="body">I could feel the Neuroflexyn working in 15 min. With Neuroflexyn backing me, I get so much done and still have the energy to work out. I am a customer for life. Thank you for a such a wonderful product.</div>
							<div class="quote-by">Corey W - Freeport, TX</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I received my bottle two weeks ago and I am pleased to say after a couple of days on this product I feel more focused in the gym.</div>
							<div class="body">My work outs are more intense because I am more focused on the matter at hand. I wake up with energy and vigor. My mind is in a state of euphoria, I am generally in a better state of mind. Thanks for making this great product.</div>
							<div class="quote-by">Rodman L - North Plainfield, NJ</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">The pill works great in every aspect it is advertised.</div>
							<div class="body">I have taken other brain enhancing pills before, but they did not like the Neuroflexyn does. It's like I was walking around before with my brain on sleep mode, now that I have the Neuroflexyn, it's more like I woke up my brain and can see everything clearly without any fog.</div>
							<div class="quote-by">Cody B - San Antonio, TX</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I started taking Neuroflexyn and almost immediately noticed that I had more focus and concentration.</div>
							<div class="body">Within a few days I found that I stopped noticing the time and would work for 3 or 4 hours in a row without needing a break. I also found that I got more work done in that timespan than I used to get done in a day.</div>
							<div class="quote-by">Keith W - Anaheim, CA</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
					<div class="card">
						<img src="images/img-quote.png" />
						<div class="content">
							<div class="title">I came across Neuroflexyn about a mont or so back online and I was a little skeptical about the product.</div>
							<div class="body">I personally have used this product for about 2 weeks now and in the beginning I didn't think it was doing much until about after 1 week of taking the supplement and I did notice that was focusing more on my workflow at my company and I feel a lot more productive. I would definitely recommend this product as it assists with increasing your daily productivity, no matter if it's at work or in your personal life.</div>
							<div class="quote-by">Patrick C - Bridgewater, MA</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<p class="res-vary">Results Not Typical. Results Will Vary.</p>
				</div>
				<img class="img-responsive amazon-review" src="images/reviews-amazon.png" />
				<p class="res-vary">Results Not Typical. Results Will Vary.</p>

				<div class="note">
					<p><strong>PLEASE NOTE:</strong> While real consumers like you reported the following results after using our brand of Neuroflexyn, each testimonial merely represents the personal experience of the particular consumer and should not be interpreted as an endorsement that you will achieve the same results. Each consumer's experience is different, and different consumers experience different results. In many cases, these customers were given a complimentary bottle(s) of Neuroflexyn for sharing their experiences.</p>
					<p>Results Not Typical. Results Will Vary.</p>
				</div>
				<button>Rush My Order!</button>
			</div>

			<div class="col-lg-4 col-md-4 col-sm-12">

			<?php include("sidebar.php"); ?>

			</div>
		</div>

	</div>
	<div class="try-neuroflexyn">

		<?php include("try-neuroflexyn.php"); ?>
		
	</div>
	<?php include("footer-logo-sublinks.php"); ?>	
	<?php include("footer.php"); ?>

</div>