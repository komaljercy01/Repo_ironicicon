<?php
session_start();
?>
<html> 
<head>
<script language="javascript" src="scripts/script.js">
</script>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">

	<link type="text/css" href="../css/jquery.ui.all.css" rel="stylesheet" /> 
	<script type="text/javascript" src="../scripts/jquery-1.4.2.js"></script> 
	<script type="text/javascript" src="../scripts/jquery.ui.core.js"></script> 
	<script type="text/javascript" src="../scripts/jquery.ui.widget.js"></script> 
	<script type="text/javascript" src="../scripts/jquery.ui.datepicker.js"></script> 
	<!--<link type="text/css" href="../CSS/demos.css" rel="stylesheet" /> -->
	<script type="text/javascript"> 
	$(function() {
		$(".datepicker").datepicker();
	});
	</script> 
</head> 
<body> 
<div id="container">
<table >
<tr>
<td align="center" valign="top">
<?php

include 'config.php';
if ($usertype =="MA" )
{

?>
<table>
	<tr><td>
			MENU: <a href="Controlpanel.php">Home</a> > <a href="searchPeople.php">Search</a> > <span >Edit Student</span>
	</td></tr>
</table>

<?php

	if ($_POST['studentId'])
	{	
		$studentId = $_POST['studentId'];
		$que = mysql_query("SELECT * FROM STUDENT WHERE STUDENTID=$studentId");
		$row = mysql_fetch_array($que);
		
		// CHECK FOR STUDENT					
		if (mysql_num_rows($que) > 0)
		{	
			if ($_POST['submitCheck'] == true)
			{  
				$fName = mysql_real_escape_string(trim($_POST['fName']));
				$lName = mysql_real_escape_string(trim($_POST['lName']));
				$title = $_POST['title'];
				$gender = $_POST['gender'];
				$dob = $_POST['dob'];
				$address1 = $_POST['address1'];
				$address2 = $_POST['address2'];
				$city = $_POST['city'];
				$country = $_POST['country'];
				$mailAddress1 = $_POST['mailAddress1'];
				$mailAddress2 = $_POST['mailAddress2'];
				$companyName = $_POST['companyName'];
				$occupation = $_POST['occupation'];
				$idType = $_POST['idType'];
				$idNumber = $_POST['idNumber'];
				$phone1 = $_POST['phone1'];
				$phone2 = $_POST['phone2'];
				$phone3 = $_POST['phone3'];
				$contactName = $_POST['contactName'];
				$contactRelationship = $_POST['contactRelationship'];
				$contactPh1 = $_POST['contactPh1'];
				$contactPh2 = $_POST['contactPh2'];	
				$balance = $_POST['balance'];					
				
				$err = false;
				
			// CHECK FOR ERRORS	
				if (empty($fName))
				{	
					$notes .= 'First name cannot be left blank<br>';
					$err = true;
					$orgName = $row['FNAME'];
				}
				
				if (empty($lName))
				{	
					$notes .= 'Last name cannot be left blank<br>';
					$err = true;
					$orgName = $row['LNAME'];
				}
							
				if (empty($title))
				{	
					$notes .= 'Title cannot be left blank<br>';
					$err = true;
					$orgName = $row['TITLE'];
				}
				
				if (empty($gender))
				{	
					$notes .= 'Please select a gender.<br>';
					$err = true;
					$orgName = $row['GENDER'];
				}
														
				if ($err == false)
				{
					$insertSta = "UPDATE STUDENT SET FIRSTNAME='$fName', LASTNAME='$lName', TITLE='$title', GENDER='$gender',DOB='$dob', ADDRESS1='$address1',ADDRESS2='$address2',CITY='$city',COUNTRY='$country',MAILADDRESS1='$mailAddress1',MAILADDRESS2='$mailAddress2',COMPANYNAME='$companyName',OCCUPATION='$occupation',IDTYPE='$idType',IDNUMBER='$idNumber',PHONE1='$phone1',PHONE2='$phone2',PHONE3='$phone3',CONTACTNAME='$contactName',CONTACTRELATIONSHIP='$contactRelationship',CONTACTPH1='$contactPh1',CONTACTPH2='$contactPh2',BALANCE='$balance' WHERE STUDENTID=$studentId";
					 
					if (mysql_query($insertSta))
					{	$notes = 'Student updated.';	}
					else
					{	$notes = 'A database error occurred. The student may not have been updated successfully.';	}
				}
			}
			else
			{
				$fName = $row['FIRSTNAME'];
				$lName = $row['LASTNAME'];
				$title = $row['TITLE'];
				$gender = $row['GENDER'];
				$dob = $row['DOB'];
				$address1 = $row['ADDRESS1'];
				$address2 = $row['ADDRESS2'];
				$city = $row['CITY'];
				$country = $row['COUNTRY'];
				$mailAddress1 = $row['MAILADDRESS1'];
				$mailAddress2 = $row['MAILADDRESS2'];
				$companyName = $row['COMPANYNAME'];
				$occupation = $row['OCCUPATION'];
				$idType = $row['IDTYPE'];
				$idNumber = $row['IDNUMBER'];
				$phone1 = $row['PHONE1'];
				$phone2 = $row['PHONE2'];
				$phone3 = $row['PHONE3'];
				$contactName = $row['CONTACTNAME'];
				$contactRelationship = $row['CONTACTRELATIONSHIP'];
				$contactPh1 = $row['CONTACTPH1'];
				$contactPh2 = $row['CONTACTPH2'];	
				$balance = $row['BALANCE'];		
			}
			
			$uId = $row['USERID'];
			$uName = mysql_query("SELECT USERNAME FROM USER WHERE USERID='$uId'");
			$uName = mysql_fetch_array($uName);
			$uName = $uName[0];
			
			if ($active == "Y")
			{	$actCheck = "checked";	}
			else
			{	$actCheck = "";			}
			
		// SHOW FORM
		?>
				<table >
				<tr>
					<td align="left" colspan="4">
					
						<p class="head2"><?php 	echo $formTitle;	?><br>
						<hr color="black">		
						<p class="error"><?php 	echo $notes;		?><br>
			
					</td>
				</tr>
			<form name="editBody" method="POST" action="editStudent.php">	
			<tr>
				<td align="left" width="150">
					User Name: 
				</td>
				<td align="left" colspan="3"><?php echo $uName; ?>			
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					First Name: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="fName" value="<?php echo $fName; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left">
					Last Name: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="lName" value="<?php echo $lName; ?>">							
				</td>			
			</tr>
			
			<tr>
				<td align="left">
					Title: 
				</td>
				<td align="left" width="100">
					<select name="title">
						<option><?php echo $title; ?></option>
						<option>Dr.</option>
						<option>Mr.</option>
						<option>Ms.</option>
						<option>Mrs.</option>
					</select>				</td>			

				<td align="left" width="80">
					Gender: 
				</td>
				<td align="left">
					<select name="gender" >
						<option><?php echo $gender; ?></option>
						<option>M</option>
						<option>F</option>
					</select>							
				</td>			
			</tr>	
			<tr>
				<td align="left" width="150">
					Date of Birth: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="dob"  class="datepicker" value="<?php echo $dob; ?>">							
				</td>			
			</tr>		
			<tr>
				<td align="left" width="150">
					Address 1: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="address1" value="<?php echo $address1; ?>">							
				</td>			
			</tr>	
			<tr>
				<td align="left" width="150">
					Address 2: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="address2" value="<?php echo $address2; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					City: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="city" value="<?php echo $city; ?>">							
				</td>			
			</tr>	
			<tr>
				<td align="left" width="150">
					Country: 
				</td>
				<td align="left" colspan="3">
					<select name="country">
					<option value="<?php echo $country; ?>"><?php echo $country; ?></option>
					
        <option value="Trinidad and Tobago">Trinidad and Tobago</option> 
		<option value="Canada">Canada</option> 
		<option value="United Kingdom" >United Kingdom</option>
		<option value="Ireland" >Ireland</option>
		<option value="Australia" >Australia</option>
		<option value="New Zealand" >New Zealand</option>
		<option value="null">-------------------</option>
		<option value="Afghanistan">Afghanistan</option> 
		<option value="Albania">Albania</option> 
		<option value="Algeria">Algeria</option> 
		<option value="American Samoa">American Samoa</option> 
		<option value="Andorra">Andorra</option> 
		<option value="Angola">Angola</option> 
		<option value="Anguilla">Anguilla</option> 
		<option value="Antarctica">Antarctica</option> 
		<option value="Antigua and Barbuda">Antigua and Barbuda</option> 
		<option value="Argentina">Argentina</option> 
		<option value="Armenia">Armenia</option> 
		<option value="Aruba">Aruba</option> 
		<option value="Australia">Australia</option> 
		<option value="Austria">Austria</option> 
		<option value="Azerbaijan">Azerbaijan</option> 
		<option value="Bahamas">Bahamas</option> 
		<option value="Bahrain">Bahrain</option> 
		<option value="Bangladesh">Bangladesh</option> 
		<option value="Barbados">Barbados</option> 
		<option value="Belarus">Belarus</option> 
		<option value="Belgium">Belgium</option> 
		<option value="Belize">Belize</option> 
		<option value="Benin">Benin</option> 
		<option value="Bermuda">Bermuda</option> 
		<option value="Bhutan">Bhutan</option> 
		<option value="Bolivia">Bolivia</option> 
		<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option> 
		<option value="Botswana">Botswana</option> 
		<option value="Bouvet Island">Bouvet Island</option> 
		<option value="Brazil">Brazil</option> 
		<option value="British Indian Ocean Territory">British Indian Ocean Territory</option> 
		<option value="Brunei Darussalam">Brunei Darussalam</option> 
		<option value="Bulgaria">Bulgaria</option> 
		<option value="Burkina Faso">Burkina Faso</option> 
		<option value="Burundi">Burundi</option> 
		<option value="Cambodia">Cambodia</option> 
		<option value="Cameroon">Cameroon</option> 
		<option value="Canada">Canada</option> 
		<option value="Cape Verde">Cape Verde</option> 
		<option value="Cayman Islands">Cayman Islands</option> 
		<option value="Central African Republic">Central African Republic</option> 
		<option value="Chad">Chad</option> 
		<option value="Chile">Chile</option> 
		<option value="China">China</option> 
		<option value="Christmas Island">Christmas Island</option> 
		<option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option> 
		<option value="Colombia">Colombia</option> 
		<option value="Comoros">Comoros</option> 
		<option value="Congo">Congo</option> 
		<option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option> 
		<option value="Cook Islands">Cook Islands</option> 
		<option value="Costa Rica">Costa Rica</option> 
		<option value="Cote D'ivoire">Cote D'ivoire</option> 
		<option value="Croatia">Croatia</option> 
		<option value="Cuba">Cuba</option> 
		<option value="Cyprus">Cyprus</option> 
		<option value="Czech Republic">Czech Republic</option> 
		<option value="Denmark">Denmark</option> 
		<option value="Djibouti">Djibouti</option> 
		<option value="Dominica">Dominica</option> 
		<option value="Dominican Republic">Dominican Republic</option> 
		<option value="Ecuador">Ecuador</option> 
		<option value="Egypt">Egypt</option> 
		<option value="El Salvador">El Salvador</option> 
		<option value="Equatorial Guinea">Equatorial Guinea</option> 
		<option value="Eritrea">Eritrea</option> 
		<option value="Estonia">Estonia</option> 
		<option value="Ethiopia">Ethiopia</option> 
		<option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option> 
		<option value="Faroe Islands">Faroe Islands</option> 
		<option value="Fiji">Fiji</option> 
		<option value="Finland">Finland</option> 
		<option value="France">France</option> 
		<option value="French Guiana">French Guiana</option> 
		<option value="French Polynesia">French Polynesia</option> 
		<option value="French Southern Territories">French Southern Territories</option> 
		<option value="Gabon">Gabon</option> 
		<option value="Gambia">Gambia</option> 
		<option value="Georgia">Georgia</option> 
		<option value="Germany">Germany</option> 
		<option value="Ghana">Ghana</option> 
		<option value="Gibraltar">Gibraltar</option> 
		<option value="Greece">Greece</option> 
		<option value="Greenland">Greenland</option> 
		<option value="Grenada">Grenada</option> 
		<option value="Guadeloupe">Guadeloupe</option> 
		<option value="Guam">Guam</option> 
		<option value="Guatemala">Guatemala</option> 
		<option value="Guinea">Guinea</option> 
		<option value="Guinea-bissau">Guinea-bissau</option> 
		<option value="Guyana">Guyana</option> 
		<option value="Haiti">Haiti</option> 
		<option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option> 
		<option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option> 
		<option value="Honduras">Honduras</option> 
		<option value="Hong Kong">Hong Kong</option> 
		<option value="Hungary">Hungary</option> 
		<option value="Iceland">Iceland</option> 
		<option value="India">India</option> 
		<option value="Indonesia">Indonesia</option> 
		<option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option> 
		<option value="Iraq">Iraq</option> 
		<option value="Ireland">Ireland</option> 
		<option value="Israel">Israel</option> 
		<option value="Italy">Italy</option> 
		<option value="Jamaica">Jamaica</option> 
		<option value="Japan">Japan</option> 
		<option value="Jordan">Jordan</option> 
		<option value="Kazakhstan">Kazakhstan</option> 
		<option value="Kenya">Kenya</option> 
		<option value="Kiribati">Kiribati</option> 
		<option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option> 
		<option value="Korea, Republic of">Korea, Republic of</option> 
		<option value="Kuwait">Kuwait</option> 
		<option value="Kyrgyzstan">Kyrgyzstan</option> 
		<option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option> 
		<option value="Latvia">Latvia</option> 
		<option value="Lebanon">Lebanon</option> 
		<option value="Lesotho">Lesotho</option> 
		<option value="Liberia">Liberia</option> 
		<option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option> 
		<option value="Liechtenstein">Liechtenstein</option> 
		<option value="Lithuania">Lithuania</option> 
		<option value="Luxembourg">Luxembourg</option> 
		<option value="Macao">Macao</option> 
		<option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option> 
		<option value="Madagascar">Madagascar</option> 
		<option value="Malawi">Malawi</option> 
		<option value="Malaysia">Malaysia</option> 
		<option value="Maldives">Maldives</option> 
		<option value="Mali">Mali</option> 
		<option value="Malta">Malta</option> 
		<option value="Marshall Islands">Marshall Islands</option> 
		<option value="Martinique">Martinique</option> 
		<option value="Mauritania">Mauritania</option> 
		<option value="Mauritius">Mauritius</option> 
		<option value="Mayotte">Mayotte</option> 
		<option value="Mexico">Mexico</option> 
		<option value="Micronesia, Federated States of">Micronesia, Federated States of</option> 
		<option value="Moldova, Republic of">Moldova, Republic of</option> 
		<option value="Monaco">Monaco</option> 
		<option value="Mongolia">Mongolia</option> 
		<option value="Montserrat">Montserrat</option> 
		<option value="Morocco">Morocco</option> 
		<option value="Mozambique">Mozambique</option> 
		<option value="Myanmar">Myanmar</option> 
		<option value="Namibia">Namibia</option> 
		<option value="Nauru">Nauru</option> 
		<option value="Nepal">Nepal</option> 
		<option value="Netherlands">Netherlands</option> 
		<option value="Netherlands Antilles">Netherlands Antilles</option> 
		<option value="New Caledonia">New Caledonia</option> 
		<option value="New Zealand">New Zealand</option> 
		<option value="Nicaragua">Nicaragua</option> 
		<option value="Niger">Niger</option> 
		<option value="Nigeria">Nigeria</option> 
		<option value="Niue">Niue</option> 
		<option value="Norfolk Island">Norfolk Island</option> 
		<option value="Northern Mariana Islands">Northern Mariana Islands</option> 
		<option value="Norway">Norway</option> 
		<option value="Oman">Oman</option> 
		<option value="Pakistan">Pakistan</option> 
		<option value="Palau">Palau</option> 
		<option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option> 
		<option value="Panama">Panama</option> 
		<option value="Papua New Guinea">Papua New Guinea</option> 
		<option value="Paraguay">Paraguay</option> 
		<option value="Peru">Peru</option> 
		<option value="Philippines">Philippines</option> 
		<option value="Pitcairn">Pitcairn</option> 
		<option value="Poland">Poland</option> 
		<option value="Portugal">Portugal</option> 
		<option value="Puerto Rico">Puerto Rico</option> 
		<option value="Qatar">Qatar</option> 
		<option value="Reunion">Reunion</option> 
		<option value="Romania">Romania</option> 
		<option value="Russian Federation">Russian Federation</option> 
		<option value="Rwanda">Rwanda</option> 
		<option value="Saint Helena">Saint Helena</option> 
		<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
		<option value="Saint Lucia">Saint Lucia</option> 
		<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option> 
		<option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option> 
		<option value="Samoa">Samoa</option> 
		<option value="San Marino">San Marino</option> 
		<option value="Sao Tome and Principe">Sao Tome and Principe</option> 
		<option value="Saudi Arabia">Saudi Arabia</option> 
		<option value="Senegal">Senegal</option> 
		<option value="Serbia and Montenegro">Serbia and Montenegro</option> 
		<option value="Seychelles">Seychelles</option> 
		<option value="Sierra Leone">Sierra Leone</option> 
		<option value="Singapore">Singapore</option> 
		<option value="Slovakia">Slovakia</option> 
		<option value="Slovenia">Slovenia</option> 
		<option value="Solomon Islands">Solomon Islands</option> 
		<option value="Somalia">Somalia</option> 
		<option value="South Africa">South Africa</option> 
		<option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option> 
		<option value="Spain">Spain</option> 
		<option value="Sri Lanka">Sri Lanka</option> 
		<option value="Sudan">Sudan</option> 
		<option value="Suriname">Suriname</option> 
		<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option> 
		<option value="Swaziland">Swaziland</option> 
		<option value="Sweden">Sweden</option> 
		<option value="Switzerland">Switzerland</option> 
		<option value="Syrian Arab Republic">Syrian Arab Republic</option> 
		<option value="Taiwan, Province of China">Taiwan, Province of China</option> 
		<option value="Tajikistan">Tajikistan</option> 
		<option value="Tanzania, United Republic of">Tanzania, United Republic of</option> 
		<option value="Thailand">Thailand</option> 
		<option value="Timor-leste">Timor-leste</option> 
		<option value="Togo">Togo</option> 
		<option value="Tokelau">Tokelau</option> 
		<option value="Tonga">Tonga</option> 
		<option value="Tunisia">Tunisia</option> 
		<option value="Turkey">Turkey</option> 
		<option value="Turkmenistan">Turkmenistan</option> 
		<option value="Turks and Caicos Islands">Turks and Caicos Islands</option> 
		<option value="Tuvalu">Tuvalu</option> 
		<option value="Uganda">Uganda</option> 
		<option value="Ukraine">Ukraine</option> 
		<option value="United Arab Emirates">United Arab Emirates</option> 
		<option value="United Kingdom">United Kingdom</option> 
		<option value="United States">United States</option> 
		<option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option> 
		<option value="Uruguay">Uruguay</option> 
		<option value="Uzbekistan">Uzbekistan</option> 
		<option value="Vanuatu">Vanuatu</option> 
		<option value="Venezuela">Venezuela</option> 
		<option value="Viet Nam">Viet Nam</option> 
		<option value="Virgin Islands, British">Virgin Islands, British</option> 
		<option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option> 
		<option value="Wallis and Futuna">Wallis and Futuna</option> 
		<option value="Western Sahara">Western Sahara</option> 
		<option value="Yemen">Yemen</option> 
		<option value="Zambia">Zambia</option> 
		<option value="Zimbabwe">Zimbabwe</option>					
	
					</select>
				</td>			
			</tr>			
			<tr>
				<td align="left" width="150">
					Mailing Address 1: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="mailAddress1" value="<?php echo $mailAddress1; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Mailing Address 2: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="mailAddress2" value="<?php echo $mailAddress2; ?>">							
				</td>			
			</tr>			
			<tr>
				<td align="left" width="150">
					Company: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="companyName" value="<?php echo $companyName; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Occupation: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="occupation" value="<?php echo $occupation; ?>">							
				</td>			
			</tr>	
			<tr>
				<td align="left" width="150">
					ID Type: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="idType" value="<?php echo $idType; ?>">							
				</td>			
			</tr>	
			<tr>
				<td align="left" width="150">
					ID Number: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="idNumber" value="<?php echo $idNumber; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Phone 1: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="phone1" value="<?php echo $phone1; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Phone 2: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="phone2" value="<?php echo $phone2; ?>">							
				</td>			
			</tr>	
			<tr>
				<td align="left" width="150">
					Phone 3: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="phone3" value="<?php echo $phone3; ?>">							
				</td>			
			</tr>			
			<tr>
				<td align="left" width="150">
					Contact Name: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="contactName" value="<?php echo $contactName; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Contact Relationship: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="contactRelationship" value="<?php echo $contactRelationship; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Contact Phone 1: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="contactPh1" value="<?php echo $contactPh1; ?>">							
				</td>			
			</tr>
			<tr>
				<td align="left" width="150">
					Contact Phone 2: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="contactPh2" value="<?php echo $contactPh2; ?>">							
				</td>			
			</tr>	
            
            </tr>
			<tr>
				<td align="left" width="150">
					Balance: 
				</td>
				<td align="left" colspan="3">
					<input type="text" maxlength="50" name="balance" value="<?php echo $balance; ?>">							
				</td>			
			</tr>	
            			
				<tr>
				<td align="left" colspan="4">
					<input type="submit" name="submit" value="Save Changes" >
					<input type="hidden" name="submitCheck" value="true">
					<input type="hidden" name="studentId" value="<?php echo $studentId;?>">		
				</td>
				</tr>
				</form>	
				<tr>
				<td align="left" colspan="2">
					<form name="delete" method="post" action="deleteRecord.php">
						<input type="submit" name="sumbit" value="Delete Record">
						<input type="hidden" name="pageName" value="student">
						<input type="hidden" name="id" value="<?php echo $studentId;?>">
					</form>
				</td>
				</tr>										
				</table>
	<?php		
		}
		else
		{   ?>
				<table >
				<tr>
					<td align="center" colspan="2">
						<p class="error">The student does not exist in the system.</p>
					</td>
				</tr>
				</table>
	<?php
		} 
	}
	else
	{	?>
				<table >
				<tr>
					<td align="center" colspan="2">
						<p >You have accessed this page in error.</p>
					</td>
				</tr>
				</table>
	<?php
	}
}
else
{
	?>
		<p align="left">You have accessed this page in error<br>
		<a href="Controlpanel.php">Return to Index</a></p>
	<?php
}
?>	
	</td>
	</tr>
	</table>
    </div>
</body> 
</html> 