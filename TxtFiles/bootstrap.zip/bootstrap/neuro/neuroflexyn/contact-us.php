<?php include("header.php"); ?>

<div class="contact-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12">
				<h1>CONTACT US</h1>
				<p class="subheader-caption">LET US KNOW YOUR RESULTS</p>

				<p>Feel free to leave us a comment or question. We are more than happy to answer any questions you may have. Please include your email and your first name and we will get back to you as quickly as possible.</p>

				<p class="email">You may also send us an email directly to <span>Support@Neuroflexyn.com</span></p>

				<div class="blue-div">
					<img src="images/img-cs.png" />
					<div class="info">
						<p class="title">CUSTOMER SUPPORT</p>
						<div>
							<p>Toll Free: <span>877-296-9799</span></p>
							<p>Mon-Fri 6:00am to 6:00pm PST</p>
							<p>Saturdays 8:00am to 1:00pm PST</p>
							<p>Email: <span>Support@Neuroflexyn.com</span></p>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="card">
					<div class="title">Wholesale Inquiries Only</div>
					<div class="contact">Email: Wholesale@Neuroflexyn.com</div>

					<div class="title">Marketing Inquiries Only</div>
					<div class="contact">Email: Marketing@Neuroflexyn.com</div>

					<div class="title">Mailing Address</div>
					<div class="contact">
						<p>Neuroflexyn</p>
						<p>3183 Wilshire Blvd #196T</p>
						<p>Los Angeles, CA 90010</p>
					</div>

					<div class="title">Corporate Address</div>
					<div class="contact">
						<p>3183 Wilshire Blvd #196T</p>
						<p>Los Angeles, CA 90010</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">

			<?php include("sidebar.php"); ?>

			</div>
		</div>

	</div>
	<div class="try-neuroflexyn">

		<?php include("try-neuroflexyn.php"); ?>
		
	</div>
	<?php include("footer-logo-sublinks.php"); ?>	
	<?php include("footer.php"); ?>

</div>