<?php 
session_start();
?>
	<script type="text/javascript" src="../jquery.js"></script>
	<script type="text/javascript" src="../scripts/ajaxfileupload.js"></script>

    <link href="../CSS/Local.css" rel="stylesheet" type="text/css">	
<html>
<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">

<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">
<head>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;
$_SESSION['username_session'];


?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>

		  <p>
  <?php
		  


//Previous values///////////////////////
//////////CURRENT VALUES////////////////////////////

$accttitle = $_POST['accttitle'];		  
$acctdes = $_POST['acctdes'];
$active = $_POST['active'];
$accttype = $_POST['accttype'];

$today = time(); 



include 'config.php';
include 'opendb.php';


$SQL1 = "INSERT INTO account ( ACCTNAME, DESCRIPTION , ACTIVE ,ACCTYPE )
Values('".$accttitle."','".$acctdes."','".$active."','".$accttype."')" ;
$result1_SQL1 = mysql_query($SQL1);
if (!$result1_SQL1){
echo 'An Error has occurred please click here to go back to the previous form';
die();
}





  ?>

<a href="create_fin_acct.php">Financial Account Created Successfully. You are being redirected </a></p> 
		  <p><script>setTimeout('window.location.replace("create_fin_acct.php")', 1000);  </script> </p>
          </div>
</body>
</html>
