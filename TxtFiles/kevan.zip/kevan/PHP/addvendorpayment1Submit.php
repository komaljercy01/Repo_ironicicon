<?php 
session_start();
?>
	
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
</head>
<body >
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;
$_SESSION['username_session'];


?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>

		  <p>
  <?php
		  
///Previous values///////////////



//Previous values///////////////////////
//////////CURRENT VALUES////////////////////////////
$vnumber = mysql_real_escape_string($_POST['vnumber']);		  
$VchequeNo = mysql_real_escape_string($_POST['VchequeNo']);
$Date = mysql_real_escape_string($_POST['Date']);
$vid_get = mysql_real_escape_string($_POST['vid']);
$cash = mysql_real_escape_string($_POST['cash']);
$Comment = mysql_real_escape_string($_POST['Comment']);
$TAmount = mysql_real_escape_string($_POST['TAmount']);
$SQL1 = " INSERT INTO vpaymentseq  ( VendorID, CHQno, VPDATE, CashAcc, VDamount, Comment)  VALUES 

('".$vid_get."','".$VchequeNo."','".$Date."','".$cash."','".$TAmount."','".$Comment."') " ;
$result1 = mysql_query($SQL1);
$lastVPSID= mysql_insert_id();
echo $lastVPSID;

//$quantity1 = mysql_real_escape_string($_POST['quantity1']);
$Description1 = mysql_real_escape_string($_POST['Description1']);
$vaccountpay1 = mysql_real_escape_string($_POST['vaccountpay1']);
$Amount1 = mysql_real_escape_string($_POST['Amount1']);

$vpaymentdetails1 = " INSERT INTO vpaymentdetails   ( VPSID, VendorID, VPDDesc, VPDaccID, VPDamt)  VALUES 

('".$lastVPSID."','".$vid_get."','".$Description1."','".$vaccountpay1."','".$Amount1."')" ;

$resultvpaymentdetails1 = mysql_query($vpaymentdetails1);


$quantity2 = mysql_real_escape_string($_POST['quantity2']);
$Description2 = mysql_real_escape_string($_POST['Description2']);
$vaccountpay2 = mysql_real_escape_string($_POST['vaccountpay2']);
$Amount2 = mysql_real_escape_string($_POST['Amount2']);

$vpaymentdetails2 = " INSERT INTO vpaymentdetails   ( VPSID, VendorID, VPDDesc, VPDaccID, VPDamt)  VALUES 

('".$lastVPSID."','".$vid_get."','".$Description2."','".$vaccountpay2."','".$Amount2."')" ;
$resultvpaymentdetails2 = mysql_query($vpaymentdetails2);


$quantity3 = mysql_real_escape_string($_POST['quantity3']);
$Description3 = mysql_real_escape_string($_POST['Description3']);
$vaccountpay3 = mysql_real_escape_string($_POST['vaccountpay3']);
$Amount3 = mysql_real_escape_string($_POST['Amount3']);

$vpaymentdetails3 = " INSERT INTO vpaymentdetails   ( VPSID, VendorID, VPDDesc, VPDaccID, VPDamt)  VALUES 

('".$lastVPSID."','".$vid_get."','".$Description3."','".$vaccountpay3."','".$Amount3."')" ;

$resultvpaymentdetails3 = mysql_query($vpaymentdetails3);

$quantity4 = mysql_real_escape_string($_POST['quantity4']);
$Description4 = mysql_real_escape_string($_POST['Description4']);
$vaccountpay4 = mysql_real_escape_string($_POST['vaccountpay4']);
$Amount4 = mysql_real_escape_string($_POST['Amount4']);

$vpaymentdetails4 = " INSERT INTO vpaymentdetails   ( VPSID, VendorID, VPDDesc, VPDaccID, VPDamt)  VALUES 

('".$lastVPSID."','".$vid_get."','".$Description4."','".$vaccountpay4."','".$Amount4."')" ;
$resultvpaymentdetails4 = mysql_query($vpaymentdetails4);


$quantity5 = mysql_real_escape_string($_POST['quantity5']);
$Description5 = mysql_real_escape_string($_POST['Description5']);
$vaccountpay5 = mysql_real_escape_string($_POST['vaccountpay5']);
$Amount5 = mysql_real_escape_string($_POST['Amount5']);

$vpaymentdetails5 = " INSERT INTO vpaymentdetails   ( VPSID, VendorID, VPDDesc, VPDaccID, VPDamt)  VALUES 

('".$lastVPSID."','".$vid_get."','".$Description5."','".$vaccountpay5."','".$Amount5."')" ;
$resultvpaymentdetails5 = mysql_query($vpaymentdetails5);

$fullamount = $Amount1+ $Amount2 +$Amount3 + $Amount4 +$Amount5; 
$SQL = " Update  vpaymentseq  set  VDamount='".$fullamount."'  
where  
VPSID='".$lastVPSID."'";
$result= mysql_query($SQL);
  ?>
Success!
What would you like to do next?
 <div class="row">
    <div class="col-md-8 col-md-offset-1">
<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
               <a href="addVendorpayment1.php?vid=<?php echo $vid_get;?>" class="btn btn-primary btn-lg " role="button">Add payment for same vendor</a>
              <a href="addvendorpayment.php" class="btn btn-primary btn-lg " role="button">Add payment for different vendor</a>
              </div>
            </div>
            </div>
            
            </div>
      </div>
        </div>
</body>
</html>
