<div class="how-work-setps">
	<div class="step">
		<img src="images/img-step1.jpg" />
		<div class="info">
			<p class="title">STEP #1</p>
			<p class="body">DMAE bitartrate begins working by boosting oxygen levels in your blood4, helping to increase alertness and spike motivation.</p>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="step">
		<!-- <img src="images/img-stepline.jpg" /> -->
		<div class="clearfix"></div>
	</div>
	<div class="step">
		<img src="images/img-step2.jpg" />
		<div class="info">
			<p class="title">STEP #2</p>
			<p class="body">Bacopin &reg; begins to increase cerebral blood flow5 and allow for improved memory recall.</p>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="step">
		<!-- <img src="images/img-stepline.jpg" /> -->
		<div class="clearfix"></div>
	</div>
	<div class="step">
		<img src="images/img-step3.jpg" />
		<div class="info">
			<p class="title">STEP #3</p>
			<p class="body">Next, Choline begins to repair neurotransmitters that have taken free radical damage or normal wear and tear from high-level cognitive function6.</p>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="step">
		<!-- <img src="images/img-stepline.jpg" /> -->
		<div class="clearfix"></div>
	</div>
	<div class="step">
		<img src="images/img-step4.jpg" />
		<div class="info">
			<p class="title">STEP #4</p>
			<p class="body">Finally, GABA acts as a calming agent7 to ensure that you avoid any feeling of being jittery or "on edge".</p>
		</div>
		<div class="clearfix"></div>
	</div>
</div>