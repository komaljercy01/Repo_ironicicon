<?php session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>change username</title>

	<script type="text/javascript" src="../jquery.js"></script>
	<script type="text/javascript" src="../scripts/ajaxfileupload.js"></script>
    <link href="../CSS/Local.css" rel="stylesheet" type="text/css">
	
<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>

<script type="text/javascript" src="../scripts/jquery-1.2.1.pack.js"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<script type="text/javascript">
function data_copy()
{

if(document.addstudentinfo.copy[0].checked){
document.addstudentinfo.MailAdd1.value= document.addstudentinfo.HAddress.value;

}else{

document.addstudentinfo.MailAdd1.value="";


}

}

</script>


<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="container">
<table width="100%" border="0">
  <caption align="left">
    Menu
  </caption>
  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>

<?php 
include 'config.php';
include 'opendb.php';

//$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];


$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}
} // if($row=mysql_fetch_array($resultid))
else{
echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}

$username = $_POST['inputString'];        
  ?>   <?php
   $query5="select * from user where  USERNAME LIKE '".$username."'"; 
	   $result5= mysql_query($query5);
$if_username_exist = mysql_num_rows($result5);
if ($if_username_exist==0){
echo "Username Does not exist please try again";
include 'getuser_change.php';
die();
}


 
 ?>
   
	
<table width="100%" border="0">
  <tr>
    <td><form id="changeuser" name="changeuser" method="post" action="change_username_submit.php">
    Change username <?php echo $username; ?> to :  
        <span id="sprytextfield1">
        <input name="new_username" type="text" id="new_username" />
        <span class="textfieldRequiredMsg">A value is required.</span></span>
        <input type="hidden" name="inputString" id="inputString" value="<?php echo $username;?>" />
      <label>
      <input type="submit" name="submit" id="submit" value="Submit" />
      </label>
    </form>    </td>
    <td>&nbsp;</td>
  </tr>
</table>
</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom");
//-->
</script>
</body>
</html>
