<?php 
session_start();
?>
	

<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.2/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/tabletools/2.2.3/css/dataTables.tableTools.css">
	<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" language="javascript" src="./scripts/datatable10000.js"></script>
	<script type="text/javascript" language="javascript" src="//cdn.datatables.net/tabletools/2.2.3/js/dataTables.tableTools.min.js"></script>
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->


        
<title>Edit Vendor</title>
<head>
</head>
  
	<?php 



include 'config.php';
include 'opendb.php';

$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];
$appid = $_GET['appid'];
$appidcheck = $_GET['appid'];
$formnum=2;
$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {
"	<body><p>Some text that you want to display to the user.</p>
";


	echo '<p> Unable to log in <a href=login.html> click here </a> to login again ';

echo "</body> </html>";

die();
}
} // if($row=mysql_fetch_array($resultid))
else{
	
	"	<body>



";

echo " 
<p> Unable to log in <a href=login.html> click here </a> 


 to login again 
 
</body> </html>";

die();
}



?>


    
    
    

          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>
<body id="dt_example">
		<div id="container">
		
	

        
<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $adminusername; ?></td>
      </tr>
      <tr>
        <td height="34">

<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>
    

<table width="100%" border="0">

  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>

<?php 



include 'config.php';
include 'opendb.php';

$quer_usersfor_course=mysql_query("

SELECT  *
FROM   VpayTemp 
WHERE  
debitAmt > 0


");  

?>
<div id="container">
		<div id="demo">
<table  width="100%" class='display' id='example' cellpadding='0' cellspacing='0' border='1'> 
    <thead>
    		<tr>
          
            <th >Date</th>
             <th >VSeqNO</th>
             <th>AccounIDnumber</th>
          <th>AccountName</th>
                <th >Cheque</th>
                <th>Vendor Number </th>
            <th>Vendor Name </th>               
                <th >Amount</th>
                 <th>Line Description</th>               
               

          </tr>
    </thead>
    <tbody>
   
   


 
<?php




/////////////////////////////////////////////////////////create temp table//////////////////////////////////////////////////
include 'config.php';
include 'opendb.php';


while($noticia = mysql_fetch_array($quer_usersfor_course)) {
//	$inputString_post.= "'".$noticia['USERNAME']."',";
//$vendorid = $noticia['VendorID'];
$accountid_query = $noticia['accountid'];
$vendorname_query =$noticia['VendorName'];

$quer_acctname=mysql_query("
SELECT * 
FROM account
WHERE ACCTNAME LIKE  '$accountid_query' "
);
while($noticia_quer_acctname = mysql_fetch_array($quer_acctname)) {
	$acctidoutput=$noticia_quer_acctname['ACCTID'];
}


$quer_vname=mysql_query("
SELECT * 
FROM vendor
WHERE VendorName LIKE  '$vendorname_query' "
);
while($noticia_quer_vname = mysql_fetch_array($quer_vname)) {
	$vidoutput=$noticia_quer_vname['VendorID'];
}

echo "<tr>";
echo "<td>".$noticia['date']."</td>";
echo "<td>".$noticia['VDetailsNumber']."</td>";
echo "<td>".$acctidoutput."</td>";
echo "<td>".$noticia['accountid']."</td>";
echo "<td>".$noticia['checkNo']."</td>";
//echo "<td>".$noticia['checkNo']."</td>";
echo "<td>".$vidoutput."</td>";
echo "<td>".$noticia['VendorName']."</td>";
echo "<td>".$noticia['debitAmt']."</td>";

echo "<td>".$noticia['lineDesc']."</td>";
//echo "<td>".$noticia['paytype']."</td>";
echo "</tr>";	

}

?>

    </tbody>
    
</table>

</div></div>

    
</div>
		<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('#example').dataTable();
} );
		</script>
</body>
</html>