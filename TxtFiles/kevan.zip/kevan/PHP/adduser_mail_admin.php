<?php 
session_start();
?>
<html>
<head>
<title>CTS</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script type="text/javascript" src="../SpryAssets/jquery-1.2.6.min.js"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<SCRIPT type="text/javascript">
<!--
/*
Credits: Bit Repository
Source: http://www.bitrepository.com/web-programming/ajax/username-checker.html 
USERNAME CHECKER SCRPIT
*/

pic1 = new Image(16, 16); 
pic1.src = "images/loader.gif";

$(document).ready(function(){

$("#username").change(function() { 

var usr = $("#username").val();

if(usr.length >= 3)
{
$("#status").html('<img src="loader.gif" align="absmiddle">&nbsp;Checking availability...');

    $.ajax({  
    type: "POST",  
    url: "usercheck.php",  
    data: "username="+ usr,  
    success: function(msg){  
   
   $("#status").ajaxComplete(function(event, request, settings){ 

	if(msg == 'OK')
	{ 
        $("#username").removeClass('object_error'); // if necessary
		$("#username").addClass("object_ok");
		$(this).html('&nbsp;<img src="tick.gif" align="absmiddle">');
	}  
	else  
	{  
		$("#username").removeClass('object_ok'); // if necessary
		$("#username").addClass("object_error");
		$(this).html(msg);
	}  
   
   });

 } 
   
  }); 

}
else
	{
	$("#status").html('<font color="red"></font>');
	$("#username").removeClass('object_ok'); // if necessary
	$("#username").addClass("object_error");
	}

});

});

//-->
</SCRIPT>
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (CTS.psd) -->
<div id="container">
          <h3>&nbsp;</h3>
<table width="700">
            <tr>
              <td> </td>
            </tr>
          </table>
		  <p><br/>
		    
            <?php 
 include 'config.php';
include 'opendb.php';
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];

$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}
} // if($row=mysql_fetch_array($resultid))
else{
echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}



function createPassword($length) {
	$chars = "234567890abcdefghijkmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$i = 0;
	$password = "";
	while ($i <= $length) {
		$password .= $chars{mt_rand(0,strlen($chars))};
		$i++;
	}
	return $password;
}
 
$password = createPassword(8);
$encrpyt_password = md5($password);

$username = $_POST['username'];
$email = $_POST['email'];
$usertype = $_POST['usertype'];
// random password generator goes here
$SQL1 = "INSERT INTO USER (USERNAME, PASSWORD , EMAIL , ACTIVE , USERTYPE )
Values('".$username."','".$encrpyt_password."','".$email."','"."1"."','".$usertype."')" ;

$result1 = mysql_query($SQL1);


$sendto = $email; // this is the email address collected form the form
//$ccto = "you@yourdomain.com"; //you can cc it to yourself
$subject = "email confirmation"; // Subject
$message = "the body of the email - this email is to confirm you have signed up for CTSCBS registration \n Welcome! You have been registered to CTS online Please login here with following information <a href='http://192.168.1.6/CTS/PHP/login.php'> here</a>. <p>Your Username is ".$username."\r\n <p>Password is ".$password."\r\n";
$header = "From: CTSCBS@edu.tt\r\n";
$header .= "Reply-to: CTSCBS@edu.tt\r\n";
// This is the function to send the email
mail($sendto, $subject, $message, $header); 


//echo $message;
?>
</p> Account creation successful.
		  <p><a href="adduser_admin.php">Click here to add another user.</a></p>
</div>

<!-- End Save for Web Slices -->

</body>
</html>