<?php include("header.php"); ?>

<div class="order-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<h1>FINAL STEP - PAYMENT INFORMATION</h1>
			</div>				
		</div>

	</div>
	<div class="container">
		<div class="row form-area">
			<div class="col-lg-8 col-md-8 col-sm-12">
				<div class="card">
					<div class="header">
						<p>Neuroflexyn - <span>5 Bottles</span> - Recommended</p>
						<img src="images/bg-freeshipping.png" />

					</div>
					<div class="body" data-order="1">
						<div class="white-bg">
							<div class="info">
								<div class="checkbox"></div>
								<p class="package">Best Selling Package</p>
								<p class="bottle-plan">5 Bottle Monster Plan!</p>
								<p class="price">$149.85</p>
								<p class="individual-price">Only $29.97/ea</p>
							</div>
							<img src="images/img-package-one.png" />
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="card">
					<div class="header">
						<p>Neuroflexyn - <span>3 Bottles</span></p>
						<img src="images/bg-freeshipping.png" />

					</div>
					<div class="body" data-order="2">
						<div class="white-bg">
							<div class="info">
								<div class="checkbox"></div>
								<p class="package">Tier Two Package</p>
								<p class="bottle-plan">3 Bottle Moderate Plan!</p>
								<p class="price">$119.91</p>
								<p class="individual-price">Only $39.97/ea</p>
							</div>
							<img src="images/img-package-two.png" />
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="card">
					<div class="header">
						<p>Neuroflexyn - <span>1 Bottle</span></p>
						<img src="images/bg-freeshipping.png" />

					</div>
					<div class="body" data-order="3">
						<div class="white-bg">
							<div class="info">
								<div class="checkbox"></div>
								<p class="package">Sampler Package</p>
								<p class="bottle-plan">1 Bottle Test Plan!</p>
								<p class="price">$49.95</p>
								<p class="individual-price">Only $20</p>
							</div>
							<img src="images/img-package-three.png" />
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="computation">
					<div class="compute">
						<img src="images/usps.png" />
						<div class="info">
							<div class="shipping-type type dashes">
								<div class="caption">Shipping Type:</div>
								<div class="amount">Select Package</div>
								<div class="clearfix"></div>
							</div>
							<div class="package-type type dashes">
								<div class="caption">Package Type:</div>
								<div class="amount">Select Package</div>
								<div class="clearfix"></div>
							</div>
							<div class="shipping-price type dashes">
								<div class="shipping-price">
									<div class="caption">Shipping Price:</div>
									<div class="amount">$0.00</div>
									<div class="clearfix"></div>
								</div>
							</div>
							<div class="your-total type dashes">
								<div class="caption">Your Total:</div>
								<div class="amount">$0.00</div>
								<div class="clearfix"></div>
							</div>
							<div class="save type">
								<div class="caption">$0.00</div>
								<div class="amount">$0.00</div>
								<div class="clearfix"></div>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">
				
			</div>
		</div>
	</div>
	<?php include("footer-logo-sublinks.php"); ?>	
	<?php include("footer.php"); ?>

</div>