<?php include("header.php"); ?>

	<div class="gradient-background">
		<div class="container top">
			<div class="header-caption">
				<div class="blue-border">Scientist are calling it</div>
				<p class="main-caption">&#8216;The Smart Pill&#8217;</p>
				<p class="sub-caption">Fuel for The Brain</p>
			</div>
			<div class="formulated">
				<p>Formulated to Help</p>
				<ul>
					<li>
						<span class="f-icon icon-rocket"></span>
						<div class="caption">Sky Rocket Concentration</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<span class="f-icon icon-gear"></span>
						<div class="caption">Improve Creative Thinking</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<span class="f-icon icon-thunder"></span>
						<div class="caption">Boost Energy</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<span class="f-icon icon-time"></span>
						<div class="caption">Enhance Memory Recall</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<span class="f-icon icon-mind"></span>
						<div class="caption">Elevate Work Productivity</div>
						<div class="clearfix"></div>
					</li>
				</ul>
				<div class="clearfix"></div>
				<button>Buy Now!</button>
			</div>
			<div class="socmed-container">
				<div class="socmed money-back">
					<div class="socmed-img"></div>
					<div class="caption">
						<div class="top-caption">Money-Back</div>
						<div class="bottom-caption">Guarantee</div>
					</div>
				</div>
				<div class="socmed fast-acting">
					<div class="socmed-img"></div>
					<div class="caption">
						<div class="top-caption">Fast Acting</div>
						<div class="bottom-caption">Formula</div>
					</div>
				</div>
				<div class="socmed amazon">
					<div class="socmed-img"></div>
					<div class="caption">
						<div class="top-caption">Amazon</div>
						<div class="bottom-caption">Payments</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="neuroflexyn-info">
			<h1>WHAT IS NEUROFLEXYN?</h1>
			<p class="subheader-caption">A FAST, SAFE WAY TO GAIN A MENTAL EDGE</p>
			<div class="row">
				<div class="col-lg-7 col-md-6 col-sm-12">
					<img class="img-responsive" src="images/img-science.jpg" />
				</div>
				<div class="col-lg-5  col-md-6 col-sm-12">
					<p class="subheader-caption">NEUROFLEXYN</p>
					<p class="info">is an expertly crafted cognitive enhancement supplement that has been studied and produced by a top-quality, cGMP certified and FDA licensed laboratory environment under the most rigorously professional conditions.</p>
					<p class="info">The positive mental benefits provided by the ingredients in Neuroflexyn have been published by organizations such as Science magazine1, the American Journal of Clinical Nutrition2, and the Center for Human Psychopharmacology3.</p>
					<p class="info">Neuroflexyn - research drives results!</p>
				</div>
			</div>
		</div>
	</div>
	<div class="benefits">
		<!-- <div class="people img-responsive"></div>	 -->
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<img class="people img-responsive" src="images/bg-people.png" />
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 benefits-list-container">
					<div class="benefits-list">
						<h1>THE BENEFITS</h1>
						<p class="subheader-caption">OF NEUROFLEXYN</p>
						<div>
							<img src="images/img-check.png" />
							<div class="caption">Help conquer the pesky distraction that sabotages your ability to focus and finish important projects, without the jittery feeling that too much caffeine can create.</div>
							<div class="clearfix"></div>
						</div>
						<div>
							<img src="images/img-check.png" />
							<div class="caption">Treat your brain to the protective benefits of antioxidants while increasing cerebral blood flow and promoting healthy neurotransmitters.</div>
							<div class="clearfix"></div>
						</div>
						<div>
							<img src="images/img-check.png" />
							<div class="caption">Neuroflexyn isn't just any smart supplement - it's a custom blend with a detailed approach to formulation based on ingredients that have been studied by several top scientific journals.</div>
							<div class="clearfix"></div>
						</div>
						<div>
							<img src="images/img-check.png" />
							<div class="caption">A safe, fast way to load up on compounds that studies suggest can increase focus, concentration, and mood regulation.</div>
							<div class="clearfix"></div>
						</div>
						<button>Buy Now!</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="focus">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<h1>WHY FOCUS</h1>
					<p class="subheader-caption">WITH NEUROFLEXYN</p>
					<p class="info">NEUROFLEXYN isn't your ordinary supplement. It contains ingredients that not only enhance your ability to think clearly and focus in the short-term, but also provide important protective benefits for your long-term cerebral health. By increasing your brain's natural production of acetylcholine, Neuroflexyn promotes enhanced neurotransmitter function.</p>
					<p class="info">Other "nootropic" smart supplements are slow to reveal the ingredients they contain, but Neuroflexyn's blend has always been based on ingredients with a track record of thorough scientific study. With Neuroflexyn, research drives results.</p>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12">
					<img src="images/bg-brainbottle.jpg" class="img-responsive brain-bottle" />
				</div>
			</div>
		</div>
	</div>
	<div class="how-works">
		<div class="container">
			<div class="row">
				<div class="col-lg-5 col-md-6 col-sm-12">
					<h1>HOW DOES</h1>
					<p class="subheader-caption">NEUROFLEXYN WORK?</p>
					<div class="detailed-info">
						<img src="images/bottle-small.png" />
						<p class="caption">It's no secret that "nootropics", sometimes called "smart supplements", are hugely popular today. The ability to enhance the human brain's processing speed and sense of clarity is a well-documented phenomenon, but what makes Neuroflexyn the best nootropic available?</p>
						<p class="caption">Neuroflexyn relies on ingredients that peer-reviewed research has shown exciting potential to improve intellectual activity, enhance mood, and provide increased focus. Importantly, these studies were primarily conducted on individuals with normal cognitive function, meaning that the people participating in the studies were regular, everyday people like you. Best of all, the incredibly high-quality FDA licensed laboratory environment used to manufacture Neuroflexyn ensures that each and every pill is of the highest, professional-grade standard.</p>
					</div>
				</div>
				<div class="col-lg-7 col-md-6 col-sm-12">
					<?php include("how-works.php") ?>
				</div>
			</div>
		</div>
	</div>
	<div class="whats-in">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<span>WHAT'S IN</span>
					<p class="subheader-caption">NEUROFLEXYN?</p>

					<?php include("neuroflexyn-ingredients.php"); ?>

				</div>
			</div>
		</div>
	</div>
	<div class="supplements-fact">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<h1>SUPPLEMENT <span>FACTS</span></h1>
					<p class="subheader-caption">EXPERIENCE THE ULTIMATE PRODUCTIVITY PILL TODAY</p>
					<img class="img-responsive hidden-xs" src="images/bottle-ingredient.png" />
					<img class="img-responsive supplements visible-xs" src="images/supplements-bottles.png" />
					<img class="img-responsive supplements visible-xs" src="images/supplements-fact.jpg" />
				</div>
			</div>
		</div>
	</div>
	<div class="rush-button">
		<div class="container">
			<div class="row">
				<button>Rush My Order!</button>
			</div>
		</div>
	</div>
	<div class="compare">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<h1>HOW DOES IT COMPARE?</h1>
					<img class="img-responsive" src="images/img-table.jpg" />
				</div>
			</div>
		</div>
	</div>

	<div class="try-neuroflexyn">
		<?php include("try-neuroflexyn.php"); ?>
	</div>

	<?php include("footer-logo-sublinks.php"); ?>
	<?php include("footer.php"); ?>
</body>
</html>