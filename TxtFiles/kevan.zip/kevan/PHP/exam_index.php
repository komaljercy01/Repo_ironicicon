<?php
session_start();
?>
<html> 
<head>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">
</head> 
</head> 
<body> 
<div id="container">
<table>
<tr>
<td valign="top">

<?php

include 'config.php';

if (($usertype =="MA" ) || ($usertype =="AA" ) || ($usertype =="SA" ))
{

$formTitle = "ADMINISTRATION HOME";
?>
		<table>		
		<tr>
			<td>
				<p><?php 	echo $formTitle;	?><br>
				<hr>
				<p align="left">
				<?php if ($usertype == 'MA' ) { ?>
					WELCOME. Here you can create, access and modify Academic Body, Course and Teacher information.
				<?php } else { ?>
					<p>WELCOME. Here you can view Academic Body, Course and Teacher information.
				<?php } ?>
				</p> 				
			</td>
		</tr>
		<tr>
			<td>
				<hr>
				<p align="left">ACADEMIC BODIES</p>
				<p align="left">
				<?php if ($usertype == 'MA' ) { ?>
					<a href="addBody.php">Add Academic Body</a><br>
				<?php } ?>
					<a href="listBody.php">List Academic Bodies</a>
				</p>                
			</td>
		</tr>
		<tr>
			<td>
				<hr>
				<p align="left">LISTS</p>
				<p align="left">
					<a href="listProgram.php">List All Programmes</a><br> 
					<a href="listCourse.php">List All Courses</a><br>  
					<a href="listYear.php">List All Academic Years</a><br>  
					<a href="listSemester.php">List All Semesters</a><br> 
					<a href="listCourseOffering.php">List All Course Offerings</a><br> 
					<a href="addSimilarCourseOffering.php">Add Multiple and Similar Course Offerings</a><br> 
				</p>  									               
			</td>
		</tr>
		<tr>
			<td>
				<hr>
				<p align="left">TEACHERS</p>
				<p align="left">
				<?php if ($usertype == 'MA' ) { ?>
					<a href="addTeacher.php">Add Teacher</a><br> 
				<?php } ?>
					<a href="listTeacher.php">List Teachers</a>
				</p>                                               
			</td>
		</tr>  
		<tr>
			<td>
				<hr>
				<p align="left">SEARCH</p>
				<p align="left">
					<a href="searchPeople.php">Search Teachers, Students </a> <br>  
					<a href="searchAcademic.php">Search Academic Body, Programme, Course, Academic Year, Semester, Course Offering</a>
				</p>	
			</td>
		</tr> 
 		<tr>
			<td>
				<hr>
<!--				<p align="left">SEMESTER TIMETABLE</p>
				<p align="left">
					<a href="semesterTimeTable.php">View the course schedule for a particular semester<br>  
				</p>	 -->				
			</td>
		</tr>  
		</table>
<?php
}
else
{
	?>
		<p align="left">You have accessed this page in error<br>
		<a href="login.php">Return to login</a></p>
	<?php
}
?>
		
</td>
</tr>
</table>
</div>
</body> 
</html> 