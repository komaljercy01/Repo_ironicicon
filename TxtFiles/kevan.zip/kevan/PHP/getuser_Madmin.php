<?php 
session_start();



include 'config.php';
include 'opendb.php';
//$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$adminusername = $_SESSION['username_session'];


$SQLuserid = "select * from  user where USERNAME='".$adminusername."' OR USERNAME='".$_SESSION['username_session']."'"; 
$resultid = mysql_query($SQLuserid);
if($row=mysql_fetch_array($resultid))
{
if($row['PASSWORD'] == $password && $row['ACTIVE']==1 ){}

else {echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}
} // if($row=mysql_fetch_array($resultid))
else{
echo '<p> Unable to log in <a href=index.html > click here </a> to login again';
die();}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Student Information</title>
<link href="../CSS/Local.css" rel="stylesheet" type="text/css">

<script src="/spryjs/SpryValidationConfirm.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">

<link href="../SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="../scripts/jquery-1.2.1.pack.js"></script>
<script type="text/javascript">
	function lookup(inputString) {
		if(inputString.length == 0) {
			// Hide the suggestion box.
			$('#suggestions').hide();
		} else {
			$.post("rpc_Madmin.php", {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$('#suggestions').show();
					$('#autoSuggestionsList').html(data);
				}
			});
		}
	} // lookup
	
	function fill(thisValue) {
		$('#inputString').val(thisValue);
		setTimeout("$('#suggestions').hide();", 200);
	}
</script>

<style type="text/css">


	.suggestionsBox {
		position: relative;
		left: 30px;
		margin: 10px 0px 0px 0px;
		width: 200px;
		background-color: #212427;
		-moz-border-radius: 7px;
		-webkit-border-radius: 7px;
		border: 2px solid #000;	
		color: #fff;
	}
	
	.suggestionList {
		margin: 0px;
		padding: 0px;
	}
	
	.suggestionList li {
		
		margin: 0px 0px 3px 0px;
		padding: 3px;
		cursor: pointer;
	}
	
	.suggestionList li:hover {
		background-color: #659CD8;
	}
</style>

</head>

<body>
<div id="container">
<table width="100%" border="0">
  <caption align="left">
    Menu
  </caption>
  <tr>
    <td align="left"><a href="Controlpanel.php" title="Control Panel" >Home</a>  </td>
  </tr>
</table>
<?php 
$username = $_POST['inputString'];
      
         
  ?>  
   
      <p class="gaia"><span >Required fields are marked</span><span class="style1">*</span></p>

	
        <form method="post"  name="addstudentinfo" action="reset_pass_Madmin.php">
		  <div>
				Type Username:
				<br />
				<span id="sprytextfield1">
				<input type="text" size="30" value="" name="inputString" id="inputString" onkeyup="lookup(this.value);" onblur="fill();" />
				<span class="textfieldRequiredMsg">A value is required.</span></span><?php //echo $username;?>			</div>
			
			<div class="suggestionsBox" id="suggestions" style="display: none;">
				<img src="../images/upArrow.png" style="position: relative; top: -12px; left: 30px;" alt="upArrow" />
				<div class="suggestionList" id="autoSuggestionsList">
					&nbsp;
				</div>
			</div>
            <input type="submit" value="Reset Password"/>
    
         </form>   

	</div>

    <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
//-->
    </script>
    </div>
</body>
</html>
