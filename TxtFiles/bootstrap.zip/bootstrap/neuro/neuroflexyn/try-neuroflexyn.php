<div class="container">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<h1>TRY NEUROFLEXYN TODAY!</h1>
			<div class="white-container">
				<div class="col-lg-4 col-md-4 col-sm-12">
					<img class="img-responsive big-bottle" src="images/bottle-big.png" />
				</div>
				<div class="col-lg-8 col-md-8 col-sm-12">
					<p class="title">SMART SUPPLEMENT, SMART CHOICE. GET IT TODAY</p>
					<p class="body">Neuroflexyn is guaranteed to help increase focus, improve concentration, and deliver a boost in energy. If for any reason you are dissatisfied with the product, simply return the unused portion within 30 days for a full, prompt refund, no questions asked.</p>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<img src="images/img-badges.png" class="img-responsive badge-img" />
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<img src="images/img-stars.png" class="img-responsive star-img" />
					</div>
					<div class="clearfix"></div>
					<button>Rush My Order!</button>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>