-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2015 at 06:54 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `elance`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `ACCTID` int(5) NOT NULL AUTO_INCREMENT,
  `ACCTNAME` varchar(25) NOT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `ACTIVE` varchar(3) DEFAULT NULL,
  `DATE` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ACCTYPE` int(3) DEFAULT NULL,
  `SALE_TYPE` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ACCTID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`ACCTID`, `ACCTNAME`, `DESCRIPTION`, `ACTIVE`, `DATE`, `ACCTYPE`, `SALE_TYPE`) VALUES
(1, '20012', 'FCB - 1397019 chequing a/c', 'Yes', '2011-01-04 18:46:15', 2, 'CTS'),
(2, '20013', 'FCB - Montrose 2nd chequing', 'Yes', '2011-01-04 18:46:44', 2, 'CTS'),
(3, '20015', 'Petty Cash', 'Yes', '2011-01-04 18:47:00', 2, 'CTS'),
(4, '23000', 'A/R for CTSCBCS', 'Yes', '2011-01-04 18:47:48', 1, 'CTS'),
(5, '40001', 'Sales Rev - GATE', 'Yes', '2011-01-04 18:48:37', 4, 'GATE'),
(6, '40004', 'Sales Rev - T-Shirts & Misc', 'Yes', '2011-01-04 18:49:01', 4, 'CTS'),
(7, '44000', 'Sales Rev - Computer Courses', 'Yes', '2011-01-04 18:49:30', 4, 'CTS'),
(8, '44100', 'Sales Rev - CSEC Courses', 'Yes', '2011-01-04 18:49:52', 4, 'CTS'),
(9, '44200 - B.Sc. Rev', 'UH B.Sc. Sales', 'Yes', '2011-01-04 18:50:15', 4, 'CTS'),
(10, '44300 - BABA Rev', 'UH BABA Sales', 'Yes', '2011-01-04 18:50:30', 4, 'CTS'),
(11, '44400 - ABE Rev', 'ABE Sales', 'Yes', '2011-01-04 18:50:55', 4, 'CTS'),
(12, '44500 - ACP Rev', 'ACP Sales', 'Yes', '2011-01-04 18:51:10', 4, 'CTS'),
(13, '44800 - MBA Rev', 'GLG MBA Sales', 'Yes', '2011-01-04 18:51:28', 4, 'CTS'),
(14, '40003', 'CTS Reg Fee', 'Yes', '2011-03-16 15:10:51', 4, 'REG'),
(15, '66017', 'Discount Allowed', 'Yes', '2011-04-21 00:20:09', 5, 'CTS'),
(16, 'Accrual - GLG MBA fees', 'Accrual - GLG MBA fees', 'Yes', '2012-01-24 18:45:45', 6, 'noCTS'),
(17, '44600 Prof Course Rev', 'Professional Course Sales', 'Yes', '2012-06-27 16:44:30', 4, 'CTS'),
(18, '44900 ABMA Rev', 'ABMA Sales', 'Yes', '2012-08-29 14:41:43', 4, 'CTS'),
(19, 'Gown - Rental', 'Gown - Rental', 'Yes', '2013-10-05 17:39:13', 4, 'CTS'),
(20, 'Graduation Tickets', 'Graduation Ticket Sales', 'Yes', '2013-10-05 17:39:31', 4, 'CTS'),
(21, 'Accrual - ACP fees', 'Accrual - ACP fees', 'Yes', '2013-11-20 18:11:20', 6, 'noCTS'),
(22, 'Accrual - ABE fees', 'Accrual - ABE fees', 'Yes', '2014-03-26 19:11:53', 6, 'noCTS'),
(23, 'Accrual - ABMA Fees', 'Accrual - ABMA Fees', 'Yes', '2014-09-15 20:05:08', 6, 'noCTS'),
(24, 'Accrual - UH BABA fees', 'Accrual - UH BABA fees', 'Yes', '2014-09-15 20:06:22', 6, 'noCTS'),
(25, 'A/R - Foreign Fees - ACP', 'A/R - Foreign Fees - ACP', 'Yes', '2014-09-15 20:13:58', 1, 'noCTS'),
(26, 'A/R - Foreign Fees - UH', 'A/R - Foreign Fees - UH', 'Yes', '2014-09-15 20:13:58', 1, 'noCTS'),
(27, 'A/R - Foreign Fees - AIB', 'A/R - Foreign Fees - AIB', 'Yes', '2014-09-15 20:15:45', 1, 'noCTS'),
(28, 'A/R - Foreign Fees - ABE', 'A/R - Foreign Fees - ABE', 'Yes', '2014-09-15 20:15:45', 1, 'noCTS'),
(29, 'A/R - Foreign Fees - ABMA', 'A/R - Foreign Fees - ABMA', 'Yes', '2014-09-15 20:17:27', 1, 'noCTS'),
(30, 'Foreign Expense - ACP', 'Foreign Expense - ACP', 'Yes', '2014-09-15 20:17:27', 5, 'noCTS'),
(31, 'Foreign Expense - AIB', 'Foreign Expense - AIB', 'Yes', '2014-09-15 20:19:45', 5, 'noCTS'),
(32, 'Foreign Expense - ABE', 'Foreign Expense - ABE', 'Yes', '2014-09-15 20:19:45', 5, 'noCTS'),
(33, 'Foreign Expense - ABMA', 'Foreign Expense - ABMA', 'Yes', '2014-09-15 20:20:44', 5, 'noCTS'),
(34, 'Foreign Expense - UH', 'Foreign Expense - UH', 'Yes', '2014-09-15 20:20:44', 5, 'noCTS'),
(35, '44700 - BBA Rev', 'GLG BBA Sales', 'Yes', '2014-09-19 15:38:41', 4, 'CTS'),
(36, 'Accrual - GLG BBA fees', 'Accrual - GLG BBA fees', 'Yes', '2014-09-19 15:39:03', 6, 'noCTS'),
(37, 'Accrual - UH BSc fees', 'Accrual - UH BSc fees', 'Yes', '2014-09-19 15:52:18', 6, 'noCTS'),
(38, '23500', 'A/R for GATE', 'Yes', '2014-09-23 13:35:03', 1, 'GATE');

-- --------------------------------------------------------

--
-- Table structure for table `accounttype`
--

CREATE TABLE IF NOT EXISTS `accounttype` (
  `ACCTYPE` int(3) NOT NULL,
  `ACCTDESC` varchar(50) NOT NULL,
  `MISC` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ACCTYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounttype`
--

INSERT INTO `accounttype` (`ACCTYPE`, `ACCTDESC`, `MISC`) VALUES
(1, 'Account Receivable', NULL),
(2, 'Cash / Bank', NULL),
(3, 'Cost of Sale', NULL),
(4, 'Sale / Income', NULL),
(5, 'Expense', NULL),
(6, 'Accrual', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `USERID` int(50) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `ACTIVE` varchar(100) NOT NULL COMMENT 'ADD CHECK CONSTRAINT ''1'', ''0''',
  `USERTYPE` varchar(10) NOT NULL COMMENT 'Assign Usertype Check Constraint: DEF, AA, MA, DA',
  PRIMARY KEY (`USERID`),
  UNIQUE KEY `USERNAME` (`USERNAME`),
  UNIQUE KEY `EMAIL` (`EMAIL`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Table of Users classified by their type' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`USERID`, `USERNAME`, `PASSWORD`, `EMAIL`, `ACTIVE`, `USERTYPE`) VALUES
(1, 'admindef', '29ccd6e3943335876b295f6faf8ea697', 'admin@def.com', '1', 'DEF'),
(2, 'adminma', 'ef0903717033723d8eec7140fb26746a', 'admin@ma.com', '1', 'MA'),
(3, 'adminaa', '003503028c98685c16838b949f9a8a68', 'admin@aa.com', '1', 'AA');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE IF NOT EXISTS `vendor` (
  `VendorID` int(10) NOT NULL AUTO_INCREMENT,
  `VendorName` varchar(150) NOT NULL,
  `VendorDesc` varchar(150) NOT NULL,
  `Vexpense` int(10) NOT NULL,
  `VendorCashAcct` int(10) NOT NULL,
  `VendorAdd` varchar(150) DEFAULT NULL,
  `Vcity` varchar(150) DEFAULT NULL,
  `VendorPersonContact` varchar(150) DEFAULT NULL,
  `VendorPContact` varchar(150) DEFAULT NULL,
  `VendorSContact` varchar(150) DEFAULT NULL,
  `Vfax` varchar(150) DEFAULT NULL,
  `VendorAcctname` varchar(150) DEFAULT NULL,
  `VendorPEmail` varchar(150) DEFAULT NULL,
  `Vweb` varchar(150) DEFAULT NULL,
  `Vtype` varchar(150) DEFAULT NULL,
  `Vactive` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`VendorID`),
  UNIQUE KEY `VendorID` (`VendorID`),
  KEY `Vexpense` (`Vexpense`,`VendorCashAcct`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`VendorID`, `VendorName`, `VendorDesc`, `Vexpense`, `VendorCashAcct`, `VendorAdd`, `Vcity`, `VendorPersonContact`, `VendorPContact`, `VendorSContact`, `Vfax`, `VendorAcctname`, `VendorPEmail`, `Vweb`, `Vtype`, `Vactive`) VALUES
(20, 'AMAZON.COM', '', 66, 1, '', '', '', '', '', '', '', '', '', '', 1),
(29, 'DIGICEL', '', 69, 1, 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 1),
(34, 'EXPRESS', '', 60, 1, '', '', '', '', '', '', '', '', '', '', 1),
(36, 'COLUMBUS COMUNICATIONS', 'none', 69, 1, 'none', '', '', '', '', '', 'none', '', '', '', 1),
(99, 'TSTT', '', 69, 1, '', '', '', '', '', '', '', '', '', '', 1),
(100, 'TTEC', 'none', 76, 1, 'none', '', '', '', '', '', 'none', '', '', '', 1),
(101, 'TTPOST', '', 63, 3, '', '', '', 'none', '', '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vendorbills`
--

CREATE TABLE IF NOT EXISTS `vendorbills` (
  `VBid` int(10) NOT NULL AUTO_INCREMENT,
  `VID` int(10) NOT NULL,
  `VInvoiceNumber` varchar(150) NOT NULL,
  `VBdate` date NOT NULL,
  `duedate` date NOT NULL,
  `AR` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`VBid`),
  KEY `VID` (`VID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `vendorbills`
--

INSERT INTO `vendorbills` (`VBid`, `VID`, `VInvoiceNumber`, `VBdate`, `duedate`, `AR`, `active`) VALUES
(1, 99, '', '2015-02-01', '2015-05-01', 3, 1),
(2, 99, '', '2015-02-11', '2015-02-28', 8, 1),
(3, 21, '', '2015-03-04', '2015-03-31', 12, 1),
(4, 36, '', '2015-03-04', '2015-03-19', 38, 1),
(5, 20, 'vinvoice ', '2015-03-04', '2015-04-03', 38, 1),
(6, 20, '', '2015-03-04', '2015-04-03', 38, 1),
(7, 20, '', '2015-03-04', '2015-04-03', 38, 1),
(8, 36, '', '2015-03-04', '2015-03-19', 38, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vendorbillsitems`
--

CREATE TABLE IF NOT EXISTS `vendorbillsitems` (
  `VBIID` int(10) NOT NULL AUTO_INCREMENT,
  `VBid` int(10) NOT NULL,
  `AcctID` int(10) NOT NULL,
  `Quantity` decimal(10,2) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `Subtotal` decimal(10,2) NOT NULL,
  `ACTIVE` int(3) NOT NULL,
  PRIMARY KEY (`VBIID`),
  KEY `VBid` (`VBid`,`AcctID`),
  KEY `VBid_2` (`VBid`),
  KEY `AcctID` (`AcctID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `vendorbillsitems`
--

INSERT INTO `vendorbillsitems` (`VBIID`, `VBid`, `AcctID`, `Quantity`, `Description`, `unitPrice`, `Subtotal`, `ACTIVE`) VALUES
(1, 2, 8, '1.00', 'Pencils', '34.00', '34.00', 1),
(2, 2, 9, '2.00', 'papers', '10.00', '20.00', 1),
(3, 2, 12, '4.00', 'clips', '0.50', '2.00', 0),
(4, 1, 6, '1.00', 'January phone bill', '100.00', '100.00', 0),
(5, 3, 4, '12.50', 'test ing ', '1.00', '25.00', 1),
(6, 4, 21, '200.00', 'test ', '3.02', '604.00', 0),
(7, 4, 38, '3.00', 'testttt', '44.00', '132.00', 0),
(8, 4, 20, '3.00', 'mememem', '5.00', '15.00', 1),
(9, 5, 38, '1.00', 'yest', '4.00', '4.00', 1),
(39, 6, 38, '1.00', 'testt', '2.00', '2.00', 1),
(40, 7, 38, '1.00', 'testt', '2.00', '2.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vpaymentdetails`
--

CREATE TABLE IF NOT EXISTS `vpaymentdetails` (
  `VPDID` int(10) NOT NULL AUTO_INCREMENT,
  `VPSID` int(10) NOT NULL,
  `VPDDesc` varchar(150) NOT NULL,
  `VBID` int(10) NOT NULL,
  `PaymentAmt` float(10,2) NOT NULL,
  `PaymentDiscount` float(10,2) NOT NULL,
  `DiscountID` int(10) NOT NULL,
  `ACTIVE` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`VPDID`),
  KEY `VPSID` (`VPSID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `vpaymentseq`
--

CREATE TABLE IF NOT EXISTS `vpaymentseq` (
  `VPSID` int(10) NOT NULL AUTO_INCREMENT,
  `VendorID` int(10) NOT NULL,
  `CashAcct` int(10) NOT NULL,
  `ChequeNumber` varchar(150) NOT NULL,
  `ChequeAmt` float(10,2) NOT NULL,
  `ChequeDate` date NOT NULL,
  `Active` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`VPSID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `vpaymentseq`
--

INSERT INTO `vpaymentseq` (`VPSID`, `VendorID`, `CashAcct`, `ChequeNumber`, `ChequeAmt`, `ChequeDate`, `Active`) VALUES
(1, 0, 0, '', 0.00, '0000-00-00', 1),
(2, 0, 0, '', 0.00, '0000-00-00', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vendorbillsitems`
--
ALTER TABLE `vendorbillsitems`
  ADD CONSTRAINT `vendorbillsitems_ibfk_1` FOREIGN KEY (`VBid`) REFERENCES `vendorbills` (`VBid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
