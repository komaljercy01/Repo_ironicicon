
<?php 
$userid = $_SESSION['USERAUTH'];

$query4="select USER.USERTYPE from USER where  USERID  = '$userid '";
$result4 = @mysql_query($query4);

while($row=mysql_fetch_array($result4))
{
$usertype= $row['USERTYPE'];
}
?>