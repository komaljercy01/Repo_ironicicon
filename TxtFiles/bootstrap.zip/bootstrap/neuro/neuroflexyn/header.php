<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="/images/favicon.ico">

<meta property="og:locale" content="en_US" />
<meta property="og:url" content="http://www.neuroflexyn.com" />
<meta property="og:site_name" content="Neuroflexyn" />
<meta property="og:title" content="Neuroflexyn Brain Enhancement and Balanced Nootropic Formula" />
<meta property="og:description" content="Neuroflexyn is a smart supplement and balanced nootropic produced in a top-quality, cGMP certified and FDA licensed laboratory." />
<meta property="og:image" content="http://www.neuroflexyn.com/images/600x315_neuroflexyn_fb.png" />
<meta property="fb:app_id" content="653277241446599" />

<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300italic,400italic,700italic,400,700,300|Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>

<link href="/vendor/bootstrap/css/bootstrap.min.css" media="screen, projection" rel="stylesheet" type="text/css" />
<link href="/stylesheets/screen.css" media="screen, projection" rel="stylesheet" />
<script src="https://apis.google.com/js/platform.js" async defer></script>
</head>
<body>
<div class="social-share">
	<div class="container">
		<ul>
			<li><a href="https://www.facebook.com/neuroflexyn" target="_blank"><img src="images/ico-fb-small.png"></a></li>
			<li><a href="https://twitter.com/neuroflexyn" target="_blank"><img src="images/ico-twitter-small.png"></a></li>
			<li><a href="https://www.youtube.com/user/neuroflexyn" target="_blank"><img src="images/ico-youtube-small.png"></a></li>
			<li class="g-plus"><div class="g-plusone" data-annotation="none"></div></li>
			<li class="fb-share"><iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fneuroflexyn&amp;width&amp;layout=standard&amp;action=like&amp;show_faces=false&amp;share=true&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:500px; height:80px;" allowTransparency="true"></iframe></li>
		</ul>
		<div class="toll-number">
			<span class="caption">CALL TOLL FREE:</span>
			<span class="number">877-296-9799</span>
		</div>
	</div>
</div>
<div class="toll-number"></div>
<div class="nav-section">
	<div class="container">
		<div class="nav">
			<a href="."><img src="images/logo.png" class="main-logo" /></a>
			<div class="mobile-toggle visible-xs">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</div>
			<ul>
				<li><a href=".">Home</a></li>
				<li class="hidden-xs"><span class="div-separator"></span></li>
				<li><a href="how-neuroflexyn-works.php">How It Works</a></li>
				<li class="hidden-xs"><span class="div-separator"></span></li>
				<li><a href="neuroflexyn-success-stories.php">Testimonials</a></li>
				<li class="hidden-xs"><span class="div-separator"></span></li>
				<li><a href="about-neuroflexyn.php">Ingredients</a></li>
				<li class="hidden-xs"><span class="div-separator"></span></li>
				<li><a href="neuroflexyn-frequently-asked-questions.php">FAQ</a></li>
				<li class="hidden-xs"><span class="div-separator"></span></li>
				<li><a href="contact-us.php">Contact</a></li>
				<li class="hidden-xs"><span class="div-separator"></span></li>
				<li><a href="order.php">Order</a></li>
			</ul>
		</div>	
	</div>
</div>
<div class="ajax-content">
	<div class="content"></div>
</div>