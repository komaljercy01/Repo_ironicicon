<?php 
session_start();
?>
	
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
</head>
<body >
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;
$_SESSION['username_session'];


?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>

		  <p>
  <?php
		  
///Previous values///////////////



//Previous values///////////////////////
//////////CURRENT VALUES////////////////////////////
$vname = mysql_real_escape_string($_POST['vname']);		  
$vnumber = mysql_real_escape_string($_POST['vnumber']);
$VchequeNo = mysql_real_escape_string($_POST['VchequeNo']);
$Date = mysql_real_escape_string($_POST['Date']);
$vid = mysql_real_escape_string($_POST['vid']);
$cash = mysql_real_escape_string($_POST['cash']);
$Comment = mysql_real_escape_string($_POST['Comment']);
$TAmount = mysql_real_escape_string($_POST['TAmount']);
$VPDid = $_POST['VPDID'];
$Amount = $_POST['Amount'];
$Description = $_POST['Description'];
$vaccountpay = $_POST['vaccountpay'];
//$i= mysql_real_escape_string($_POST['i']);
$i = 5;

//$result1 = mysql_query($SQL1);
//$lastVPSID= mysql_insert_id();
//echo $lastVPSID;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

foreach ( $_POST['row'] as $key =>$value ) {
    echo $key."  ".$value. "<br />";
	$count=$value;
	//echo $VPDid[$key];
//$vpaymentdetails1 = " UPDATE vpaymentdetails  set  VPDDesc =$value  where VPDID=$VPDid  ";
}
for ($k = 0; $k <= $count; $k++)
    {
 
	$SQL1 = " Update  vpaymentdetails   set VPDDesc='".$Description[$k]."' ,  VPDaccID='".$vaccountpay[$k]."' , VPDamt='". $Amount[$k]."' where VPDID='".$VPDid[$k]."'";
$result1 = mysql_query($SQL1);
$seqAmount += $Amount[$k];
    }


$SQL = " Update  vpaymentseq  set CHQno='".$VchequeNo."' ,  VPDATE='".$Date."' , CashAcc='".$cash."' ,  VDamount='".$seqAmount."' , Comment='".$Comment."' 
where  
VPSID='".$vid."'";
$result= mysql_query($SQL);
  ?>
Success!
What would you like to do next?
 <div class="row">
    <div class="col-md-8 col-md-offset-1">
<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
               <a href="editVendorpayment1.php?vid=<?php echo $vid_get;?>" class="btn btn-primary btn-lg " role="button">Add payment for same vendor</a>
              <a href="editvendorpayment.php" class="btn btn-primary btn-lg " role="button">Add payment for different vendor</a>
              </div>
            </div>
            </div>
            
            </div>
      </div>
        </div>
</body>
</html>
