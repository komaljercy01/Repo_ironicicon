	  
<?php
include 'config.php';
include 'opendb.php';

if($_POST){
	$vnumber = $_POST['vnumber'];
	$Date = $_POST['date'];
	$vaccountpay1 = $_POST['AR'];
	$dueDate = $_POST['duedate'];
	$vbid=$_POST['vbid'];
	
	$s="select * from vendorbills where VBid=$vbid";
	$sresult = mysql_query($s);
	$lastVBID="";
	if(!$sresult){
		$SQL1 = " INSERT INTO vendorbills  ( VID, VBdate, duedate, AR, active)  VALUES ('".$vnumber."','".$Date."','".$dueDate."','".$vaccountpay1."','1') " ;
		$result1 = mysql_query($SQL1);
		$lastVBID= mysql_insert_id();
	}else{
		$SQL1 = " UPDATE vendorbills  SET VBdate='".$Date."', duedate='".$dueDate."', AR='".$vaccountpay1."', active=1 WHERE VBid='".$vbid."'" ;
		$result1 = mysql_query($SQL1);
		$lastVBID=$vbid;
	}
	

    $ct=0;
	$resultSQLvendorbillsitems="";
    foreach( $_POST['desc'] as $k=> $value ){ // loop through array
        $Comment = addslashes( $value );  // set name based on value
        $quantity     = addslashes($_POST['Quantity'][$ct] ); // set qty using $ct to identify # out of total submitted
        $UnitPrice        = addslashes($_POST['unitPrice'][$ct] ); // same as set qty
         $itemacctid        = addslashes($_POST['ARVal'][$ct] ); 
         $amt           = $_POST['Subtotal'][ $ct ];
		 $vbiId=addslashes($_POST['vbitemid'][ $ct ]);
		 $vbitemid=(isset($vbiId) && $vbiId) ? $vbiId : "";
		 if(!is_numeric($quantity)){
			 $jsonEnc=json_encode(array("status"=>"error","message"=>"provide numeric value"));
			 echo $jsonEnc;
			 exit;
		 }
		 if(!is_numeric($UnitPrice)){
			 $jsonEnc=json_encode(array("status"=>"error","message"=>"provide numeric value"));
			 echo $jsonEnc;
			 exit;
		 }
		 if(!isset($Comment) || !$Comment){
			 $jsonEnc=json_encode(array("status"=>"error","message"=>"provide description"));
			 echo $jsonEnc;
			 exit;
		 }
		try{
				if(!$vbitemid){
					$SQLvendorbillsitems = " INSERT INTO vendorbillsitems  ( VBid, AcctID, Quantity, Description, unitPrice, Subtotal,ACTIVE)  VALUES 

		('".$lastVBID."','".$itemacctid."','".$quantity."','".$Comment."','".$UnitPrice."','".$amt."',1) " ;
		$resultSQLvendorbillsitems = mysql_query($SQLvendorbillsitems);	
			}else{
				$SQLvendorbillsitems = "update vendorbillsitems  set AcctID='".$itemacctid."',Quantity='".$quantity."', Description='".$Comment."', unitPrice='".$UnitPrice."', Subtotal='".$amt."',ACTIVE=1 where VBIID=$vbitemid" ;
		$resultSQLvendorbillsitems = mysql_query($SQLvendorbillsitems);	
			}
			$ct++; // increment +1
		}catch(Exception $e){
			$jsonEnc=json_encode(array("status"=>"error","message"=>"Unable to add bill details..."));
			echo $jsonEnc;
		} 
		
       // $db->query("UPDATE products SET product_name = '$product_name', quantity = '$quantity', price = '$price' WHERE id = '$id' LIMIT 1");    
    }
	if($resultSQLvendorbillsitems){
		$jsonEnc=json_encode(array("status"=>"success","message"=>"Bill Details added successfully..."));
		echo $jsonEnc;
	}else{
		$jsonEnc=json_encode(array("status"=>"error","message"=>"No changes available."));
		echo $jsonEnc;
	}
	
	
}
?>

