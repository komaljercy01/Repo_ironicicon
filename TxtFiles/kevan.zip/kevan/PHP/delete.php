

<?php

include 'config.php';
include 'opendb.php';

if($_POST[ amsg_id])
{
$id=$_POST[ amsg_id];
$id = mysql_escape_String($id);
$sql = "delete from courseapp where CAID=$id";
mysql_query( $sql);
}
?>

