<?php 
session_start();
?>
	
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
<link rel="stylesheet" href="http://bootsnipp.com/css/bootsnipp.min.css?ver=42f321feccec9b5774d234a7ace874c2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script> 
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
    	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js"></script>
    <![endif]-->
</head>
<body >
<div id="container">
<!-- Save for Web Slices (CTS.psd) -->
        
		  <?php
    // enter php to divert to login.php when appid and userid test fails
	//
 
include 'config.php';
include 'opendb.php';
 $stu_id = $_SESSION['STU_ID'];
$userid = $_SESSION['USERAUTH'];
$password = $_SESSION['password_session'] ;
$_SESSION['password_session_go_back']= $_SESSION['password_session'] ;
$_SESSION['username_session'];


?> 
          <?php
 //session validation  
 $query4="select USERNAME from user where  USERID  = ".$userid;
$result4 = @mysql_query($query4);

while($row=@mysql_fetch_array($result4))
{
$username= $row['USERNAME'];}
if ($username==null){echo '<p> Unable to log in <a href=login.php > click here </a> to login again ';
die();}
else {
}
?> 
          <script type="text/javascript">
function submitform()
{
    document.forms["logout"].submit();
}
</script>

<form action="logout.php" method="post" name="logout" class="style3" id="logout">    
<table width="300" border="0" align="right" class="style3">
      <tr>
        <td>You are logged in as:</td>
        <td><?php echo $username; ?></td>
      </tr>
      <tr>
        <td height="34">
<?php  // echo "<input type='hidden' name='userid' id='userid' value='".$userid."' > ";?>
<a href="javascript: submitform()" class="style2"> Click here to Logout</a></td>
      </tr>
    </table></form>

		  <p>
  <?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
$vnumber = $_POST['vnumber']
$Date = $_POST['Date'];
$vaccountpay1 = $_POST['vaccountpay1'];
$dueDate = $_POST['dueDate'];

$SQL1 = " INSERT INTO vendorbills  ( VID, VBdate, duedate, AR, active)  VALUES ('".$vnumber."','".$Date."','".$dueDate."','".$vaccountpay1."','1') " ;
$result1 = mysql_query($SQL1);
$lastVBID= mysql_insert_id();

echo $SQL1;
    $ct=0;
    foreach( $_POST['Comment'] as $k=> $value ){ // loop through array
        $Comment = addslashes( $value );  // set name based on value
        $quantity     = addslashes($_POST['Quantity'][$ct] ); // set qty using $ct to identify # out of total submitted
        $UnitPrice        = addslashes($_POST['price'][$ct] ); // same as set qty
         $itemacctid        = addslashes($_POST['itemacctid'][$ct] ); 
         $amt           = $_POST['Samt'][ $ct ];


       // $db->query("UPDATE products SET product_name = '$product_name', quantity = '$quantity', price = '$price' WHERE id = '$id' LIMIT 1");

        $SQLvendorbillsitems = " INSERT INTO vendorbillsitems  ( VBid, AcctID, Quantity, Description, unitPrice, Subtotal)  VALUES 

('".$lastVBID."','".$itemacctid."','".$quantity."','".$Comment."','".$UnitPrice."','".$amt."') " ;
$resultSQLvendorbillsitems = mysql_query($SQLvendorbillsitems);

echo $resultSQLvendorbillsitems;

        $ct++; // increment +1
    }

$vid_get = mysql_real_escape_string($_POST['vid']);

///Previous values///////////////


  ?>
Success!
What would you like to do next?
 <div class="row">
    <div class="col-md-8 col-md-offset-1">
<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
               <a href="addVendorpayment1.php?vid=<?php echo $vid_get;?>" class="btn btn-primary btn-lg " role="button">Add payment for same vendor</a>
              <a href="addvendorpayment.php" class="btn btn-primary btn-lg " role="button">Add payment for different vendor</a>
              </div>
            </div>
            </div>
            
            </div>
      </div>
    <?php }
    else{
    ?>
<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
      <span class='badge badge-important'> Sorry you have access this page in error  </span>
     Please <a href='Controlpanel.php'>click here</a> to go back to the main page 
   </div>
 </div>
</div>
<?php 
}
?>
   
        </div>
</body>
</html>
