<?php

$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die
('Error connecting to mysql');
mysql_select_db($dbname);


$dbcnx =mysql_connect($dbhost, $dbuser, $dbpass);
if(!$dbcnx){
echo "<p>"."unable to connect";
exit();
}

mysql_select_db($dbname, $dbcnx);
if (! mysql_select_db($dbname)){
die('<p> unable to locate '.$dbname.'db');
}
?>